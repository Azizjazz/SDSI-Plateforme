You are a senior UI/UX designer and frontend engineer. Refactor the existing dashboard layout into "Version 2: Nested Sub-Tab Architecture." Maintain the established design tokens: clean white backdrops, rounded card corners, crisp typography, and the distinct Devoteam coral/pink accent color for states.



### SECTION 1: GLOBAL SIDEBAR NAVIGATION REFACTOR

Replace the current flat list navigation in the sidebar with the following specific hierarchical accordion tree structure:



▼ [Coral-Pink Background/Text] AS-IS 

  ├── Initialisation & Cadrage

  ├── Ingestion & Organisation

  ├── Alignement : Analyse & Ateliers 

  └── Synthèse & Cartographie Finale

▷ [Neutral Text] Cible (Phase 2 - Collapsed)

▷ [Neutral Text] Roadmap (Phase 3 - Collapsed)

▷ [Neutral Text] Impact (Simulation - Collapsed)

────────────────────────────────────────────────────────────

⚙️ Settings



UI Customizations: 

Indent the four nested sub-tabs under AS-IS by 16px. 

Inactive sub-tabs must use neutral muted gray text (#64748B).

Completely REMOVE the "Data Ingestion (System Overview)" and "Deliverable Studio" links from the bottom of the sidebar. Keep only "Settings" below the horizontal rule separator.



---



### SECTION 2: DYNAMIC MAIN VIEWPORT STATES

Retain the top global header bar (UIB client dropdown, breadcrumbs "Dashboard > AS-IS Dashboard", profile icon, and "Contact Expert" button). Below the header, implement 4 distinct frame layouts corresponding to the clicked sub-tabs:



#### STATE 1: VIEWPORT FOR "Initialisation & Cadrage"

Goal: Initialize the client mission and establish the methodological scoping boundaries.

Component A: "Mission Creation Form" featuring text fields for [Client Name], [Industry Sector], [Assigned Team], and [Date].

Component B: "Execution Mode Toggle". A high-contrast horizontal pill switch or segmented control for: **[New Mission]** vs **[Refresh Mission]**.

  - If [New Mission] is selected: Show a prominent Drag-and-Drop file landing zone labeled "Importer le Cahier des charges Client (PDF/Docx)".

  - If [Refresh Mission] is selected: Replace the drop zone with a dropdown selector labeled "Sélectionner l'ancienne version SDSI / Roadmap existante".

Component C: "Framework Validation List". A dynamic, editable panel listing standard SDSI phases and sub-phases. Provide inline edit and delete icons next to each item, finalized with a solid coral-colored "Valider le périmètre" action button.



#### STATE 2: VIEWPORT FOR "Ingestion & Organisation"

Goal: Rapid bulk upload, automated classification, and macro visualization of client inputs.

Component A: "Upload & Tagging Modal". A multi-file file ingestion queue window. Each successfully loaded file item displays an inline dropdown chip matrix to override or assign metadata labels (e.g., AS-IS, Cible, Roadmap).

Component B: "Corpus Overview Kanban Board". A full-width kanban-style grid workspace where columns represent the methodological phases validated in State 1. Files populate these columns as clickable, self-contained aspect cards displaying file name, type icon (PDF, PPT, XLS), and assigned tags.



#### STATE 3: VIEWPORT FOR "Alignement : Analyse & Ateliers (Boucles A & B)"

Goal: Consolidate AI document document processing (Loop A) and live collaborative workshop orchestration (Loop B) into a seamless side-by-side workspace.

Left-Hand Split Panel (AI Document Workspace - Loop A):

  - Activating a document card splits the viewport. The left side hosts the interactive PDF/Document viewer.

  - The parallel right panel inside this split houses an "AI Conversational Co-pilot Chatbot". The top right corner of this chat panel includes a persistent button labeled "Consulter nos connaissances passées" which slides open an experiential filter panel (filterable by Year and Sector) to view past Devoteam mission assets.

  - At the bottom of the AI chat panel, embed a clear action button labeled "Voir Questionnaire". Clicking it dynamically swaps out the chat pane with a rich text workspace containing the AI-generated draft questionnaire.

Right-Hand Split Panel (Workshop Execution Studio - Loop B):

  - Top Region: An interactive timeline/Gantt chart row mapping scheduled interview sessions. Clicking an interview card slides out a context sheet to assign the Client Actor, map a base questionnaire template, and inject historic reference data.

  - Central Collaborative Form Field: Activated via a prominent "Partager le lien" icon. Show two synchronized sub-views:

    1. Client View Workspace: A clean web-form input block where client answers track live.

    2. Consultant Notes Grid: A adjacent shaded sidebar area explicitly labeled "Observations/Remarques du Consultant (Temps Réel)" for private notation tracking.

  - Footer Action: Feature a prominent "Double Validation Lock (Client + Consultant)" dual-button set that freezes inputs, permanently saves entries to the central engine, and updates the timeline track item status to "Completed".



#### STATE 4: VIEWPORT FOR "Synthèse & Cartographie Finale"

Goal: Consolidate verified inputs into the definitive architectural delivery profile.

Component A: "Synthesis Editor Builder". Triggered by clicking a primary "Commencer synthèse" button. Loads a master document outline layout pre-populated automatically with consolidated note blocks extracted from State 3.

Component B: "Contextual SI Cartography Map". Appears as a side panel. Displays a skeleton tree of the client's information system mapping nodes using automatic "hard matching" logic. Clicking any node brick opens an contextual NLP input box enabling changes via chat syntax commands (e.g., "déplace cette application vers cette brique fonctionnelle").

Component C: "Final Maturity Network Graph". A visual interactive network diagram based on the node blocks layout seen in image_b1906f.png. Every application/infrastructure brick component must feature high-visibility color-coded border boundaries reflecting digital maturity evaluations (Green = High Coverage, Orange = Moderate Gaps, Red = Critical Risk, Grey = Unknown/Unmapped).

Top Right Utility Drawer: Floating tool buttons allowing the consultant to trigger "Partager le lien (Co-édition Directe)" or "Exporter en PPTX (Effet Carrousel)".