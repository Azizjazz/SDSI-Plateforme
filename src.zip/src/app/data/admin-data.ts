export interface ExpectedDoc {
  id: string;
  name: string;
  description: string;
}

export interface TreeNodeData {
  id: string;
  label: string;
  level: number;
  type: string;
  children: TreeNodeData[];
}

export const TREE_DATA: TreeNodeData[] = [
  {
    id: "as-is", label: "AS-IS", level: 1, type: "as-is",
    children: [
      {
        id: "cartographie", label: "Cartographie", level: 2, type: "as-is-primary",
        children: [
          { id: "carto-fonc", label: "Carto. fonc.", level: 3, type: "as-is-primary", children: [] },
          { id: "carto-appl", label: "Carto. appl.", level: 3, type: "as-is-primary", children: [] }
        ]
      },
      {
        id: "technique", label: "Technique", level: 2, type: "as-is",
        children: [
          {
            id: "infrastructure", label: "Infrastructure", level: 3, type: "as-is",
            children: [
              {
                id: "architectures", label: "Architectures", level: 4, type: "as-is",
                children: [
                  { id: "reseaux", label: "Réseaux", level: 5, type: "as-is", children: [] },
                  { id: "systemes", label: "Systèmes", level: 5, type: "as-is", children: [] },
                  { id: "securite-technique", label: "Sécurité technique", level: 5, type: "as-is", children: [] }
                ]
              },
              { id: "politiques-infra", label: "Politiques", level: 4, type: "as-is", children: [] }
            ]
          }
        ]
      },
      {
        id: "organisationnel", label: "Organisationnel", level: 2, type: "as-is",
        children: [
          { id: "structure-dsi", label: "Structure DSI", level: 3, type: "as-is", children: [] },
          {
            id: "gouvernance-si", label: "Gouvernance SI", level: 3, type: "as-is",
            children: [
              {
                id: "politiques-gouv", label: "Politiques Gouvernance", level: 4, type: "as-is",
                children: [
                  { id: "pol-securite", label: "Politique sécurité", level: 5, type: "as-is", children: [] },
                  { id: "sauvegarde", label: "Sauvegarde", level: 5, type: "as-is", children: [] },
                  { id: "pca", label: "PCA", level: 5, type: "as-is", children: [] }
                ]
              }
            ]
          },
          { id: "processus", label: "Processus", level: 3, type: "as-is", children: [] }
        ]
      }
    ]
  },
  {
    id: "cible", label: "Cible", level: 1, type: "cible",
    children: []
  },
  {
    id: "feuille-de-route", label: "Feuille de route", level: 1, type: "feuille",
    children: [
      { id: "projets-budget", label: "Projets & Budget", level: 2, type: "feuille", children: [] }
    ]
  }
];

export const initialExpectedDocs: ExpectedDoc[] = [
  { id: "plan-continuite", name: "Plan de Continuité d'Activité (PCA)", description: "Procédures de continuité et reprise d'activité en cas de sinistre" },
  { id: "rgpd", name: "Politique RGPD", description: "Conformité au règlement général sur la protection des données" },
  { id: "audit-reseau", name: "Audit Réseau", description: "Analyse de performance et sécurité de l'infrastructure réseau" },
  { id: "politique-secu", name: "Politique de Sécurité SI", description: "Document cadre de la politique de sécurité des systèmes d'information" },
  { id: "infra-mapping", name: "Cartographie Infrastructure", description: "Schéma d'architecture et mapping des équipements réseau" },
  { id: "budget-dsi", name: "Budget DSI", description: "Prévision budgétaire de la direction des systèmes d'information" },
  { id: "orga-dsi", name: "Organigramme DSI", description: "Structure organisationnelle avec rôles et responsabilités" },
  { id: "rapport-si", name: "Rapport SI Global", description: "État des lieux complet du système d'information" },
  { id: "cloud-strat", name: "Stratégie Cloud", description: "Feuille de route de migration cloud et architecture cible" },
  { id: "plan-migration", name: "Plan de Migration", description: "Planning de migration des applicatifs et infrastructures" },
];

export function getAllLeafTags(nodes: TreeNodeData[] = TREE_DATA): { id: string; path: string }[] {
  const result: { id: string; path: string }[] = [];
  function walk(n: TreeNodeData[], parentPath: string) {
    for (const node of n) {
      const fullPath = parentPath ? `${parentPath} / ${node.label}` : node.label;
      if (node.children.length === 0) {
        result.push({ id: node.id, path: fullPath });
      } else {
        walk(node.children, fullPath);
      }
    }
  }
  walk(nodes, "");
  return result;
}
