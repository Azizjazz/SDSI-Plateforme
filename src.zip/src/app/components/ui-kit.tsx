import { Sparkles, Scale } from "lucide-react";

// Reusable design-system components

export function AIBadge() {
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium"
      style={{ background: "rgba(139,92,246,0.1)", color: "#8B5CF6", border: "1px solid rgba(139,92,246,0.25)", fontFamily: "JetBrains Mono, monospace" }}>
      <Sparkles size={9} />
      Généré par IA
    </span>
  );
}

export function HumanGateBanner({ label = "Validation requise — Souveraineté Consultant" }: { label?: string }) {
  return (
    <div className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium"
      style={{ background: "rgba(245,158,11,0.08)", border: "1px solid rgba(245,158,11,0.3)", borderTopWidth: 3, borderTopColor: "#F59E0B", color: "#D97706" }}>
      <Scale size={14} />
      <span>⚖️ {label}</span>
    </div>
  );
}

export function GoldButton({ children, onClick, className = "" }: { children: React.ReactNode; onClick?: () => void; className?: string }) {
  return (
    <button onClick={onClick}
      className={`flex items-center gap-2 px-4 h-10 rounded-md font-semibold text-sm transition-all active:scale-[0.98] ${className}`}
      style={{ background: "#D97706", color: "#FFFFFF" }}>
      {children}
    </button>
  );
}

export function PrimaryButton({ children, onClick, className = "", loading = false }: { children: React.ReactNode; onClick?: () => void; className?: string; loading?: boolean }) {
  return (
    <button onClick={onClick} disabled={loading}
      className={`flex items-center gap-2 px-4 h-9 rounded-md font-medium text-sm text-white transition-all active:scale-[0.98] hover:opacity-90 ${className}`}
      style={{ background: loading ? "#CBD5E1" : "#E85D7A", color: loading ? "#94A3B8" : "white" }}>
      {loading ? <span className="animate-spin w-3 h-3 border border-current border-t-transparent rounded-full" /> : null}
      {children}
    </button>
  );
}

export function GhostButton({ children, onClick, className = "" }: { children: React.ReactNode; onClick?: () => void; className?: string }) {
  return (
    <button onClick={onClick}
      className={`flex items-center gap-2 px-4 h-9 rounded-md font-medium text-sm transition-all hover:text-[#0F172A] ${className}`}
      style={{ border: "1px solid #E2E8F0", color: "#64748B" }}
      onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = "#CBD5E1"; }}
      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "#E2E8F0"; }}>
      {children}
    </button>
  );
}

export function AIActionButton({ children, onClick, loading = false }: { children: React.ReactNode; onClick?: () => void; loading?: boolean }) {
  return (
    <button onClick={onClick}
      className="flex items-center gap-2 px-3 h-8 rounded-md text-xs font-medium transition-all"
      style={{ background: "rgba(139,92,246,0.1)", border: "1px solid rgba(139,92,246,0.3)", color: "#8B5CF6" }}
      onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(139,92,246,0.18)"; }}
      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(139,92,246,0.1)"; }}>
      <Sparkles size={11} />
      {loading ? <span className="animate-spin w-3 h-3 border border-current border-t-transparent rounded-full" /> : null}
      {children}
    </button>
  );
}

export function TagChip({ label, color = "blue" }: { label: string; color?: "blue" | "purple" | "teal" | "gray" | "amber" | "green" | "red" }) {
  const colors: Record<string, { bg: string; text: string }> = {
    blue:   { bg: "rgba(232,93,122,0.12)",  text: "#E85D7A" },
    purple: { bg: "rgba(139,92,246,0.12)",  text: "#8B5CF6" },
    teal:   { bg: "rgba(16,185,129,0.12)",  text: "#10B981" },
    gray:   { bg: "rgba(148,163,184,0.15)", text: "#64748B" },
    amber:  { bg: "rgba(245,158,11,0.12)",  text: "#F59E0B" },
    green:  { bg: "rgba(16,185,129,0.12)",  text: "#10B981" },
    red:    { bg: "rgba(239,68,68,0.12)",   text: "#EF4444" },
  };
  const c = colors[color] || colors.blue;
  return (
    <span className="inline-flex items-center px-2 h-[22px] rounded text-[11px]"
      style={{ background: c.bg, color: c.text, fontFamily: "JetBrains Mono, monospace", border: `1px solid ${c.text}22` }}>
      {label}
    </span>
  );
}

export function MaturityDot({ status }: { status: "covered" | "partial" | "obsolete" | "unknown" }) {
  const colors: Record<string, string> = { covered: "#10B981", partial: "#F59E0B", obsolete: "#EF4444", unknown: "#94A3B8" };
  return <span className="inline-block w-2.5 h-2.5 rounded-full shrink-0" style={{ background: colors[status] }} />;
}

export function MaturityLegend() {
  return (
    <div className="flex items-center gap-4 text-xs" style={{ color: "#64748B" }}>
      {[
        { status: "covered",  label: "Couvert"   },
        { status: "partial",  label: "Partiel"   },
        { status: "obsolete", label: "Obsolète"  },
        { status: "unknown",  label: "Inconnu"   },
      ].map(({ status, label }) => (
        <div key={status} className="flex items-center gap-1.5">
          <MaturityDot status={status as any} />
          <span>{label}</span>
        </div>
      ))}
    </div>
  );
}

export function CoverageRing({ pct, size = 48 }: { pct: number; size?: number }) {
  const r = (size - 6) / 2;
  const circ = 2 * Math.PI * r;
  const fill = circ * (1 - pct / 100);
  const color = pct < 30 ? "#CBD5E1" : pct < 60 ? "#E85D7A" : "#10B981";
  return (
    <svg width={size} height={size} className="shrink-0" style={{ transform: "rotate(-90deg)" }}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#E2E8F0" strokeWidth={4} />
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={4}
        strokeDasharray={circ} strokeDashoffset={fill} strokeLinecap="round"
        style={{ transition: "stroke-dashoffset 0.5s ease" }} />
      <text x={size / 2} y={size / 2 + 1} textAnchor="middle" dominantBaseline="middle"
        style={{ transform: "rotate(90deg)", transformOrigin: `${size / 2}px ${size / 2}px`, fill: color, fontSize: size < 40 ? 9 : 11, fontWeight: 600, fontFamily: "JetBrains Mono, monospace" }}>
        {pct}%
      </text>
    </svg>
  );
}

export function ModuleStepper({ active, onNavigate }: { active: number; onNavigate?: (m: number) => void }) {
  const steps = [
    { n: 1, label: "M1 · Création" },
    { n: 2, label: "M2 · Ingestion" },
    { n: 3, label: "M3 · Analyse" },
    { n: 4, label: "M4 · Ateliers" },
    { n: 5, label: "M5 · Synthèse" },
  ];
  return (
    <div className="flex items-center gap-0">
      {steps.map((s, i) => {
        const isDone = s.n < active;
        const isCurrent = s.n === active;
        const isLocked = s.n > active;
        return (
          <div key={s.n} className="flex items-center">
            <button
              onClick={() => !isLocked && onNavigate?.(s.n)}
              disabled={isLocked}
              className="flex items-center gap-1.5 px-3 py-1 rounded text-xs font-medium transition-all"
              style={{
                color: isCurrent ? "#E85D7A" : isDone ? "#10B981" : "#CBD5E1",
                background: isCurrent ? "rgba(232,93,122,0.1)" : "transparent",
                cursor: isLocked ? "default" : "pointer",
              }}>
                <span className="w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold"
                  style={{
                    background: isCurrent ? "#E85D7A" : isDone ? "#10B981" : "#E2E8F0",
                    color: isCurrent || isDone ? "#FFFFFF" : "#94A3B8",
                  }}>
                {isDone ? "✓" : s.n}
              </span>
              <span className="hidden xl:block">{s.label}</span>
            </button>
            {i < steps.length - 1 && (
              <div className="w-5 h-px mx-0.5" style={{ background: isDone ? "#10B981" : "#E2E8F0" }} />
            )}
          </div>
        );
      })}
    </div>
  );
}

export function Card({ children, className = "", hover = false }: { children: React.ReactNode; className?: string; hover?: boolean }) {
  return (
    <div className={`rounded-xl p-4 transition-all ${hover ? "cursor-pointer" : ""} ${className}`}
      style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}
      onMouseEnter={hover ? e => { (e.currentTarget as HTMLElement).style.borderColor = "#CBD5E1"; } : undefined}
      onMouseLeave={hover ? e => { (e.currentTarget as HTMLElement).style.borderColor = "#E2E8F0"; } : undefined}>
      {children}
    </div>
  );
}

export function Input({ label, placeholder, type = "text", className = "" }: { label?: string; placeholder?: string; type?: string; className?: string }) {
  return (
    <div className={className}>
      {label && <label className="block mb-1 text-xs" style={{ color: "#64748B" }}>{label}</label>}
      <input type={type} placeholder={placeholder}
        className="w-full h-9 px-3 rounded-md text-sm outline-none transition-all"
        style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#0F172A" }}
        onFocus={e => { e.currentTarget.style.borderColor = "#E85D7A"; e.currentTarget.style.boxShadow = "0 0 0 2px rgba(232,93,122,0.15)"; }}
        onBlur={e => { e.currentTarget.style.borderColor = "#E2E8F0"; e.currentTarget.style.boxShadow = "none"; }} />
    </div>
  );
}

export function Divider({ label }: { label?: string }) {
  return label ? (
    <div className="flex items-center gap-3 my-2">
      <div className="flex-1 h-px" style={{ background: "#E2E8F0" }} />
      <span className="text-xs" style={{ color: "#94A3B8" }}>{label}</span>
      <div className="flex-1 h-px" style={{ background: "#E2E8F0" }} />
    </div>
  ) : <div className="h-px my-3" style={{ background: "#E2E8F0" }} />;
}

interface ShareableLinkProps {
  url: string;
  status: "active" | "expired";
  permission: "read" | "write";
  expiresIn: string;
  className?: string;
  compact?: boolean;
  onCopy?: () => void;
  onToggleStatus?: () => void;
  onTogglePermission?: () => void;
  onEmail?: () => void;
}

export function ShareableLink({
  url, status, permission, expiresIn, className = "", compact = false,
  onCopy, onToggleStatus, onTogglePermission, onEmail,
}: ShareableLinkProps) {
  return (
    <div className={`${className} space-y-2`}>
      <div className="flex gap-2">
        <div className="flex-1 h-9 px-3 rounded-md flex items-center text-xs truncate"
          style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#94A3B8", fontFamily: "JetBrains Mono, monospace" }}>
          {url}
        </div>
        <button onClick={onCopy} className="px-3 h-9 rounded-md text-xs shrink-0 transition-all"
          style={{ background: "#F1F5F9", border: "1px solid #E2E8F0", color: "#64748B" }}
          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = "#CBD5E1"; }}
          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "#E2E8F0"; }}>
          📋 Copier
        </button>
        {onEmail && (
          <button onClick={onEmail} className="w-9 h-9 rounded-md text-xs shrink-0 transition-all"
            style={{ background: "#F1F5F9", border: "1px solid #E2E8F0", color: "#64748B" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = "#CBD5E1"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "#E2E8F0"; }}>
            📧
          </button>
        )}
      </div>
      <div className="flex items-center gap-3 text-xs" style={{ color: "#94A3B8" }}>
        <button onClick={onToggleStatus}
          className="flex items-center gap-1.5 px-2 py-0.5 rounded transition-all"
          style={{
            background: status === "active" ? "rgba(16,185,129,0.1)" : "rgba(239,68,68,0.1)",
            color: status === "active" ? "#10B981" : "#EF4444",
            border: `1px solid ${status === "active" ? "#10B981" : "#EF4444"}22`,
          }}>
          <span className={`w-1.5 h-1.5 rounded-full ${status === "active" ? "" : "opacity-50"}`}
            style={{ background: status === "active" ? "#10B981" : "#EF4444" }} />
          {status === "active" ? "Actif" : "Expiré"}
        </button>
        {!compact && onTogglePermission && (
          <button onClick={onTogglePermission} className="flex items-center gap-1.5 px-2 py-0.5 rounded transition-all"
            style={{ background: "#F1F5F9", border: "1px solid #E2E8F0", color: "#64748B" }}>
            {permission === "read" ? "🔒" : "✏️"}
            {permission === "read" ? "Lecture seule" : "Saisie autorisée"}
          </button>
        )}
        <span className="ml-auto">Expire dans {expiresIn}</span>
      </div>
    </div>
  );
}
