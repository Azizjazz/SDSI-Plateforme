import { useState } from "react";
import { FileText, ChevronLeft, ChevronRight, Check, Pen, X, Save, FileSpreadsheet, Presentation } from "lucide-react";
import type { CartoBrique } from "../../App";

interface CartographyFact {
  id: number;
  label: string;
  value: string;
  source: string;
  domain: string;
  briqueId: string;
  updated: boolean;
  originalValue?: string;
  validated: boolean;
}

interface DocumentSummary {
  name: string;
  type: string;
  summary: string;
  keyPoints: string[];
}

interface M2DocumentOverviewProps {
  briques: CartoBrique[];
  onBriquesChange: (b: CartoBrique[]) => void;
  onNext: () => void;
  onBack: () => void;
}

const domainColors: Record<string, string> = {
  Support: "#E85D7A",
  Canaux: "#8B5CF6",
  Pilotage: "#0EA5E9",
  "Chaîne de valeur": "#10B981",
  "Gestion du SI": "#F59E0B",
  Référentiel: "#94A3B8",
};

const fileIcons: Record<string, React.ReactNode> = {
  PDF:  <FileText size={13} style={{ color: "#EF4444" }} />,
  PPT:  <Presentation size={13} style={{ color: "#F59E0B" }} />,
  XLS:  <FileSpreadsheet size={13} style={{ color: "#10B981" }} />,
};

const allDocSummaries: DocumentSummary[] = [
  { name: "Politique_Sécurité_2024.pdf", type: "PDF", summary: "Définit la politique de sécurité du SI, les contrôles d'accès, et les exigences réglementaires (RGPD, SOX, Bâle III).", keyPoints: ["Périmètre: DSI et directions métiers", "Conformité RGPD/SOX/Bâle III", "Contrôle d'accès et authentification"] },
  { name: "Infra_réseau_mapping_v3.pptx", type: "PPT", summary: "Cartographie détaillée de l'infrastructure réseau : topologie hub-and-spoke, inventaire équipements Cisco, architecture de sécurité.", keyPoints: ["Architecture hub-and-spoke", "50 serveurs physiques, 200 VMs", "Équipements Cisco EOL 2025"] },
  { name: "Organigramme_DSI.pptx", type: "PPT", summary: "Organigramme de la DSI, rôles et responsabilités, reporting hiérarchique et relations avec les directions métiers.", keyPoints: ["~2 500 utilisateurs internes", "800 utilisateurs externes", "Structure DSI complète"] },
  { name: "Audit_réseau_2023.xlsx", type: "XLS", summary: "Résultats d'audit réseau 2023 : performances, vulnérabilités, recommandations et plan d'action.", keyPoints: ["Audit complet du réseau", "Vulnérabilités identifiées", "Recommandations priorisées"] },
  { name: "Plan_migration_cloud.pdf", type: "PDF", summary: "Plan de migration vers le cloud (AWS/Azure) avec calendrier, applications cibles et analyse des risques.", keyPoints: ["Migration cloud 60% cible", "ERP SAP, CRM Salesforce", "Systèmes critiques identifiés"] },
  { name: "Cloud_Strategy_v2.pdf", type: "PDF", summary: "Stratégie cloud actualisée : objectifs ZTA, automatisation CI/CD, roadmap et budget prévisionnel.", keyPoints: ["Objectif ZTA (Zero Trust)", "Automatisation CI/CD", "Roadmap et budget"] },
  { name: "Budget_DSI_2024_2026.xlsx", type: "XLS", summary: "Budget prévisionnel DSI 2024-2026 par catégorie : investissements, fonctionnement, projets et maintenance.", keyPoints: ["Budget triennal détaillé", "Investissements vs fonctionnement", "Projets et maintenance"] },
  { name: "Rapport_SI_Global.pdf", type: "PDF", summary: "Rapport d'état des lieux du SI : maturité, risques, conformité et recommandations stratégiques.", keyPoints: ["Maturité SI: niveau 3/5", "Risques et conformité", "Recommandations stratégiques"] },
];

const initialFacts: CartographyFact[] = [
  { id: 1,  label: "Périmètre organisationnel", value: "DSI et directions métiers (Finance, RH, Production)", source: "Politique_Sécurité_2024.pdf", domain: "Support", briqueId: "gov",  updated: false, validated: false },
  { id: 2,  label: "Périmètre technique",        value: "Réseau LAN/WAN, Datacenter, Cloud (AWS/Azure)",      source: "Infra_réseau_mapping_v3.pptx", domain: "Gestion du SI", briqueId: "infra", updated: false, validated: false },
  { id: 3,  label: "Nombre d'utilisateurs",      value: "~2 500 utilisateurs internes, 800 externes",          source: "Audit_réseau_2023.xlsx",       domain: "Support", briqueId: "rh",    updated: false, validated: false },
  { id: 4,  label: "Systèmes critiques",         value: "ERP SAP, CRM Salesforce, HRIS PeopleSoft, SI Finance", source: "Plan_migration_cloud.pdf",      domain: "Chaîne de valeur", briqueId: "cartof", updated: false, validated: false },
  { id: 5,  label: "Niveau de maturité SI",      value: "Niveau 3/5 — Partiellement intégré",                  source: "Rapport_SI_Global.pdf",         domain: "Gestion du SI", briqueId: "cartoa", updated: false, validated: false },
  { id: 6,  label: "Contraintes réglementaires",  value: "RGPD, SOX, Bâle III, Loi de Sécurité Financière",    source: "Politique_Sécurité_2024.pdf",  domain: "Pilotage", briqueId: "gov",  updated: false, validated: false },
  { id: 7,  label: "Infrastructure critique",     value: "50 serveurs physiques, 200 VMs, 20 bases de données", source: "Infra_réseau_mapping_v3.pptx",  domain: "Gestion du SI", briqueId: "infra", updated: false, validated: false },
  { id: 8,  label: "Objectifs cibles",            value: "Migration cloud à 60%, automatisation CI/CD, ZTA",    source: "Cloud_Strategy_v2.pdf",         domain: "Chaîne de valeur", briqueId: "cartof", updated: false, validated: false },
];

const briquePctMap: Record<string, number> = {
  gov: 0, rh: 1, infra: 2, secu: 3, cartof: 4, cartoa: 5,
};

const FACT_PCT = 15;

function recalcPct(facts: CartographyFact[], briques: CartoBrique[]): CartoBrique[] {
  const updated: CartoBrique[] = briques.map(b => ({ ...b, pct: 0, maturity: "unknown" }));
  facts.filter(f => f.validated).forEach(f => {
    const b = updated.find(bx => bx.id === f.briqueId);
    if (b) {
      b.pct = Math.min(100, b.pct + FACT_PCT);
      b.maturity = b.pct >= 80 ? "covered" : b.pct >= 50 ? "partial" : b.pct >= 20 ? "obsolete" : "unknown";
    }
  });
  return updated;
}

export function M2DocumentOverview({ briques, onBriquesChange, onNext, onBack }: M2DocumentOverviewProps) {
  const [selectedDoc, setSelectedDoc] = useState<string | null>(null);
  const [editingFact, setEditingFact] = useState<number | null>(null);
  const [editValue, setEditValue] = useState("");
  const [facts, setFacts] = useState<CartographyFact[]>(initialFacts);
  const [expandedSummaries, setExpandedSummaries] = useState<string[]>([]);

  // Derive docs list from facts sources for perfect coherence
  const docs = [...new Set(facts.map(f => f.source))].sort();
  const docSummaries = allDocSummaries.filter(d => docs.includes(d.name));

  const toggleSummary = (name: string) => {
    setExpandedSummaries(prev => prev.includes(name) ? prev.filter(n => n !== name) : [...prev, name]);
  };

  const startEdit = (fact: CartographyFact) => {
    setEditingFact(fact.id);
    setEditValue(fact.value);
  };

  const saveEdit = (id: number) => {
    const newFacts = facts.map(f => f.id === id ? { ...f, value: editValue, originalValue: f.updated ? f.originalValue : f.value, updated: true } : f);
    setFacts(newFacts);
    onBriquesChange(recalcPct(newFacts, briques));
    setEditingFact(null);
  };

  const validateFact = (id: number) => {
    const newFacts = facts.map(f => f.id === id ? { ...f, validated: true, updated: true } : f);
    setFacts(newFacts);
    onBriquesChange(recalcPct(newFacts, briques));
  };

  const validatedCount = facts.filter(f => f.validated).length;
  const updatedCount = facts.filter(f => f.updated).length;
  const filteredFacts = selectedDoc ? facts.filter(f => f.source === selectedDoc) : facts;
  const shownDocCount = docs.length;
  const domains = ["Support", "Canaux", "Pilotage", "Chaîne de valeur", "Gestion du SI", "Référentiel"] as const;

  return (
    <div className="h-full flex flex-col" style={{ background: "#F8FAFC" }}>
      {/* Header */}
      <div className="px-6 py-4 flex items-center justify-between shrink-0" style={{ borderBottom: "1px solid #E2E8F0", background: "#FFFFFF" }}>
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="w-8 h-8 rounded-lg flex items-center justify-center transition-all" style={{ background: "#F1F5F9", color: "#64748B", border: "1px solid #E2E8F0" }}>
            <ChevronLeft size={16} />
          </button>
          <div>
            <h2 className="text-base font-semibold" style={{ color: "#0F172A" }}>Analyse préliminaire</h2>
            <p className="text-xs mt-0.5" style={{ color: "#64748B" }}>Résumés des documents et faits cartographiques extraits</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {updatedCount > 0 && (
            <span className="flex items-center gap-1 px-2.5 h-7 rounded-md text-xs font-medium" style={{ background: "rgba(245,158,11,0.1)", color: "#D97706" }}>
              <Check size={12} /> {updatedCount} mise{updatedCount > 1 ? "s" : ""} à jour
            </span>
          )}
          <button onClick={onNext}
            className="flex items-center gap-2 px-4 h-9 rounded-lg text-sm font-medium transition-all"
            style={{ background: "#E85D7A", color: "white" }}>
            Analyse approfondie <ChevronRight size={14} />
          </button>
        </div>
      </div>

      {/* Document filter bar */}
      <div className="px-6 py-3 flex items-center gap-2 shrink-0 overflow-x-auto" style={{ borderBottom: "1px solid #E2E8F0", background: "#FFFFFF" }}>
        {docs.map(doc => {
          const docFactCount = facts.filter(f => f.source === doc).length;
          return (
            <button key={doc} onClick={() => setSelectedDoc(doc === selectedDoc ? null : doc)}
              className="flex items-center gap-1.5 px-3 h-8 rounded-md text-xs whitespace-nowrap transition-all"
              style={{
                background: selectedDoc === doc ? "rgba(232,93,122,0.12)" : "#F1F5F9",
                border: `1px solid ${selectedDoc === doc ? "rgba(232,93,122,0.3)" : "#E2E8F0"}`,
                color: selectedDoc === doc ? "#E85D7A" : "#64748B",
                fontWeight: selectedDoc === doc ? 500 : 400,
              }}>
              <FileText size={12} />
              <span>{doc}</span>
              <span className="ml-1 text-[10px]" style={{ color: selectedDoc === doc ? "#E85D7A" : "#94A3B8", fontFamily: "JetBrains Mono, monospace" }}>
                {docFactCount}
              </span>
            </button>
          );
        })}
        {selectedDoc && (
          <button onClick={() => setSelectedDoc(null)}
            className="flex items-center gap-1 px-2.5 h-7 rounded-md text-[10px] transition-all ml-1 shrink-0"
            style={{ border: "1px solid #CBD5E1", color: "#64748B", background: "#FFFFFF" }}>
            <X size={11} /> Réinitialiser
          </button>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Stats */}
        <div className="flex gap-4">
          {[
            { label: "Documents analysés", value: shownDocCount.toString(), color: "#64748B" },
            { label: "Faits cartographiques", value: filteredFacts.length.toString(), color: "#E85D7A" },
            { label: "Validés", value: validatedCount.toString(), color: "#10B981" },
            { label: "Domaines couverts", value: new Set(filteredFacts.map(f => f.domain)).size.toString(), color: "#8B5CF6" },
          ].map(stat => (
            <div key={stat.label} className="flex-1 rounded-xl p-4" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
              <p className="text-2xl font-bold" style={{ color: stat.color, fontFamily: "JetBrains Mono, monospace" }}>{stat.value}</p>
              <p className="text-xs mt-1" style={{ color: "#94A3B8" }}>{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Document summaries (collapsible) */}
        <div>
          <h3 className="text-sm font-semibold mb-3" style={{ color: "#0F172A" }}>Résumés des documents</h3>
          <div className="space-y-2">
            {(selectedDoc ? docSummaries.filter(d => d.name === selectedDoc) : docSummaries).map(doc => {
              const isExpanded = expandedSummaries.includes(doc.name);
              return (
                <div key={doc.name} className="rounded-lg overflow-hidden transition-all" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
                  <button onClick={() => toggleSummary(doc.name)}
                    className="flex items-center gap-3 w-full px-4 py-3 text-left"
                    style={{ borderBottom: isExpanded ? "1px solid #E2E8F0" : "none" }}>
                    {fileIcons[doc.type] || <FileText size={13} style={{ color: "#94A3B8" }} />}
                    <span className="flex-1 text-sm font-medium" style={{ color: "#0F172A" }}>{doc.name}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: "#F1F5F9", color: "#94A3B8" }}>{doc.type}</span>
                    <ChevronRight size={14} style={{ color: "#94A3B8", transform: isExpanded ? "rotate(90deg)" : "none", transition: "transform 0.15s" }} />
                  </button>
                  {isExpanded && (
                    <div className="px-4 py-3 space-y-2">
                      <p className="text-xs leading-relaxed" style={{ color: "#475569" }}>{doc.summary}</p>
                      <div className="flex flex-wrap gap-1.5">
                        {doc.keyPoints.map((kp, ki) => (
                          <span key={ki} className="text-[10px] px-2 py-1 rounded-full" style={{ background: "rgba(139,92,246,0.08)", border: "1px solid rgba(139,92,246,0.15)", color: "#7C3AED" }}>
                            {kp}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Facts grouped by domain */}
        {domains.map(domain => {
          const domainFacts = filteredFacts.filter(f => f.domain === domain);
          if (domainFacts.length === 0) return null;
          return (
            <div key={domain}>
              <div className="flex items-center gap-2 mb-3">
                <span className="w-2.5 h-2.5 rounded-full" style={{ background: domainColors[domain] }} />
                <h3 className="text-sm font-semibold" style={{ color: "#0F172A" }}>Diagnostic de {domain}</h3>
                <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: `${domainColors[domain]}15`, color: domainColors[domain], fontFamily: "JetBrains Mono, monospace" }}>
                  {domainFacts.length}
                </span>
                {/* Linked brique scores */}
                {(() => {
                  const linkedBriques = briques.filter(b => b.domain === domain);
                  return (
                    <div className="flex items-center gap-1.5 ml-2">
                      {linkedBriques.map(b => (
                        <span key={b.id} className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: `${domainColors[domain]}08`, border: `1px solid ${domainColors[domain]}20`, color: domainColors[domain] }}>
                          {b.label}: {b.pct}%
                        </span>
                      ))}
                    </div>
                  );
                })()}
              </div>
              <div className="space-y-2">
                {domainFacts.map(fact => (
                  <div key={fact.id} className="rounded-lg p-4 transition-all" style={{
                    background: fact.validated ? "rgba(16,185,129,0.06)" : "#FFFFFF",
                    border: `1px solid ${fact.validated ? "rgba(16,185,129,0.3)" : "#E2E8F0"}`,
                  }}>
                    <div>
                      <div className="flex items-start justify-between mb-1">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-medium" style={{ color: "#64748B" }}>{fact.label}</span>
                          {fact.validated && (
                            <span className="flex items-center gap-0.5 text-[10px] px-1.5 py-0.5 rounded" style={{ background: "rgba(16,185,129,0.1)", color: "#10B981" }}>
                              <Check size={10} /> Validé +{FACT_PCT}%
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: "#E2E8F0", color: "#64748B" }}>{fact.source}</span>
                      </div>
                      {editingFact === fact.id ? (
                        <textarea value={editValue} onChange={e => setEditValue(e.target.value)}
                          className="w-full text-sm p-2 rounded-md outline-none resize-none"
                          style={{ background: "#F8FAFC", border: "1px solid #E85D7A", color: "#0F172A", minHeight: 60 }}
                          autoFocus />
                      ) : (
                        <p className="text-sm leading-relaxed" style={{ color: "#0F172A" }}>{fact.value}</p>
                      )}
                      <div className="flex items-center gap-2 mt-2 flex-wrap">
                        <span className="text-[10px] flex items-center gap-1" style={{ color: "#8B5CF6" }}>
                          <FileText size={10} /> Preuve: {fact.source}
                        </span>
                      </div>
                      <div className="flex justify-end mt-1">
                        {fact.validated ? (
                          <span className="flex items-center gap-1 px-2 h-6 rounded text-[10px]" style={{ background: "#F1F5F9", color: "#10B981" }}>
                            <Check size={10} /> Validé
                          </span>
                        ) : editingFact === fact.id ? (
                          <div className="flex gap-1">
                            <button onClick={() => setEditingFact(null)} className="flex items-center gap-1 px-2.5 h-6 rounded text-[10px] transition-all" style={{ border: "1px solid #E2E8F0", color: "#64748B", background: "#FFFFFF" }}>
                              <X size={10} /> Annuler
                            </button>
                            <button onClick={() => saveEdit(fact.id)} className="flex items-center gap-1 px-2.5 h-6 rounded text-[10px] font-medium text-white transition-all" style={{ background: "#E85D7A" }}>
                              <Save size={10} /> Enregistrer
                            </button>
                          </div>
                        ) : (
                          <div className="flex gap-1">
                            <button onClick={() => startEdit(fact)} className="flex items-center gap-1 px-2 h-6 rounded text-[10px] transition-all" style={{ border: "1px solid #E2E8F0", color: "#64748B", background: "#FFFFFF" }}>
                              <Pen size={10} /> Modifier
                            </button>
                            <button onClick={() => validateFact(fact.id)} className="flex items-center gap-1 px-2.5 h-6 rounded text-[10px] font-medium transition-all" style={{ background: "#10B981", color: "#FFFFFF" }}>
                              <Check size={10} /> Valider
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}

        {/* Empty state */}
        {filteredFacts.length === 0 && (
          <div className="text-center py-16">
            <div className="w-14 h-14 rounded-xl flex items-center justify-center mx-auto mb-4" style={{ background: "#F1F5F9" }}>
              <FileText size={24} style={{ color: "#CBD5E1" }} />
            </div>
            <p className="text-sm font-medium" style={{ color: "#94A3B8" }}>Aucun fait cartographique</p>
            <p className="text-xs mt-1" style={{ color: "#CBD5E1" }}>Aucun fait cartographique n'a été extrait de ce document</p>
          </div>
        )}
      </div>
    </div>
  );
}
