import { useState } from "react";
import { Send, Sparkles, FileText, ChevronLeft } from "lucide-react";
import { AIBadge } from "../ui-kit";

interface ChatMessage {
  role: "user" | "ai";
  text: string;
  sources?: string[];
  documents?: string[];
}

const suggestions = [
  "Résume les documents ingérés pour cette mission",
  "Quels sont les risques principaux identifiés ?",
  "Génère une synthèse exécutive du diagnostic SI",
  "Quelles sont les recommandations prioritaires ?",
];

const initialMessages: ChatMessage[] = [
  {
    role: "ai",
    text: "Bonjour, je suis l'assistant IA de la plateforme SDSI. Je peux vous aider à analyser les documents, comprendre les enjeux SI, et préparer vos ateliers. Que souhaitez-vous explorer ?",
    sources: [],
  },
];

interface ChatBotScreenProps {
  onBack?: () => void;
  onNext?: () => void;
  onQuestions?: (qs: string[]) => void;
}

export function ChatBotScreen({ onBack, onNext, onQuestions }: ChatBotScreenProps) {
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [input, setInput] = useState("");
  const [userQuestions, setUserQuestions] = useState<string[]>([]);

  const send = () => {
    if (!input.trim()) return;
    const userMsg = input;
    setMessages(prev => [...prev, { role: "user", text: userMsg }]);
    setInput("");
    const updated = [...userQuestions, userMsg];
    setUserQuestions(updated);
    onQuestions?.(updated);

    setTimeout(() => {
      const lower = userMsg.toLowerCase();
      let aiResponse = "";
      let sources: string[] = [];
      let documents: string[] = [];

      if (lower.includes("résume") || lower.includes("resume") || lower.includes("synthèse") || lower.includes("synthese")) {
        aiResponse = "Voici une synthèse des documents analysés pour la mission **Audit SI — Banque Centrale Maghreb** :\n\n**Documents ingérés (4/6 reçus) :**\n• Politique_Sécurité_2024.pdf — Politique de sécurité SI\n• Infra_réseau_mapping_v3.pptx — Cartographie réseau\n• Organigramme_DSI.pptx — Structure DSI\n• Audit_réseau_2023.xlsx — Résultats d'audit\n• Plan_migration_cloud.pdf — Stratégie cloud\n• Rapport_SI_Global.pdf — État des lieux SI\n\n**Couverture par domaine :**\n• Organisationnel : 42%\n• Technique : 38%\n• Cartographie : 61%";
        documents = ["Politique_Sécurité_2024.pdf", "Infra_réseau_mapping_v3.pptx", "Rapport_SI_Global.pdf"];
        sources = ["p.1-24"];
      } else if (lower.includes("risque") || lower.includes("vulnérabilité") || lower.includes("vulnerabilite")) {
        aiResponse = "**Risques principaux identifiés :**\n\n1. **Infrastructure obsolète** — Équipements Cisco en fin de support (EOL 2025), architecture hub-and-spoke sous-dimensionnée\n2. **Gouvernance SI fragile** — Pas de RSSI full-time, comité SI sans ordre du jour formalisé\n3. **Continuité d'activité** — Backup LTO-6 sans test depuis 2021, RPO/RTO non conformes\n4. **Sécurité périmétrique** — Firewalls ASA 5500 ancienne génération, pas de SOC\n5. **Conformité réglementaire** — GAP analysis BCT non réalisé, risques de non-conformité Bâle III";
        documents = ["Infra_réseau_mapping_v3.pptx", "Politique_Sécurité_2024.pdf"];
        sources = ["p.3", "p.7", "p.12"];
      } else if (lower.includes("recommandation") || lower.includes("prioritaire")) {
        aiResponse = "**Recommandations prioritaires :**\n\n1. **🔴 Critique** — Lancer un programme de remplacement des équipements réseau EOL (budget estimé : 400 K€)\n2. **🔴 Critique** — Recruter un RSSI dédié ou externaliser via MSSP\n3. **🟡 Important** — Migrer vers une architecture SD-WAN\n4. **🟡 Important** — Réaliser un audit de sécurité externe\n5. **🟢 Souhaitable** — Déployer une solution SIEM\n6. **🟢 Souhaitable** — Formaliser les procédures ITIL (Incident, Problem, Change)";
        documents = ["Rapport_SI_Global.pdf"];
        sources = ["p.20"];
      } else {
        aiResponse = "Je peux vous aider avec :\n\n• **Résumé** des documents de la mission\n• **Analyse des risques** et vulnérabilités\n• **Recommandations** prioritaires\n• **Synthèse exécutive** du diagnostic SI\n• **Préparation d'ateliers** et questionnaires\n\nQue souhaitez-vous explorer ?";
      }

      setMessages(prev => [...prev, {
        role: "ai", text: aiResponse,
        ...(sources.length ? { sources } : {}),
        ...(documents.length ? { documents } : {}),
      }]);
    }, 600);
  };

  return (
    <div className="h-full flex flex-col" style={{ background: "#F8FAFC" }}>
      {/* Header */}
      <div className="px-6 py-4 flex items-center justify-between shrink-0" style={{ borderBottom: "1px solid #E2E8F0", background: "#FFFFFF" }}>
        <div className="flex items-center gap-3">
          {onBack && (
            <button onClick={onBack} className="w-8 h-8 rounded-lg flex items-center justify-center transition-all" style={{ background: "#F1F5F9", color: "#64748B", border: "1px solid #E2E8F0" }}>
              <ChevronLeft size={16} />
            </button>
          )}
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: "rgba(139,92,246,0.1)", color: "#8B5CF6" }}>
              <Sparkles size={16} />
            </div>
            <div>
              <h2 className="text-base font-semibold" style={{ color: "#0F172A" }}>Assistant IA — SDSI</h2>
              <p className="text-xs mt-0.5" style={{ color: "#64748B" }}>Posez vos questions sur les documents et l'analyse SI</p>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[11px] px-2 py-1 rounded-md flex items-center gap-1.5" style={{ background: "rgba(139,92,246,0.08)", border: "1px solid rgba(139,92,246,0.15)", color: "#8B5CF6" }}>
            <Sparkles size={11} />
            Mission: Audit SI — BCM
          </span>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            {m.role === "ai" ? (
              <div className="max-w-[80%]">
                <div className="rounded-xl px-5 py-4 text-sm leading-relaxed"
                  style={{ background: "#FFFFFF", border: "1px solid #8B5CF633", borderLeft: "3px solid #8B5CF6", color: "#0F172A", whiteSpace: "pre-wrap" }}>
                  <div className="flex items-center gap-2 mb-2.5">
                    <AIBadge />
                  </div>
                  {m.text}
                  {m.sources && m.sources.length > 0 && (
                    <div className="flex items-center gap-1.5 mt-3 flex-wrap">
                      <span className="text-[10px]" style={{ color: "#94A3B8" }}>Sources:</span>
                      {m.sources.map(s => (
                        <span key={s} className="text-[11px] px-1.5 py-0.5 rounded"
                          style={{ background: "rgba(232,93,122,0.1)", color: "#E85D7A", fontFamily: "JetBrains Mono, monospace" }}>
                          {s}
                        </span>
                      ))}
                    </div>
                  )}
                  {m.documents && m.documents.length > 0 && (
                    <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                      <span className="text-[10px]" style={{ color: "#94A3B8" }}>Docs:</span>
                      {m.documents.map(d => (
                        <span key={d} className="flex items-center gap-1 text-[11px] px-1.5 py-0.5 rounded"
                          style={{ background: "rgba(16,185,129,0.1)", color: "#10B981" }}>
                          <FileText size={10} /> {d}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="max-w-[70%] px-4 py-2.5 rounded-xl text-sm" style={{ background: "#E85D7A", color: "white" }}>
                {m.text}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Input */}
      <div className="px-6 py-4 shrink-0" style={{ borderTop: "1px solid #E2E8F0", background: "#FFFFFF" }}>
        <div className="flex gap-2 mb-2">
          <div className="flex-1 flex items-center gap-2 px-4 rounded-lg" style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", height: 44 }}>
            <input
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && send()}
              placeholder="Posez votre question sur la mission..."
              className="flex-1 bg-transparent outline-none text-sm" style={{ color: "#0F172A" }}
            />
          </div>
          <button onClick={send} className="w-11 h-11 rounded-lg flex items-center justify-center transition-all" style={{ background: "#8B5CF6", color: "white" }}>
            <Send size={15} />
          </button>
        </div>
        <div className="flex gap-2 flex-wrap">
          {suggestions.map((s, i) => (
            <button key={i} onClick={() => setInput(s)}
              className="text-[11px] px-3 py-1.5 rounded-full transition-all"
              style={{ background: "#F1F5F9", border: "1px solid #E2E8F0", color: "#64748B" }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = "#94A3B8"; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "#E2E8F0"; }}>
              {s}
            </button>
          ))}
        </div>
      </div>

      {onNext && (
        <div className="px-6 py-3 shrink-0 flex justify-end" style={{ background: "#F8FAFC", borderTop: "1px solid #E2E8F0" }}>
          <button onClick={onNext}
            className="flex items-center gap-2 px-5 h-10 rounded-lg text-sm font-medium transition-all"
            style={{ background: "#E85D7A", color: "white" }}>
            Passer à l'analyse des écarts →
          </button>
        </div>
      )}
    </div>
  );
}
