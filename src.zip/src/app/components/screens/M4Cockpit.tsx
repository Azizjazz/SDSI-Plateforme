import { useState, useEffect } from "react";
import { Plus, Send, CheckCircle, Clock, AlertCircle, HelpCircle, FileText, X, Pin, ChevronDown, ChevronRight } from "lucide-react";
import { GoldButton, ShareableLink } from "../ui-kit";

interface Question {
  id: number;
  text: string;
  answered: boolean;
  response: string;
  status: "pending" | "in-progress" | "answered";
  updatedAt: string;
  answeredBy?: string;
}

interface WorkshopNote {
  id: number;
  text: string;
  category: string;
  questionId: number | null;
  pinned: boolean;
}

const initialQuestions: Question[] = [
  { id: 1, text: "Quel est le taux de virtualisation actuel ?",          answered: true,  response: "Environ 45% du parc serveur.", status: "answered",    updatedAt: "11:24", answeredBy: "DSI" },
  { id: 2, text: "Disposez-vous d'un PCA documenté ?",                   answered: true,  response: "Oui, datant de 2021 — non testé depuis.", status: "answered", updatedAt: "11:32", answeredBy: "RSSI" },
  { id: 3, text: "Quelle est la politique de rétention des backups ?",   answered: false, response: "", status: "in-progress", updatedAt: "11:45" },
  { id: 4, text: "Avez-vous réalisé un audit sécurité récemment ?",      answered: false, response: "", status: "pending", updatedAt: "" },
  { id: 5, text: "Quels sont les projets SI en cours ?",                 answered: false, response: "", status: "pending", updatedAt: "" },
];

const noteCategories = ["Observation", "Constat", "Besoin", "Zone d'ombre"];
const noteCatColors: Record<string, string> = {
  "Observation": "#E85D7A", "Constat": "#F59E0B", "Besoin": "#10B981", "Zone d'ombre": "#EF4444",
};
const questionStatusColors: Record<string, string> = {
  pending: "#94A3B8", "in-progress": "#F59E0B", answered: "#10B981",
};
const questionStatusLabels: Record<string, string> = {
  pending: "En attente", "in-progress": "En cours", answered: "Répondu",
};

interface M4CockpitProps { onNext: () => void; }

export function M4Cockpit({ onNext }: M4CockpitProps) {
  const [seconds, setSeconds] = useState(0);
  const [notes, setNotes] = useState<WorkshopNote[]>([
    { id: 1, text: "Architecture hub-and-spoke confirmée par le DSI", category: "Constat", questionId: null, pinned: false },
    { id: 2, text: "Besoin exprimé: migration SD-WAN à horizon 2 ans", category: "Besoin", questionId: 1, pinned: false },
    { id: 3, text: "Aucun RSSI full-time — rôle assuré par un consultant externe", category: "Zone d'ombre", questionId: 2, pinned: true },
  ]);
  const [newNote, setNewNote] = useState("");
  const [newCat, setNewCat] = useState("Observation");
  const [reassignNoteId, setReassignNoteId] = useState<number | null>(null);
  const [showConfirm, setShowConfirm] = useState(false);
  const [showShare, setShowShare] = useState(false);
  const [questionState, setQuestionState] = useState<Question[]>(initialQuestions);
  const [hoveredQuestion, setHoveredQuestion] = useState<number | null>(null);
  const [expandedQuestionNotes, setExpandedQuestionNotes] = useState<number | null>(null);

  useEffect(() => {
    const t = setInterval(() => setSeconds(s => s + 1), 1000);
    return () => clearInterval(t);
  }, []);

  const timer = `${String(Math.floor(seconds / 3600)).padStart(2, "0")}:${String(Math.floor((seconds % 3600) / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;

  const addNote = () => {
    if (!newNote.trim()) return;
    setNotes([...notes, { id: Date.now(), text: newNote, category: newCat, questionId: 1, pinned: false }]);
    setNewNote("");
  };

  const answeredCount = questionState.filter(q => q.answered).length;

  const updateResponse = (id: number, response: string) => {
    setQuestionState(prev => prev.map(q => {
      if (q.id !== id) return q;
      const now = new Date();
      const time = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
      const answered = response.trim().length > 0;
      return {
        ...q,
        response,
        answered,
        status: answered ? "answered" : q.status,
        updatedAt: answered ? time : q.updatedAt,
        answeredBy: answered ? "Client" : q.answeredBy,
      };
    }));
  };

  const questionsWithNotes = questionState.map(q => ({
    ...q,
    relatedNotes: notes.filter(n => n.questionId === q.id),
  }));

  const statusCounts = {
    answered: questionState.filter(q => q.status === "answered").length,
    inProgress: questionState.filter(q => q.status === "in-progress").length,
    pending: questionState.filter(q => q.status === "pending").length,
  };

  const togglePin = (noteId: number) => {
    setNotes(prev => prev.map(n => n.id === noteId ? { ...n, pinned: !n.pinned } : n));
  };

  const reassignNote = (noteId: number, questionId: number | null) => {
    setNotes(prev => prev.map(n => n.id === noteId ? { ...n, questionId } : n));
    setReassignNoteId(null);
  };

  const getNoteQuestionLabel = (note: WorkshopNote): string => {
    if (!note.questionId) return "Générale";
    return `Q${note.questionId}`;
  };

  return (
    <div className="h-full flex overflow-hidden" style={{ background: "#F8FAFC" }}>
      {/* LEFT — Questions with dynamic state */}
      <div className="w-[30%] flex flex-col h-full" style={{ borderRight: "1px solid #E2E8F0" }}>
        <div className="px-4 py-3 shrink-0" style={{ borderBottom: "1px solid #E2E8F0", background: "#FFFFFF" }}>
          <div className="flex items-center justify-between">
            <h4>Questions atelier</h4>
            <span className="text-[11px]" style={{ color: "#94A3B8", fontFamily: "JetBrains Mono, monospace" }}>{answeredCount}/{questionState.length}</span>
          </div>
          {/* Status bar */}
          <div className="flex gap-2 mt-2">
            {[
              { label: "Répondu", count: statusCounts.answered, color: "#10B981" },
              { label: "En cours", count: statusCounts.inProgress, color: "#F59E0B" },
              { label: "Attente", count: statusCounts.pending, color: "#94A3B8" },
            ].map(s => (
              <div key={s.label} className="flex items-center gap-1 text-[10px]" style={{ color: s.color }}>
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: s.color }} />
                <span>{s.count}</span>
              </div>
            ))}
          </div>
          <div className="h-1 rounded-full mt-2 overflow-hidden" style={{ background: "#F1F5F9" }}>
            <div className="flex h-full">
              <div style={{ width: `${(statusCounts.answered / questionState.length) * 100}%`, background: "#10B981", transition: "width 0.5s" }} />
              <div style={{ width: `${(statusCounts.inProgress / questionState.length) * 100}%`, background: "#F59E0B", transition: "width 0.5s" }} />
            </div>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {questionState.map(q => {
            const isHovered = hoveredQuestion === q.id;
            const relatedNotes = notes.filter(n => n.questionId === q.id);
            return (
              <div key={q.id}
                className="rounded-lg transition-all"
                style={{
                  background: isHovered ? "rgba(139,92,246,0.06)" : "#FFFFFF",
                  border: `1px solid ${isHovered ? "rgba(139,92,246,0.3)" : "#E2E8F0"}`,
                  borderLeftWidth: 3,
                  borderLeftColor: questionStatusColors[q.status],
                  boxShadow: isHovered ? "0 2px 8px rgba(0,0,0,0.08)" : "none",
                }}
                onMouseEnter={() => setHoveredQuestion(q.id)}
                onMouseLeave={() => setHoveredQuestion(null)}>
                <div className="px-3 py-2.5">
                  <div className="flex items-start gap-2">
                    {q.status === "answered" ? (
                      <CheckCircle size={13} style={{ color: "#10B981", flexShrink: 0, marginTop: 1 }} />
                    ) : q.status === "in-progress" ? (
                      <Clock size={13} style={{ color: "#F59E0B", flexShrink: 0, marginTop: 1 }} className="animate-pulse" />
                    ) : (
                      <HelpCircle size={13} style={{ color: "#94A3B8", flexShrink: 0, marginTop: 1 }} />
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-xs leading-relaxed" style={{ color: q.answered ? "#64748B" : "#0F172A", fontWeight: q.answered ? 400 : 500 }}>{q.text}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[9px] px-1 py-0.5 rounded" style={{ background: `${questionStatusColors[q.status]}15`, color: questionStatusColors[q.status] }}>
                          {questionStatusLabels[q.status]}
                        </span>
                        {q.updatedAt && (
                          <span className="text-[9px]" style={{ color: "#94A3B8" }}>{q.updatedAt}</span>
                        )}
                        {q.answeredBy && (
                          <span className="text-[9px]" style={{ color: "#8B5CF6" }}>par {q.answeredBy}</span>
                        )}
                      </div>
                      {/* Quick response preview on hover */}
                      {isHovered && q.answered && (
                        <div className="mt-1.5 p-1.5 rounded text-[10px] leading-relaxed" style={{ background: "rgba(16,185,129,0.06)", border: "1px solid rgba(16,185,129,0.15)", color: "#475569" }}>
                          {q.response}
                        </div>
                      )}
                      {/* Associated notes count */}
                      {relatedNotes.length > 0 && (
                        <button onClick={() => setExpandedQuestionNotes(expandedQuestionNotes === q.id ? null : q.id)}
                          className="flex items-center gap-1 mt-1 text-[9px] transition-all" style={{ color: "#8B5CF6" }}>
                          {expandedQuestionNotes === q.id ? <ChevronDown size={9} /> : <ChevronRight size={9} />}
                          {relatedNotes.length} note{relatedNotes.length > 1 ? "s" : ""} associée{relatedNotes.length > 1 ? "s" : ""}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
                {/* Expanded associated notes */}
                {expandedQuestionNotes === q.id && relatedNotes.length > 0 && (
                  <div className="px-3 pb-2.5 space-y-1">
                    {relatedNotes.map(n => (
                      <div key={n.id} className="flex items-start gap-1.5 p-1.5 rounded" style={{ background: "rgba(139,92,246,0.04)", border: "1px solid rgba(139,92,246,0.1)" }}>
                        <span className="text-[9px] leading-relaxed flex-1" style={{ color: "#64748B" }}>{n.text}</span>
                        <span className="text-[8px] px-1 py-0.5 rounded shrink-0" style={{ background: `${noteCatColors[n.category]}15`, color: noteCatColors[n.category] }}>{n.category}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* CENTER — Notes cockpit with question association */}
      <div className="flex-1 flex flex-col overflow-hidden" style={{ borderRight: "1px solid #E2E8F0" }}>
        <div className="px-4 py-3 flex items-center justify-between shrink-0" style={{ borderBottom: "1px solid #E2E8F0", background: "#FFFFFF" }}>
          <div>
            <div className="flex items-center gap-2">
              <h4>Atelier DSI — Direction SI</h4>
              <span className="flex items-center gap-1 text-[11px] px-2 py-0.5 rounded"
                style={{ background: "rgba(239,68,68,0.1)", color: "#EF4444", border: "1px solid rgba(239,68,68,0.3)" }}>
                <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: "#EF4444" }} />
                Live
              </span>
            </div>
            <p className="text-xs mt-0.5" style={{ color: "#64748B", fontFamily: "JetBrains Mono, monospace" }}>{timer}</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <button onClick={() => setShowShare(!showShare)}
                className="text-xs px-3 h-7 rounded-md flex items-center gap-1.5 transition-all"
                style={{ background: showShare ? "rgba(232,93,122,0.12)" : "#F1F5F9", border: "1px solid #E2E8F0", color: "#E85D7A" }}>
                🔗 Partager le questionnaire
              </button>
              {showShare && (
                <div className="absolute right-0 top-full mt-2 w-80 rounded-lg p-4 z-50" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0", boxShadow: "0 8px 24px rgba(0,0,0,0.1)" }}>
                  <ShareableLink
                    url="https://sdsi.devoteam.com/share/qnr-3f9a"
                    status="active"
                    permission="read"
                    expiresIn="14 jours"
                    onCopy={() => {}}
                    onToggleStatus={() => {}}
                    onTogglePermission={() => {}}
                    onEmail={() => {}}
                    compact
                  />
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="px-4 pt-3 pb-1 shrink-0 flex items-center justify-between">
          <label className="text-xs font-semibold" style={{ color: "#0F172A" }}>Notes du consultant</label>
          <div className="flex items-center gap-2">
            <span className="text-[9px] px-1.5 py-0.5 rounded" style={{ background: "rgba(16,185,129,0.1)", color: "#10B981" }}>
              Q1 par défaut
            </span>
            <select value={newCat} onChange={e => setNewCat(e.target.value)}
              className="h-7 px-2 rounded-md text-[10px] outline-none"
              style={{ background: "#F1F5F9", border: "1px solid #E2E8F0", color: "#64748B" }}>
              {noteCategories.map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {/* Pinned notes first */}
          {notes.filter(n => n.pinned).map(n => (
            <div key={n.id} className="flex items-start gap-2.5 px-3 py-2.5 rounded-lg group"
              style={{ background: "rgba(139,92,246,0.06)", border: "1px solid rgba(139,92,246,0.2)", borderLeftWidth: 3, borderLeftColor: noteCatColors[n.category] }}>
              <Pin size={10} style={{ color: "#7C3AED", flexShrink: 0, marginTop: 3 }} />
              <div className="flex-1">
                <p className="text-sm" style={{ color: "#0F172A" }}>{n.text}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: `${noteCatColors[n.category]}15`, color: noteCatColors[n.category], fontFamily: "JetBrains Mono, monospace" }}>
                    {n.category}
                  </span>
                  <div className="relative">
                    <button onClick={() => setReassignNoteId(reassignNoteId === n.id ? null : n.id)}
                      className="text-[9px] px-1.5 py-0.5 rounded transition-all flex items-center gap-0.5"
                      style={{ background: "rgba(139,92,246,0.1)", color: "#7C3AED" }}>
                      {getNoteQuestionLabel(n)} <ChevronDown size={7} />
                    </button>
                    {reassignNoteId === n.id && (
                      <div className="absolute top-full left-0 mt-1 w-40 rounded-md py-1 z-20" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0", boxShadow: "0 4px 12px rgba(0,0,0,0.1)" }}>
                        {questionState.map(q => (
                          <button key={q.id} onClick={() => reassignNote(n.id, q.id)}
                            className="w-full text-left px-3 py-1.5 text-[10px] transition-all"
                            style={{ color: n.questionId === q.id ? "#7C3AED" : "#64748B", background: n.questionId === q.id ? "rgba(139,92,246,0.06)" : "transparent" }}>
                            Q{q.id}: {q.text.substring(0, 22)}...
                          </button>
                        ))}
                        <div className="h-px mx-2" style={{ background: "#E2E8F0" }} />
                        <button onClick={() => reassignNote(n.id, null)}
                          className="w-full text-left px-3 py-1.5 text-[10px] transition-all"
                          style={{ color: n.questionId === null ? "#7C3AED" : "#64748B", background: n.questionId === null ? "rgba(139,92,246,0.06)" : "transparent" }}>
                          Autre (indépendant)
                        </button>
                      </div>
                    )}
                  </div>
                  <button onClick={() => togglePin(n.id)} className="text-[9px] ml-auto" style={{ color: "#94A3B8" }}>
                    Détacher
                  </button>
                </div>
              </div>
            </div>
          ))}

          {/* Divider */}
          {notes.filter(n => n.pinned).length > 0 && notes.filter(n => !n.pinned).length > 0 && (
            <div className="flex items-center gap-2 py-1">
              <div className="flex-1 h-px" style={{ background: "#E2E8F0" }} />
              <span className="text-[9px]" style={{ color: "#94A3B8" }}>Autres notes</span>
              <div className="flex-1 h-px" style={{ background: "#E2E8F0" }} />
            </div>
          )}

          {/* Grouped by question */}
          {questionState.map(q => {
            const qNotes = notes.filter(n => n.questionId === q.id && !n.pinned);
            if (qNotes.length === 0) return null;
            return (
              <div key={q.id} className="mb-2">
                <p className="text-[10px] font-medium mb-1 flex items-center gap-1" style={{ color: "#8B5CF6" }}>
                  <FileText size={10} /> Q{q.id}: {q.text.substring(0, 40)}...
                </p>
                {qNotes.map(n => (
                  <div key={n.id} className="flex items-start gap-2.5 px-3 py-2 rounded-lg group ml-2"
                    style={{ background: "#FFFFFF", border: "1px solid #E2E8F0", borderLeftWidth: 3, borderLeftColor: noteCatColors[n.category] }}>
                    <div className="flex-1">
                      <p className="text-sm" style={{ color: "#0F172A" }}>{n.text}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: `${noteCatColors[n.category]}15`, color: noteCatColors[n.category], fontFamily: "JetBrains Mono, monospace" }}>
                          {n.category}
                        </span>
                        <div className="relative">
                          <button onClick={() => setReassignNoteId(reassignNoteId === n.id ? null : n.id)}
                            className="text-[9px] px-1.5 py-0.5 rounded transition-all flex items-center gap-0.5"
                            style={{ background: "rgba(139,92,246,0.1)", color: "#7C3AED" }}>
                            {getNoteQuestionLabel(n)} <ChevronDown size={7} />
                          </button>
                          {reassignNoteId === n.id && (
                            <div className="absolute top-full left-0 mt-1 w-40 rounded-md py-1 z-20" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0", boxShadow: "0 4px 12px rgba(0,0,0,0.1)" }}>
                              {questionState.map(q => (
                                <button key={q.id} onClick={() => reassignNote(n.id, q.id)}
                                  className="w-full text-left px-3 py-1.5 text-[10px] transition-all"
                                  style={{ color: n.questionId === q.id ? "#7C3AED" : "#64748B", background: n.questionId === q.id ? "rgba(139,92,246,0.06)" : "transparent" }}>
                                  Q{q.id}: {q.text.substring(0, 22)}...
                                </button>
                              ))}
                              <div className="h-px mx-2" style={{ background: "#E2E8F0" }} />
                              <button onClick={() => reassignNote(n.id, null)}
                                className="w-full text-left px-3 py-1.5 text-[10px] transition-all"
                                style={{ color: n.questionId === null ? "#7C3AED" : "#64748B", background: n.questionId === null ? "rgba(139,92,246,0.06)" : "transparent" }}>
                                Autre (indépendant)
                              </button>
                            </div>
                          )}
                        </div>
                        <button onClick={() => togglePin(n.id)} className="text-[9px]" style={{ color: "#94A3B8" }}>
                          Épingler
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            );
          })}

          {/* Ungrouped notes */}
          {notes.filter(n => n.questionId === null && !n.pinned).map(n => (
            <div key={n.id} className="flex items-start gap-2.5 px-3 py-2.5 rounded-lg group"
              style={{ background: "#FFFFFF", border: "1px solid #E2E8F0", borderLeftWidth: 3, borderLeftColor: noteCatColors[n.category] }}>
              <div className="flex-1">
                <p className="text-sm" style={{ color: "#0F172A" }}>{n.text}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: `${noteCatColors[n.category]}15`, color: noteCatColors[n.category], fontFamily: "JetBrains Mono, monospace" }}>
                    {n.category}
                  </span>
                  <div className="relative">
                    <button onClick={() => setReassignNoteId(reassignNoteId === n.id ? null : n.id)}
                      className="text-[9px] px-1.5 py-0.5 rounded transition-all flex items-center gap-0.5"
                      style={{ background: "rgba(148,163,184,0.15)", color: "#64748B" }}>
                      {getNoteQuestionLabel(n)} <ChevronDown size={7} />
                    </button>
                    {reassignNoteId === n.id && (
                      <div className="absolute top-full left-0 mt-1 w-40 rounded-md py-1 z-20" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0", boxShadow: "0 4px 12px rgba(0,0,0,0.1)" }}>
                        {questionState.map(q => (
                          <button key={q.id} onClick={() => reassignNote(n.id, q.id)}
                            className="w-full text-left px-3 py-1.5 text-[10px] transition-all"
                            style={{ color: n.questionId === q.id ? "#7C3AED" : "#64748B", background: n.questionId === q.id ? "rgba(139,92,246,0.06)" : "transparent" }}>
                            Q{q.id}: {q.text.substring(0, 22)}...
                          </button>
                        ))}
                        <div className="h-px mx-2" style={{ background: "#E2E8F0" }} />
                        <button onClick={() => reassignNote(n.id, null)}
                          className="w-full text-left px-3 py-1.5 text-[10px] transition-all"
                          style={{ color: n.questionId === null ? "#7C3AED" : "#64748B", background: n.questionId === null ? "rgba(139,92,246,0.06)" : "transparent" }}>
                          Autre (indépendant)
                        </button>
                      </div>
                    )}
                  </div>
                  <button onClick={() => togglePin(n.id)} className="text-[9px]" style={{ color: "#94A3B8" }}>
                    Épingler
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Add note */}
        <div className="p-3 shrink-0" style={{ borderTop: "1px solid #E2E8F0", background: "#FFFFFF" }}>
          <div className="flex gap-2">
            <textarea value={newNote} onChange={e => setNewNote(e.target.value)}
              placeholder="+ Nouvelle observation..."
              rows={2}
              className="flex-1 px-3 py-1.5 rounded-md text-xs outline-none resize-none"
              style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#0F172A" }} />
            <button onClick={addNote} className="w-8 h-8 rounded-md flex items-center justify-center shrink-0 self-end" style={{ background: "#E85D7A", color: "white" }}>
              <Plus size={14} />
            </button>
          </div>
          <div className="flex items-center gap-2 mt-2">
            <div className="h-0.5 flex-1 rounded-full" style={{ background: "#E2E8F0" }}>
              <div style={{ width: `${(answeredCount / questionState.length) * 100}%`, background: "#10B981", height: "100%", borderRadius: 9999, transition: "width 0.3s" }} />
            </div>
            <span className="text-[11px] shrink-0" style={{ color: "#64748B", fontFamily: "JetBrains Mono, monospace" }}>
              Réponses: {answeredCount}/{questionState.length}
            </span>
          </div>
        </div>

        {/* Terminer */}
        <div className="px-4 py-3 flex items-center gap-3 shrink-0" style={{ borderTop: "1px solid #E2E8F0" }}>
          <button className="h-9 px-4 rounded-md text-sm font-medium transition-all" style={{ background: "#F1F5F9", border: "1px solid #E2E8F0", color: "#64748B" }}>
            ⏸ Pause
          </button>
          <button className="h-9 px-4 rounded-md text-sm font-medium transition-all" style={{ background: "#F1F5F9", border: "1px solid #E2E8F0", color: "#64748B" }}>
            📝 Note rapide
          </button>
          <button onClick={() => setShowConfirm(true)}
            className="ml-auto h-9 px-4 rounded-md text-sm font-semibold transition-all"
            style={{ background: "rgba(239,68,68,0.15)", border: "1px solid rgba(239,68,68,0.3)", color: "#EF4444" }}>
            Terminer l'atelier →
          </button>
        </div>
      </div>

      {/* RIGHT — Client questionnaire */}
      <div className="w-[25%] flex flex-col overflow-hidden shrink-0">
        <div className="px-4 py-3 shrink-0" style={{ borderBottom: "1px solid #E2E8F0", background: "#FFFFFF" }}>
          <h4>Questionnaire Client</h4>
          <p className="text-[11px] mt-0.5" style={{ color: "#94A3B8", fontFamily: "JetBrains Mono, monospace" }}>Live</p>
        </div>
        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {questionState.map(q => (
            <div key={q.id} className="rounded-lg p-3" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
              <div className="flex items-start gap-2 mb-1.5">
                {q.answered
                  ? <CheckCircle size={13} style={{ color: "#10B981", flexShrink: 0, marginTop: 1 }} />
                  : <Clock size={13} style={{ color: "#94A3B8", flexShrink: 0, marginTop: 1 }} className="animate-pulse" />
                }
                <p className="text-xs leading-relaxed" style={{ color: q.answered ? "#64748B" : "#0F172A" }}>{q.text}</p>
              </div>
              <textarea
                value={q.response}
                onChange={e => updateResponse(q.id, e.target.value)}
                placeholder="Saisir la réponse client..."
                rows={2}
                className="w-full mt-1.5 px-2 py-1 rounded text-xs outline-none resize-none"
                style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#0F172A" }}
              />
            </div>
          ))}
        </div>
        <div className="px-3 py-3 shrink-0" style={{ borderTop: "1px solid #E2E8F0" }}>
          <div className="h-1 rounded-full mb-1" style={{ background: "#E2E8F0" }}>
            <div style={{ width: `${(answeredCount / questionState.length) * 100}%`, background: "#10B981", height: "100%", borderRadius: 9999 }} />
          </div>
          <p className="text-[11px] text-right" style={{ color: "#94A3B8", fontFamily: "JetBrains Mono, monospace" }}>{answeredCount}/{questionState.length} réponses</p>
        </div>
      </div>

      {/* Confirm modal */}
      {showConfirm && (
        <div className="absolute inset-0 flex items-center justify-center z-50" style={{ background: "rgba(15,17,23,0.85)" }}>
          <div className="rounded-xl p-6 max-w-sm w-full mx-4" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
            <h3 className="mb-2">Terminer l'atelier ?</h3>
            <p className="text-sm mb-5" style={{ color: "#64748B" }}>
              L'IA va générer le compte rendu basé sur vos {notes.length} observations et les {answeredCount} réponses client.
            </p>
            {answeredCount < questionState.length && (
              <p className="text-xs mb-3" style={{ color: "#F59E0B" }}>
                ⚠️ {questionState.length - answeredCount} question(s) sans réponse
              </p>
            )}
            <div className="flex gap-3 justify-end">
              <button onClick={() => setShowConfirm(false)} className="px-4 h-9 rounded-md text-sm" style={{ background: "#F1F5F9", border: "1px solid #E2E8F0", color: "#64748B" }}>
                Annuler
              </button>
              <button onClick={onNext} className="px-4 h-9 rounded-md text-sm font-semibold" style={{ background: "#EF4444", color: "white" }}>
                Terminer et générer le CR →
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
