import { useState } from "react";
import { Send, ArrowLeft, Search, FileText, ChevronLeft, ChevronRight, Plus, Minus, RotateCcw } from "lucide-react";
import { CoverageRing, MaturityLegend, AIBadge, AIActionButton } from "../ui-kit";
import type { CartoBrique } from "../../App";

const maturityColors: Record<string, string> = {
  covered: "#10B981", partial: "#F59E0B", obsolete: "#EF4444", unknown: "#6B7280",
};

interface ChatMessage {
  role: "user" | "ai";
  text: string;
  sources?: string[];
  scoreDelta?: { briqueId: string; delta: number; reason: string };
}

const chatHistory: ChatMessage[] = [
  { role: "user", text: "Analyse l'état de l'infrastructure réseau dans ce document." },
  { role: "ai", text: "D'après le document *Infra_réseau_mapping_v3.pptx*, l'infrastructure repose sur une architecture hub-and-spoke de 2018. Les points critiques identifiés :\n• 3 sites MPLS à 10 Mbps/site — sous-dimensionné\n• Aucune redondance WAN sur sites secondaires\n• Équipements Cisco en fin de support (EOL 2025)\n\nJe recommande d'ajouter cette brique en statut **Obsolète** sur la cartographie.", sources: ["p.3", "p.7", "p.12"] },
  { role: "user", text: "Quelle est la politique de backup actuelle ?" },
  { role: "ai", text: "La page 12 mentionne un backup journalier sur bandes LTO-6 avec une rétention de 30 jours. Cependant, aucun test de restauration documenté depuis 2021 n'a été retrouvé dans le corpus.", sources: ["p.12"] },
];

const suggestions = [
  "Quels sont les risques cybersécurité identifiés ?",
  "Décris l'architecture applicative AS-IS",
  "Y a-t-il un plan de continuité documenté ?",
];

// Maps each brique to its contributing facts from the overview page (M2DocumentOverview)
const briqueFactMap: Record<string, { label: string; source: string }[]> = {
  gov: [
    { label: "Périmètre organisationnel", source: "Politique_Sécurité_2024.pdf" },
    { label: "Contraintes réglementaires", source: "Politique_Sécurité_2024.pdf" },
  ],
  rh: [
    { label: "Nombre d'utilisateurs", source: "Audit_réseau_2023.xlsx" },
  ],
  infra: [
    { label: "Périmètre technique", source: "Infra_réseau_mapping_v3.pptx" },
    { label: "Infrastructure critique", source: "Infra_réseau_mapping_v3.pptx" },
  ],
  secu: [],
  cartof: [
    { label: "Systèmes critiques", source: "Plan_migration_cloud.pdf" },
    { label: "Objectifs cibles", source: "Cloud_Strategy_v2.pdf" },
  ],
  cartoa: [
    { label: "Niveau de maturité SI", source: "Rapport_SI_Global.pdf" },
  ],
};

const pageContents: Record<number, { title: string; content: string; highlights?: string[] }> = {
  1: { title: "Page 1 — Vue d'ensemble du réseau", content: "Le schéma présente l'architecture réseau globale du SI. Un backbone MLS reliant 3 sites principaux (Paris, Lyon, Marseille) avec des liens MPLS 10 Mbps. Chaque site dispose d'un routeur Cisco 2900 en fin de support. La topologie est de type hub-and-spoke avec Paris comme hub central.", highlights: ["Architecture hub-and-spoke", "Backbone MPLS 10 Mbps", "Routeurs Cisco 2900 EOL"] },
  2: { title: "Page 2 — Inventaire des équipements", content: "Tableau d'inventaire des équipements réseau : 12 routeurs Cisco 2900, 24 switches Cisco Catalyst 3750, 6 firewalls Cisco ASA 5500. Les firmware versions sont majoritairement en version 9.8 (2019). Aucun équipement SD-WAN déployé.", highlights: ["12 routeurs Cisco 2900", "Firmware 9.8 datant de 2019", "Aucun SD-WAN"] },
  3: { title: "Page 3 — Architecture détaillée Paris", content: "Site de Paris : datacenter principal hébergeant les serveurs de production et les bases de données critiques. Connexion fibre optique 1 Gbps vers le backbone. Redondance partielle avec un second lien ADSL de secours (20 Mbps). Présence d'un cluster VMware 6.5 avec 4 hôtes ESXi.", highlights: ["Datacenter principal Paris", "Fibre 1 Gbps + ADSL secours 20 Mbps", "Cluster VMware 6.5 — 4 hôtes"] },
  4: { title: "Page 4 — Architecture Lyon", content: "Site de Lyon : site secondaire hébergeant les applications métiers régionales. Connexion MPLS 10 Mbps. Pas de redondance WAN identifiée. Serveurs physiques HP ProLiant DL380 Gen9 sous Windows Server 2016.", highlights: ["Site secondaire Lyon", "MPLS 10 Mbps sans redondance", "HP ProLiant DL380 Gen9"] },
  5: { title: "Page 5 — Architecture Marseille", content: "Site de Marseille : site tertiaire avec services limités. Connexion MPLS 10 Mbps. Stockage NAS local pour les fichiers régionaux. Pas de backup local automatisé.", highlights: ["Site tertiaire Marseille", "NAS local sans backup automatisé"] },
  6: { title: "Page 6 — Schéma de sécurité périmétrique", content: "Architecture de sécurité : firewall Cisco ASA 5500 en cluster actif/passif. DMZ hébergeant les serveurs web publics. IDS/IPS Snort déployé sur le segment DMZ. VPN site-to-site IPsec pour les connexions partenaires." },
  7: { title: "Page 7 — Infrastructure de sauvegarde", content: "Stratégie de backup : sauvegarde quotidienne sur bandes LTO-6 avec une rétention de 30 jours. Un seul jeu de bandes stocké sur site (Paris). Aucune sauvegarde hors-site ni test de restauration documenté depuis 2021.", highlights: ["Backup LTO-6 quotidien", "Rétention 30 jours", "Aucun test de restauration depuis 2021"] },
  8: { title: "Page 8 — Plan d'adressage IP", content: "Plan d'adressage IP : 10.0.0.0/8 segmenté en /16 par site. DHCP géré par les routeurs Cisco. DNS interne Windows Server 2016. Active Directory intégré pour l'authentification." },
  9: { title: "Page 9 — Services réseaux", content: "Services réseaux déployés : DNS, DHCP, NTP, SNMP v3. Monitoring via Zabbix 5.0. Gestion des logs via syslog centralisé. Pas de solution SIEM en production." },
  10: { title: "Page 10 — Connectivité Cloud", content: "Projet de migration cloud Azure en phase d'étude. ExpressRoute proposé pour la connectivité hybride. Objectif : migrer les applications non-critiques vers Azure d'ici 2025." },
  11: { title: "Page 11 — Contrats de maintenance", content: "Liste des contrats de maintenance : Cisco SmartNet pour les routeurs et switches (échéance 06/2025). Support HP pour les serveurs Gen9. Renouvellement annuel." },
  12: { title: "Page 12 — Plan de continuité (PCA)", content: "Plan de continuité documenté : RPO de 24h, RTO de 72h. Backup LTO-6 comme seul mécanisme de restauration. Aucun site de repli chaud. Procédure de restauration non testée depuis 2021. Risque majeur identifié sur la reprise d'activité.", highlights: ["RPO 24h / RTO 72h", "Backup LTO-6 seul mécanisme", "Aucun test depuis 2021 — Risque majeur"] },
  13: { title: "Page 13 — Annuaire et authentification", content: "Active Directory 2016 déployé sur 2 DC à Paris. Synchronisation AAD Connect avec Azure AD. Pas de MFA déployé. Politique de mots de passe : rotation 90 jours, complexité standard." },
  14: { title: "Page 14 — Virtualisation", content: "Environnement VMware vSphere 6.5 avec 4 hôtes ESXi à Paris. 72 VMs réparties. Stockage SAN HP 3PAR 8200. vCenter Server unique. Pas de DR ni de replication cross-site." },
  15: { title: "Page 15 — Base de données", content: "Bases de données : SQL Server 2016 sur cluster 2 nœuds. Pas de Always On AG. Backup SQL via maintenance plan quotidien. Pas de chiffrement TDE." },
  16: { title: "Page 16 — Applications métiers", content: "Cartographie des applications métiers : ERP (SAP ECC 6.0), CRM (Salesforce intégré), RH (SIRH interne), Gestion documentaire (Alfresco). Interconnexions via API REST et ETL batch." },
  17: { title: "Page 17 — Postes de travail", content: "Parc de 450 postes Windows 10 Pro. Gestion via SCCM. Antivirus Defender déployé. VPN client AnyConnect pour le télétravail. Pas de gestion de correctifs automatisée (OS déployé)." },
  18: { title: "Page 18 — Téléphonie", content: "Solution téléphonie Cisco Call Manager 12.5. Téléphones IP Cisco 7800. Pas de solution de visioconférence centralisée. Teams utilisé de manière informelle." },
  19: { title: "Page 19 — Procédures ITIL", content: "Processus ITIL partiellement déployés : Incident, Problem, Change Management via un outil maison. Pas de CMDB centralisée. Les tickets sont tracés sans catégorisation standardisée." },
  20: { title: "Page 20 — Indicateurs et KPIs", content: "Tableau de bord IT : disponibilité moyenne 99.5% (sous la cible de 99.9%). Temps moyen de résolution : 4h. Tickets ouverts : 23 incidents critiques non résolus." },
};

interface M3AnalysisProps {
  briques: CartoBrique[];
  onBriquesChange: (b: CartoBrique[]) => void;
  onNext: () => void;
  onBack: () => void;
}

export function M3Analysis({ briques, onBriquesChange, onNext, onBack }: M3AnalysisProps) {
  const [selectedBrique, setSelectedBrique] = useState<string>("infra");
  const [messages, setMessages] = useState<ChatMessage[]>(chatHistory);
  const [input, setInput] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(true);
  const [showCoverage, setShowCoverage] = useState(false);
  const [selectedPage, setSelectedPage] = useState<number | null>(null);
  const [pageSearchInput, setPageSearchInput] = useState("");
  const [expandedFacts, setExpandedFacts] = useState<string | null>(null);
  const [editingCarto, setEditingCarto] = useState(false);
  const [newBriqueName, setNewBriqueName] = useState("");
  const [newBriqueDomain, setNewBriqueDomain] = useState("");
  const [newDomainName, setNewDomainName] = useState("");
  const [aiPrompt, setAiPrompt] = useState("");

  const addDomain = () => {
    if (!newDomainName.trim()) return;
    const colors = ["#E85D7A", "#8B5CF6", "#0EA5E9", "#10B981", "#F59E0B", "#EF4444", "#3B82F6", "#94A3B8"];
    const used = [...new Set(briques.map(b => b.domain))].map(d => {
      const found = briques.find(b => b.domain === d);
      return found ? colors.find(c => c === d) : null;
    }).filter(Boolean);
    const avail = colors.find(c => !used.includes(c));
    const domainId = `dom-${Date.now()}`;
    onBriquesChange([...briques, {
      id: domainId,
      domain: newDomainName.trim(),
      label: "Nouveau domaine",
      pct: 0,
      maturity: "unknown",
    }]);
    setNewDomainName("");
  };

  const addBrique = () => {
    if (!newBriqueName.trim() || !newBriqueDomain.trim()) return;
    const domain = newBriqueDomain.trim();
    let next = [...briques];
    const existingDomain = briques.find(b => b.domain === domain);
    if (!existingDomain) {
      next.push({ id: `dom-${Date.now()}`, domain, label: domain, pct: 0, maturity: "unknown" });
    }
    next.push({ id: `brique-${Date.now()}`, domain, label: newBriqueName.trim(), pct: 0, maturity: "unknown" });
    onBriquesChange(next);
    setNewBriqueName("");
    setNewBriqueDomain("");
  };

  const handleAiPrompt = () => {
    if (!aiPrompt.trim()) return;
    const lower = aiPrompt.toLowerCase();
    const msg = `🧠 **Demande traitée** : "${aiPrompt}"\n\nAnalyse en cours... La cartographie va être ajustée selon vos instructions.`;
    setMessages(prev => [...prev, { role: "ai", text: msg, sources: [] }]);
    if (lower.includes("ajoute") || lower.includes("crée") || lower.includes("nouveau")) {
      const newB = {
        id: `ai-${Date.now()}`,
        domain: "Analyse IA",
        label: `Nouveau (${aiPrompt.slice(0, 20)}...)`,
        pct: 0,
        maturity: "unknown" as const,
      };
      onBriquesChange([...briques, newB]);
    }
    setAiPrompt("");
  };

  const adjustScore = (briqueId: string, delta: number, reason: string) => {
    onBriquesChange(briques.map(b => {
      if (b.id !== briqueId) return b;
      const newPct = Math.max(0, Math.min(100, b.pct + delta));
      const newMaturity = newPct >= 80 ? "covered" : newPct >= 50 ? "partial" : newPct >= 20 ? "obsolete" : "unknown";
      return { ...b, pct: newPct, maturity: newMaturity };
    }));
    const found = briques.find(b => b.id === briqueId);
    if (found) {
      setMessages(prev => [...prev, {
        role: "ai", text: `🔔 **Mise à jour de score** : ${reason}\n\nScore ${delta > 0 ? "augmenté" : "diminué"} de ${Math.abs(delta)}% → **${found.label}**: ${found.pct + delta}%`,
        sources: [],
        scoreDelta: { briqueId, delta, reason },
      }]);
    }
  };

  const send = () => {
    if (!input.trim()) return;
    const userMsg = input;
    setMessages(prev => [...prev, { role: "user", text: userMsg, sources: [] }]);
    setInput("");

    setTimeout(() => {
      const lower = userMsg.toLowerCase();
      let aiResponse = "Analyse en cours sur la base des documents ingérés... [Réponse simulée pour la démo]";
      let delta: { briqueId: string; delta: number; reason: string } | undefined;

      if (lower.includes("conforme") || lower.includes("bon point") || lower.includes("satisfaisant")) {
        aiResponse = "Bon point identifié ! Les éléments analysés montrent une conformité partielle. Le score de **Gouvernance SI** peut être réévalué à la hausse.";
        delta = { briqueId: "gov", delta: 10, reason: "Conformité partielle identifiée dans l'analyse détaillée" };
      } else if (lower.includes("obsolète") || lower.includes("risque") || lower.includes("vulnérabilité")) {
        aiResponse = "Vulnérabilité confirmée. L'analyse détaillée révèle des lacunes supplémentaires. Le score **Infrastructure Réseaux** doit être revu à la baisse.";
        delta = { briqueId: "infra", delta: -15, reason: "Vulnérabilités supplémentaires découvertes en analyse détaillée" };
      } else if (lower.includes("bonne") || lower.includes("bien") || lower.includes("positif")) {
        aiResponse = "Élément positif confirmé. La **Cartographie fonctionnelle** montre une bonne couverture, le score peut être ajusté à la hausse.";
        delta = { briqueId: "cartof", delta: 5, reason: "Couverture fonctionnelle validée par l'analyse détaillée" };
      } else if (lower.includes("manque") || lower.includes("absent") || lower.includes("inexistant")) {
        aiResponse = "Absence confirmée. L'analyse détaillée ne trouve pas d'élément probant. Le score **RH & Structure** doit être réduit.";
        delta = { briqueId: "rh", delta: -10, reason: "Éléments manquants confirmés en analyse détaillée" };
      }

      if (delta) {
        onBriquesChange(briques.map(b => {
          if (b.id !== delta!.briqueId) return b;
          const newPct = Math.max(0, Math.min(100, b.pct + delta!.delta));
          const newMaturity = newPct >= 80 ? "covered" : newPct >= 50 ? "partial" : newPct >= 20 ? "obsolete" : "unknown";
          return { ...b, pct: newPct, maturity: newMaturity };
        }));
      }

      setMessages(prev => [...prev, {
        role: "ai", text: aiResponse, sources: ["p.1"],
        ...(delta ? { scoreDelta: delta } : {}),
      }]);
    }, 800);
  };

  const openPage = (pageNum: number) => setSelectedPage(pageNum);

  const searchPage = () => {
    const num = parseInt(pageSearchInput.replace("p.", "").replace("p", "").trim());
    if (num >= 1 && num <= 24) openPage(num);
  };

  const totalPct = Math.round(briques.reduce((s, b) => s + b.pct, 0) / briques.length);

  return (
    <div className="h-full flex overflow-hidden" style={{ background: "#F8FAFC" }}>
      {/* LEFT — Cartography */}
      <div className="w-[45%] flex flex-col h-full" style={{ borderRight: "1px solid #E2E8F0" }}>
        {/* Header with back button */}
        <div className="px-4 py-3 flex items-center justify-between shrink-0" style={{ borderBottom: "1px solid #E2E8F0", background: "#FFFFFF" }}>
          <div className="flex items-center gap-2.5">
            <button onClick={onBack} className="w-7 h-7 rounded-lg flex items-center justify-center transition-all" style={{ background: "#F1F5F9", color: "#64748B", border: "1px solid #E2E8F0" }}
              title="Revenir à l'aperçu documentaire">
              <ChevronLeft size={14} />
            </button>
            <h4>Cartographie SI — AS-IS</h4>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setEditingCarto(!editingCarto)}
              className="text-[10px] px-2 h-6 rounded transition-all font-medium"
              style={{ background: editingCarto ? "rgba(232,93,122,0.12)" : "#F1F5F9", border: `1px solid ${editingCarto ? "#E85D7A" : "#E2E8F0"}`, color: editingCarto ? "#E85D7A" : "#64748B" }}>
              {editingCarto ? "Terminé" : "Modifier"}
            </button>
            <button onClick={() => setShowCoverage(!showCoverage)} className="cursor-pointer relative">
              <CoverageRing pct={totalPct} size={40} />
            </button>
            <span className="text-xs" style={{ color: "#64748B" }}>{totalPct}% couvert</span>
          </div>
        </div>

        {showCoverage && (
          <div className="px-4 py-3 shrink-0" style={{ background: "#FFFFFF", borderBottom: "1px solid #E2E8F0" }}>
            <p className="text-xs mb-2" style={{ color: "#64748B" }}>Couverture par brique :</p>
            <div className="space-y-1.5">
              {[...briques].sort((a, b) => a.pct - b.pct).map(b => (
                <div key={b.id} className="flex items-center gap-2">
                  <span className="text-xs w-36 truncate" style={{ color: "#64748B" }}>{b.label}</span>
                  <div className="flex-1 h-2 rounded-full" style={{ background: "#E2E8F0" }}>
                    <div className="h-full rounded-full transition-all" style={{ width: `${b.pct}%`, background: maturityColors[b.maturity] }} />
                  </div>
                  <span className="text-[11px] w-7 text-right" style={{ color: "#94A3B8", fontFamily: "JetBrains Mono, monospace" }}>{b.pct}%</span>
                </div>
              ))}
            </div>
            <button onClick={onNext} className="mt-3 w-full h-8 rounded-md text-xs font-medium" style={{ background: "#E85D7A", color: "white" }}>
              Identifier les ateliers nécessaires →
            </button>
          </div>
        )}

        <div className="flex-1 overflow-y-auto p-4">
          {[...new Set(briques.map(b => b.domain))].map(domain => (
            <div key={domain} className="mb-4">
              <div className="flex items-center justify-between mb-2 px-2">
                <p className="text-[11px] uppercase tracking-widest" style={{ color: "#94A3B8" }}>{domain}</p>
                <span className="text-[10px]" style={{ color: "#94A3B8", fontFamily: "JetBrains Mono, monospace" }}>
                  {Math.round(briques.filter(b => b.domain === domain).reduce((s, b) => s + b.pct, 0) / Math.max(1, briques.filter(b => b.domain === domain).length))}% moy.
                </span>
              </div>
              {briques.filter(b => b.domain === domain).map(b => {
                const isSelected = b.id === selectedBrique;
                const lastDelta = messages.filter(m => m.scoreDelta?.briqueId === b.id).pop()?.scoreDelta;
                const contribFacts = briqueFactMap[b.id] || [];
                const isFactExpanded = expandedFacts === b.id;
                return (
                  <div key={b.id}>
                    <div
                      className="group flex items-center gap-2.5 px-3 py-2.5 rounded-lg mb-0.5 cursor-pointer transition-all"
                      style={{
                        background: isSelected ? "rgba(232,93,122,0.1)" : "#FFFFFF",
                        border: `1px solid ${isSelected ? "#E85D7A" : "#E2E8F0"}`,
                        borderLeftWidth: 3,
                        borderLeftColor: maturityColors[b.maturity],
                      }}
                      onClick={() => setSelectedBrique(b.id)}>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <p className="text-xs font-medium" style={{ color: "#0F172A" }}>{b.label}</p>
                          {lastDelta && (
                            <span className={`text-[10px] font-medium ${lastDelta.delta > 0 ? "text-green-600" : "text-red-500"}`}>
                              ({lastDelta.delta > 0 ? "+" : ""}{lastDelta.delta}%)
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <div className="h-1.5 w-20 rounded-full" style={{ background: "#E2E8F0" }}>
                            <div className="h-full rounded-full transition-all duration-500" style={{ width: `${b.pct}%`, background: maturityColors[b.maturity] }} />
                          </div>
                          <span className="text-[10px]" style={{ color: "#94A3B8", fontFamily: "JetBrains Mono, monospace" }}>{b.pct}%</span>
                          {/* Quick adjust buttons */}
                          <div className="flex gap-0.5 opacity-0 group-hover:opacity-100 transition-all">
                            <button onClick={e => { e.stopPropagation(); adjustScore(b.id, 5, "Ajustement manuel — information confirmée"); }}
                              className="w-5 h-5 rounded flex items-center justify-center transition-all" style={{ background: "rgba(16,185,129,0.1)", color: "#10B981" }}>
                              <Plus size={10} />
                            </button>
                            <button onClick={e => { e.stopPropagation(); adjustScore(b.id, -5, "Ajustement manuel — information à revoir"); }}
                              className="w-5 h-5 rounded flex items-center justify-center transition-all" style={{ background: "rgba(239,68,68,0.1)", color: "#EF4444" }}>
                              <Minus size={10} />
                            </button>
                          </div>
                        </div>
                        {contribFacts.length > 0 && (
                          <div className="flex items-center gap-0.5 mt-1">
                            <button onClick={e => { e.stopPropagation(); setExpandedFacts(isFactExpanded ? null : b.id); }}
                              className="text-[10px] px-1.5 py-0.5 rounded transition-all flex items-center gap-1"
                              style={{ background: "rgba(139,92,246,0.08)", border: "1px solid rgba(139,92,246,0.15)", color: "#7C3AED" }}>
                              <span>{contribFacts.length} fait{contribFacts.length > 1 ? "s" : ""} source{contribFacts.length > 1 ? "s" : ""}</span>
                              <span style={{ fontSize: 8 }}>{isFactExpanded ? "▲" : "▼"}</span>
                            </button>
                            <span className="text-[9px]" style={{ color: "#94A3B8" }}>Voir aperçu</span>
                          </div>
                        )}
                      </div>
                      <button className="text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-all"
                        style={{ background: "rgba(245,158,11,0.1)", color: "#F59E0B", border: "1px solid rgba(245,158,11,0.2)" }}>
                        ⚖️ Valider
                      </button>
                    </div>
                    {isFactExpanded && contribFacts.length > 0 && (
                      <div className="ml-6 mb-1.5 p-2 rounded-md" style={{ background: "rgba(139,92,246,0.04)", border: "1px solid rgba(139,92,246,0.1)" }}>
                        <p className="text-[9px] uppercase tracking-wider mb-1" style={{ color: "#94A3B8" }}>Faits issus de l'aperçu documentaire</p>
                        {contribFacts.map((f, fi) => (
                          <div key={fi} className="flex items-center gap-1.5 text-[10px] py-0.5" style={{ color: "#64748B" }}>
                            <span className="w-1 h-1 rounded-full shrink-0" style={{ background: "#7C3AED" }} />
                            <span className="flex-1 truncate">{f.label}</span>
                            <span className="text-[9px]" style={{ color: "#94A3B8" }}>{f.source}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
              {/* Ajouter une brique — visible en mode édition */}
              {editingCarto && (
                <div className="flex items-center gap-1.5 mt-2 pl-3">
                  <input value={newBriqueName} onChange={e => setNewBriqueName(e.target.value)}
                    placeholder="Nom de la brique"
                    className="h-7 px-2 rounded text-[11px] outline-none flex-1"
                    style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#0F172A" }}
                    onFocus={e => e.currentTarget.style.borderColor = "#E85D7A"}
                    onBlur={e => e.currentTarget.style.borderColor = "#E2E8F0"} />
                  <input value={newBriqueDomain} onChange={e => setNewBriqueDomain(e.target.value)}
                    placeholder="Domaine"
                    className="h-7 w-24 px-2 rounded text-[11px] outline-none"
                    style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#0F172A" }}
                    onFocus={e => e.currentTarget.style.borderColor = "#E85D7A"}
                    onBlur={e => e.currentTarget.style.borderColor = "#E2E8F0"} />
                  <button onClick={addBrique}
                    className="flex items-center gap-1 px-2.5 h-7 rounded text-[10px] font-medium text-white shrink-0"
                    style={{ background: "#E85D7A" }}>
                    <Plus size={10} /> Ajouter
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
        <div className="px-4 py-3 shrink-0" style={{ borderTop: "1px solid #E2E8F0" }}>
          {editingCarto ? (
            <div className="flex items-center gap-1.5">
              <input value={newDomainName} onChange={e => setNewDomainName(e.target.value)}
                placeholder="Nom du nouveau domaine"
                className="flex-1 h-7 px-2 rounded text-[11px] outline-none"
                style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#0F172A" }}
                onFocus={e => e.currentTarget.style.borderColor = "#E85D7A"}
                onBlur={e => e.currentTarget.style.borderColor = "#E2E8F0"}
                onKeyDown={e => e.key === "Enter" && addDomain()} />
              <button onClick={addDomain}
                className="flex items-center gap-1 px-2.5 h-7 rounded text-[10px] font-medium"
                style={{ background: "#F1F5F9", border: "1px dashed #CBD5E1", color: "#64748B" }}>
                <Plus size={10} /> Ajouter un domaine
              </button>
            </div>
          ) : (
            <div className="flex items-center justify-between">
              <MaturityLegend />
              <button onClick={() => onBriquesChange(briques.map(b => ({ ...b, pct: b.pct + 1 })))}
                className="text-[10px] px-2 py-1 rounded transition-all" style={{ border: "1px solid #E2E8F0", color: "#94A3B8", background: "#FFFFFF" }}>
                <RotateCcw size={10} className="inline mr-1" />Rafraîchir
              </button>
            </div>
          )}
        </div>
      </div>

      {/* RIGHT — Chat + Page Viewer */}
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {/* Header */}
        <div className="px-4 py-3 flex items-center justify-between shrink-0" style={{ borderBottom: "1px solid #E2E8F0", background: "#FFFFFF" }}>
          <div>
            <p className="text-sm font-semibold" style={{ color: "#0F172A" }}>Infra_réseau_mapping_v3.pptx</p>
            <p className="text-xs mt-0.5" style={{ color: "#94A3B8", fontFamily: "JetBrains Mono, monospace" }}>24 pages · 🎯 Ciblage actif: p.3, p.7, p.12</p>
          </div>
          <div className="flex items-center gap-2">
            <AIActionButton onClick={() => setShowSuggestions(!showSuggestions)}>
              Suggestions IA
            </AIActionButton>
          </div>
        </div>

        {/* Page search bar */}
        <div className="px-4 py-2 shrink-0 flex items-center gap-2" style={{ background: "#FFFFFF", borderBottom: "1px solid #E2E8F0" }}>
          <Search size={13} style={{ color: "#94A3B8" }} />
          <input value={pageSearchInput} onChange={e => setPageSearchInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && searchPage()}
            placeholder="Rechercher une page (ex: p.3, 7, 12)..."
            className="flex-1 bg-transparent outline-none text-xs" style={{ color: "#0F172A" }} />
          <span className="text-[11px]" style={{ color: "#94A3B8", fontFamily: "JetBrains Mono, monospace" }}>1-24</span>
        </div>

        {/* Content area: either page viewer or chat */}
        {selectedPage !== null && pageContents[selectedPage] ? (
          <div className="flex-1 overflow-y-auto p-4" style={{ background: "#FFFFFF" }}>
            <button onClick={() => setSelectedPage(null)}
              className="flex items-center gap-1.5 text-xs mb-4 transition-all" style={{ color: "#E85D7A" }}>
              <ArrowLeft size={14} /> Retour au chat
            </button>
            <div className="rounded-xl p-5" style={{ background: "#F8FAFC", border: "1px solid #E2E8F0" }}>
              <div className="flex items-center gap-2 mb-4">
                <FileText size={16} style={{ color: "#E85D7A" }} />
                <span className="text-sm font-semibold" style={{ color: "#0F172A" }}>{pageContents[selectedPage].title}</span>
                <span className="text-[11px] px-2 py-0.5 rounded" style={{ background: "rgba(232,93,122,0.1)", color: "#E85D7A", fontFamily: "JetBrains Mono, monospace" }}>
                  Page {selectedPage}/24
                </span>
              </div>
              <p className="text-sm leading-relaxed mb-4" style={{ color: "#334155" }}>{pageContents[selectedPage].content}</p>
              {pageContents[selectedPage].highlights && (
                <div className="rounded-lg p-3" style={{ background: "rgba(139,92,246,0.06)", border: "1px solid rgba(139,92,246,0.15)" }}>
                  <p className="text-[11px] font-semibold mb-2" style={{ color: "#8B5CF6" }}>Points clés</p>
                  <ul className="space-y-1">
                    {pageContents[selectedPage].highlights!.map((h, hi) => (
                      <li key={hi} className="text-xs flex items-start gap-2" style={{ color: "#64748B" }}>
                        <span className="shrink-0 mt-1 w-1.5 h-1.5 rounded-full" style={{ background: "#8B5CF6" }} />
                        {h}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        ) : selectedPage !== null ? (
          <div className="flex-1 flex items-center justify-center" style={{ background: "#FFFFFF" }}>
            <button onClick={() => setSelectedPage(null)}
              className="flex items-center gap-1.5 text-xs transition-all" style={{ color: "#E85D7A" }}>
              <ArrowLeft size={14} /> Retour au chat
            </button>
            <p className="text-sm ml-4" style={{ color: "#94A3B8" }}>Contenu non disponible pour cette page</p>
          </div>
        ) : (
          <>
            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {messages.map((m, i) => (
                <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                  {m.role === "ai" && (
                    <div className="max-w-[85%]">
                      <div className="rounded-xl px-4 py-3 text-sm leading-relaxed"
                        style={{ background: "#FFFFFF", border: "1px solid #8B5CF633", borderLeft: "3px solid #8B5CF6", color: "#0F172A", whiteSpace: "pre-wrap" }}>
                        <div className="flex items-center gap-2 mb-2">
                          <AIBadge />
                          {m.scoreDelta && (
                            <span className={`flex items-center gap-0.5 text-[10px] px-1.5 py-0.5 rounded ${
                              m.scoreDelta.delta > 0 ? "text-green-700 bg-green-50" : "text-red-700 bg-red-50"
                            }`} style={{ border: `1px solid ${m.scoreDelta.delta > 0 ? "#10B981" : "#EF4444"}30` }}>
                              {m.scoreDelta.delta > 0 ? "+" : ""}{m.scoreDelta.delta}%
                            </span>
                          )}
                        </div>
                        {m.text}
                        {m.sources && m.sources.length > 0 && (
                          <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                            {m.sources.map(s => {
                              const pageNum = parseInt(s.replace("p.", ""));
                              return (
                                <button key={s} onClick={() => openPage(pageNum)}
                                  className="text-[11px] px-1.5 py-0.5 rounded cursor-pointer transition-all"
                                  style={{ background: "rgba(232,93,122,0.15)", color: "#E85D7A", fontFamily: "JetBrains Mono, monospace" }}
                                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(232,93,122,0.25)"; }}
                                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(232,93,122,0.15)"; }}>
                                  {s}
                                </button>
                              );
                            })}
                          </div>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-1.5 ml-1">
                        <button className="text-[11px] transition-all" style={{ color: "#94A3B8" }}
                          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.color = "#64748B"; }}
                          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.color = "#94A3B8"; }}>
                          📋 Copier
                        </button>
                        <button className="text-[11px] transition-all" style={{ color: "#94A3B8" }}
                          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.color = "#10B981"; }}
                          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.color = "#94A3B8"; }}>
                          🗺️ Ajouter à la cartographie
                        </button>
                      </div>
                    </div>
                  )}
                  {m.role === "user" && (
                    <div className="max-w-[75%] px-4 py-2.5 rounded-xl text-sm" style={{ background: "#E85D7A", color: "white" }}>
                      {m.text}
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Input */}
            <div className="px-4 py-3 shrink-0" style={{ borderTop: "1px solid #E2E8F0", background: "#FFFFFF" }}>
              <div className="flex gap-2">
                <div className="flex-1 flex items-center gap-2 px-3 rounded-md" style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", height: 36 }}>
                  <input value={input} onChange={e => setInput(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && send()}
                    placeholder="Posez une question sur ce document..."
                    className="flex-1 bg-transparent outline-none text-sm" style={{ color: "#0F172A" }} />
                </div>
                <button className="w-9 h-9 rounded-md flex items-center justify-center transition-all" style={{ background: "#E85D7A", color: "white" }} onClick={send}>
                  <Send size={14} />
                </button>
              </div>
              <div className="flex gap-2 mt-2 flex-wrap">
                {suggestions.map((s, i) => (
                  <button key={i} onClick={() => setInput(s)}
                    className="text-[11px] px-2.5 py-1 rounded-full transition-all"
                    style={{ background: "#F1F5F9", border: "1px solid #E2E8F0", color: "#64748B" }}
                    onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = "#94A3B8"; }}
                    onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "#E2E8F0"; }}>
                    {s}
                  </button>
                ))}
              </div>
            </div>

            {/* AI Prompt for cartography modification */}
            <div className="px-4 py-3 shrink-0" style={{ borderTop: "1px solid #E2E8F0", background: "#F8FAFC" }}>
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: "#8B5CF6" }}>🧠 Modifier la cartographie</span>
                <span className="text-[9px]" style={{ color: "#94A3B8" }}>langage naturel</span>
              </div>
              <textarea value={aiPrompt} onChange={e => setAiPrompt(e.target.value)}
                rows={2} placeholder="Ex: 'Ajoute une brique Sécurité dans le domaine Technique avec score 30%'"
                className="w-full text-xs px-2.5 py-2 rounded-md resize-none outline-none mb-2"
                style={{ background: "#FFFFFF", border: "1px solid #E2E8F0", color: "#0F172A" }}
                onFocus={e => e.currentTarget.style.borderColor = "#8B5CF6"}
                onBlur={e => e.currentTarget.style.borderColor = "#E2E8F0"}
                onKeyDown={e => { if (e.key === "Enter" && e.shiftKey) { e.preventDefault(); handleAiPrompt(); } }} />
              <div className="flex items-center justify-between">
                <div className="flex gap-1">
                  {["Ajoute une brique Sécurité", "Crée un domaine Pilotage", "Ajuste le score RH à 50%"].map(chip => (
                    <button key={chip} onClick={() => setAiPrompt(chip)}
                      className="text-[9px] px-1.5 py-1 rounded transition-all"
                      style={{ background: "rgba(139,92,246,0.08)", border: "1px solid rgba(139,92,246,0.15)", color: "#8B5CF6" }}>
                      {chip}
                    </button>
                  ))}
                </div>
                <button onClick={handleAiPrompt}
                  className="flex items-center gap-1 px-3 h-7 rounded text-[10px] font-medium"
                  style={{ background: "rgba(139,92,246,0.15)", border: "1px solid rgba(139,92,246,0.3)", color: "#8B5CF6" }}>
                  Appliquer
                </button>
              </div>
            </div>
          </>
        )}

        {/* Bottom status bar */}
        <div className="px-4 py-2 flex items-center gap-4 shrink-0 text-xs" style={{ background: "#F8FAFC", borderTop: "1px solid #E2E8F0", color: "#94A3B8", fontFamily: "JetBrains Mono, monospace" }}>
          <button onClick={onBack} className="flex items-center gap-1 transition-all" style={{ color: "#E85D7A" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.color = "#BE4D6A"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.color = "#E85D7A"; }}>
            <ChevronLeft size={12} /> Retour aperçu
          </button>
          <span>·</span>
          <span>Page {selectedPage || 1}/24</span>
          <span>·</span>
          <span style={{ color: "#8B5CF6" }}>🔁 Instance 2/7 documents</span>
          <span>·</span>
          <span style={{ color: "#D97706" }}>Scores préliminaires: {totalPct}%</span>
          <div className="flex-1" />
          <button onClick={onNext}
            className="flex items-center gap-1.5 px-4 h-8 rounded-md text-xs font-medium transition-all"
            style={{ background: "#E85D7A", color: "white" }}>
            Analyse d'écart GAP <ChevronRight size={12} />
          </button>
        </div>
      </div>
    </div>
  );
}
