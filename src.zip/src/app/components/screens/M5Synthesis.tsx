import { useState, useEffect } from "react";
import { Sparkles, ChevronRight, X, Archive, CheckCircle, MessageSquare, Plus, Send, ChevronLeft } from "lucide-react";
import { AIBadge, GoldButton, GhostButton, MaturityLegend, AIActionButton, CoverageRing, ShareableLink } from "../ui-kit";
import type { CartoBrique } from "../../App";

const maturityColors: Record<string, string> = {
  covered: "#10B981", partial: "#F59E0B", obsolete: "#EF4444", unknown: "#6B7280",
};

const STATUTS: Record<string, { label: string; couleur: string }> = {
  non_couvert: { label: "Non couvert", couleur: "#EF4444" },
  partiel: { label: "Partiellement couvert", couleur: "#F59E0B" },
  couvert: { label: "Couvert", couleur: "#10B981" },
};

// ---- Nouvelle structure alignée cartographie final ----
function flattenCartoBriques(bForce?: typeof cartographie): { nom: string; statut: string; domaine: string }[] {
  const c = bForce || cartographie;
  const r: { nom: string; statut: string; domaine: string }[] = [];
  for (const col of c.colonnesLaterales)
    for (const b of col.briques) r.push({ ...b, domaine: col.titre });
  for (const d of c.domainesCentraux) {
    if (d.briques) for (const b of d.briques) r.push({ ...b, domaine: d.titre });
    if (d.sousDomaines)
      for (const sd of d.sousDomaines)
        for (const b of sd.briques) r.push({ ...b, domaine: sd.titre });
  }
  return r;
}

function briquesForDomain(domainId: string): string[] {
  const col = cartographie.colonnesLaterales.find(c => c.id === domainId);
  if (col) return col.briques.map(b => b.nom);
  const dc = cartographie.domainesCentraux.find(d => d.id === domainId);
  if (!dc) return [];
  const names: string[] = [];
  if (dc.briques) names.push(...dc.briques.map(b => b.nom));
  if (dc.sousDomaines)
    for (const sd of dc.sousDomaines)
      names.push(...sd.briques.map(b => b.nom));
  return names;
}

const cartographie = {
  colonnesLaterales: [
    {
      id: "support", titre: "Support",
      briques: [
        { nom: "Achats et Stocks", statut: "non_couvert" },
        { nom: "Juridique", statut: "non_couvert" },
        { nom: "Comptabilité", statut: "partiel" },
        { nom: "Ressources Humaines", statut: "partiel" },
        { nom: "Bureau d'ordre", statut: "non_couvert" },
      ],
    },
    {
      id: "referentiel", titre: "Référentiel",
      briques: [
        { nom: "Banques", statut: "non_couvert" },
        { nom: "SFD", statut: "non_couvert" },
        { nom: "Bailleurs de fonds", statut: "non_couvert" },
      ],
    },
  ],
  domainesCentraux: [
    {
      id: "canaux", titre: "Canaux de communication",
      briques: [
        { nom: "Site web", statut: "partiel" },
        { nom: "Réseaux Sociaux", statut: "non_couvert" },
      ],
    },
    {
      id: "pilotage", titre: "Pilotage et Reporting",
      briques: [
        { nom: "Risques", statut: "non_couvert" },
        { nom: "Conformité", statut: "non_couvert" },
        { nom: "Contrôle Permanent", statut: "non_couvert" },
        { nom: "Contrôle de Gestion", statut: "non_couvert" },
        { nom: "Audit", statut: "non_couvert" },
      ],
    },
    {
      id: "chaine_valeur", titre: "Chaîne de valeur",
      sousDomaines: [
        { titre: "Refinancement", briques: [{ nom: "Refinancement sur ressources concessionnelles", statut: "non_couvert" }, { nom: "Refinancement sur ressources du marché", statut: "non_couvert" }] },
        { titre: "Titrisation", briques: [{ nom: "Titrisation", statut: "non_couvert" }] },
        { titre: "Garanties", briques: [{ nom: "Garanties", statut: "non_couvert" }] },
        { titre: "Finance et Trésorerie", briques: [{ nom: "Pilotage des ressources financières", statut: "non_couvert" }] },
      ],
    },
    {
      id: "gestion_si", titre: "Gestion du SI",
      briques: [
        { nom: "Gestion de la sécurité", statut: "partiel" },
        { nom: "Administration des infrastructures", statut: "partiel" },
        { nom: "Réseaux et Téléphonie", statut: "partiel" },
        { nom: "Gestion des services", statut: "non_couvert" },
        { nom: "Gestion des collaboratifs", statut: "couvert" },
        { nom: "Gestion des échanges", statut: "non_couvert" },
      ],
    },
  ],
};

function getBriqueStatut(nomBrique: string): string {
  for (const col of cartographie.colonnesLaterales) {
    for (const b of col.briques) if (b.nom === nomBrique) return b.statut;
  }
  for (const d of cartographie.domainesCentraux) {
    if (d.briques) for (const b of d.briques) if (b.nom === nomBrique) return b.statut;
    if (d.sousDomaines) for (const sd of d.sousDomaines) for (const b of sd.briques) if (b.nom === nomBrique) return b.statut;
  }
  console.warn(`Brique "${nomBrique}" introuvable dans cartographie`);
  return "non_couvert";
}

const m1Domains = [
  { id: "support",       label: "Support",              icon: "🏗️", color: "#E85D7A", description: "Achats, Juridique, Compta, RH, Bureau d'ordre" },
  { id: "canaux",        label: "Canaux",               icon: "📡", color: "#8B5CF6", description: "Site web, Réseaux Sociaux" },
  { id: "pilotage",      label: "Pilotage & Reporting", icon: "📊", color: "#0EA5E9", description: "Risques, Conformité, Audit, Contrôle" },
  { id: "chaine_valeur", label: "Chaîne de valeur",     icon: "🔗", color: "#10B981", description: "Refinancement, Titrisation, Garanties, Trésorerie" },
  { id: "gestion_si",    label: "Gestion du SI",        icon: "💻", color: "#F59E0B", description: "Sécurité, Infra, Réseaux, Services" },
  { id: "referentiel",   label: "Référentiel",          icon: "📚", color: "#94A3B8", description: "Banques, SFD, Bailleurs" },
];

const domainBriqueIds: Record<string, string[]> = {};
for (const d of m1Domains) domainBriqueIds[d.id] = briquesForDomain(d.id);

// Synthesis data per brique (same structure as before)
const defaultSynthData: Record<string, { obs: string[]; constats: string[]; besoins: string[] }> = {
  gov: {
    obs: ["Le comité SI se réunit trimestriellement sans ordre du jour formalisé", "Absence de RACI documenté entre DSI et directions métier", "Roadmap SI non synchronisée avec le plan stratégique"],
    constats: ["Gouvernance SI insuffisamment formalisée face aux exigences BCT", "Pas de reporting SI vers le Conseil d'Administration"],
    besoins: ["Mise en place d'un comité SI mensuel avec reporting structuré", "Formalisation d'un RACI DSI / Métier"],
  },
  rh: {
    obs: ["Organisation DSI partiellement documentée", "Pas de plan de relève pour les postes clés"],
    constats: ["Turnover de 8% sans plan de rétention formalisé"],
    besoins: ["Établir un plan de succession pour les postes critiques"],
  },
  infra: {
    obs: ["Le réseau repose sur une architecture hub-and-spoke datant de 2018", "Aucune redondance WAN sur les sites secondaires", "Équipements Cisco en fin de support (EOL 2025)", "Backup LTO-6 sans test de restauration depuis 2021"],
    constats: ["Infrastructure réseau sous-dimensionnée face à la croissance", "Risque opérationnel majeur lié à l'absence de PCA testé", "Aucune solution de reprise après sinistre"],
    besoins: ["Mise à niveau du backbone réseau (MPLS → SD-WAN)", "Mise en place d'une architecture de redondance N+1"],
  },
  secu: {
    obs: ["Politique IAM non révisée depuis 2021", "Absence de MFA déployé", "Pas de solution SIEM en production", "Procédure de réponse aux incidents non formalisée"],
    constats: ["Non-conformité partielle aux exigences BCT sur la sécurité", "Pas de SOC (Security Operations Center)"],
    besoins: ["Déploiement d'un SOC et d'une solution SIEM", "Mise en place de MFA pour tous les accès distants"],
  },
  cartof: {
    obs: ["Cartographie fonctionnelle partiellement documentée", "Flux inter-applicatifs non cartographiés"],
    constats: ["La cartographie n'a pas été mise à jour depuis 2022", "Dépendances critiques non identifiées formellement"],
    besoins: ["Mise à jour complète de la cartographie fonctionnelle", "Cartographie des flux et dépendances inter-systèmes"],
  },
  cartoa: {
    obs: ["Inventaire applicatif partiel (47 apps recensées)", "Applications legacy sans plan de migration"],
    constats: ["12 applications critiques sans PCA dédié", "Taux de virtualisation à 78% — potentiel d'optimisation"],
    besoins: ["Plan de migration des applications legacy", "Établir un PCA applicatif pour les 12 apps critiques"],
  },
};

// Augment with all cartography briques (empty data for new ones)
const allSynthData: Record<string, { obs: string[]; constats: string[]; besoins: string[] }> = { ...defaultSynthData };
const oldToCartoMap: Record<string, string> = {
  gov: "Risques", rh: "Ressources Humaines", infra: "Administration des infrastructures",
  secu: "Gestion de la sécurité",
};
for (const [k, label] of Object.entries(oldToCartoMap)) {
  if (defaultSynthData[k]) allSynthData[label] = defaultSynthData[k];
}
for (const b of flattenCartoBriques()) {
  if (!allSynthData[b.nom]) allSynthData[b.nom] = { obs: [], constats: [], besoins: [] };
}

function getStatutCouleur(nomBrique: string): string {
  const s = getBriqueStatut(nomBrique);
  return STATUTS[s]?.couleur || "#9CA3AF";
}

function BriqueCard({ brique, onClick }: { brique: { nom: string; statut: string }; onClick?: () => void }) {
  const s = STATUTS[brique.statut];
  if (!s) console.warn(`Statut inconnu: "${brique.statut}" pour "${brique.nom}"`);
  return (
    <div className="rounded-lg px-3 py-2 text-center text-xs font-bold text-white cursor-pointer transition-all"
      style={{ background: s?.couleur || "#9CA3AF" }}
      onClick={onClick}
      onMouseEnter={e => { e.currentTarget.style.filter = "brightness(1.1)"; e.currentTarget.style.boxShadow = "0 2px 8px rgba(0,0,0,0.15)"; }}
      onMouseLeave={e => { e.currentTarget.style.filter = "none"; e.currentTarget.style.boxShadow = "none"; }}>
      {brique.nom}
    </div>
  );
}

function SousDomainGroup({ sousDomaine, onBriqueClick }: { sousDomaine: { titre: string; briques: { nom: string; statut: string }[] }; onBriqueClick: (nom: string) => void }) {
  return (
    <div className="flex-1">
      <p className="text-xs font-bold mb-1" style={{ color: "#E84260" }}>{sousDomaine.titre}</p>
      <div className="space-y-1">
        {sousDomaine.briques.map((b, i) => <BriqueCard key={i} brique={b} onClick={() => onBriqueClick(b.nom)} />)}
      </div>
    </div>
  );
}

function DomainBand({ domaine, onBriqueClick }: { domaine: typeof cartographie.domainesCentraux[0]; onBriqueClick: (nom: string) => void }) {
  return (
    <div className="rounded-lg p-4" style={{ background: "#F2F2F2" }}>
      <h4 className="font-bold mb-3" style={{ color: "#E84260", fontSize: 14 }}>{domaine.titre}</h4>
      {domaine.sousDomaines ? (
        <div className="flex gap-3">
          {domaine.sousDomaines.map((sd, i) => <SousDomainGroup key={i} sousDomaine={sd} onBriqueClick={onBriqueClick} />)}
        </div>
      ) : (
        <div className="flex flex-wrap gap-2">
          {domaine.briques?.map((b, i) => <BriqueCard key={i} brique={b} onClick={() => onBriqueClick(b.nom)} />)}
        </div>
      )}
    </div>
  );
}

function DomainColumn({ domaine, onBriqueClick }: { domaine: typeof cartographie.colonnesLaterales[0]; onBriqueClick: (nom: string) => void }) {
  return (
    <div className="rounded-lg p-4 flex flex-col gap-2" style={{ background: "#F2F2F2" }}>
      <h4 className="font-bold text-center" style={{ color: "#E84260", fontSize: 14 }}>{domaine.titre}</h4>
      {domaine.briques.map((b, i) => <BriqueCard key={i} brique={b} onClick={() => onBriqueClick(b.nom)} />)}
    </div>
  );
}

function Legende() {
  return (
    <div className="flex items-center gap-6 px-1">
      {Object.entries(STATUTS).map(([key, s]) => (
        <div key={key} className="flex items-center gap-2 text-xs" style={{ color: "#374151" }}>
          <span className="inline-block w-3 h-3 rounded-full" style={{ background: s.couleur }} />
          {s.label}
        </div>
      ))}
    </div>
  );
}

const sectionTitles = { obs: "Observations", constats: "Constats", besoins: "Besoins" } as const;
type SectionKey = keyof typeof sectionTitles;

interface ClientComment {
  id: number;
  briqueId: string;
  section: SectionKey;
  itemIdx: number;
  text: string;
  authorInitials: string;
  authorName: string;
  date: string;
}

interface M5SynthesisProps {
  briques: CartoBrique[];
  onBriquesChange: (b: CartoBrique[]) => void;
  onNext: () => void;
}

export function M5Synthesis({ briques, onBriquesChange, onNext }: M5SynthesisProps) {
  const [activeView, setActiveView] = useState<"draft" | "split" | "carto" | "share" | "success">("draft");
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [aiPrompt, setAiPrompt] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);
  const [archiving, setArchiving] = useState(false);
  const [shareStatus, setShareStatus] = useState<"waiting" | "validated">("waiting");
  const [notified, setNotified] = useState(false);
  const [clientRemarks, setClientRemarks] = useState([
    { id: 1, initials: "KB", name: "Khalil Ben Ali", text: "Pouvez-vous détailler le plan d'action pour l'infrastructure réseau ? Les délais nous semblent trop courts.", date: "12 juin 2026", section: "Infrastructure Réseaux", resolved: false },
    { id: 2, initials: "KB", name: "Khalil Ben Ali", text: "OK pour la partie Gouvernance SI, nous validons les constats.", date: "11 juin 2026", section: "Gouvernance SI", resolved: true },
    { id: 3, initials: "KB", name: "Khalil Ben Ali", text: "Quel est le périmètre exact de la cartographie applicative ? Certaines applications legacy ne sont pas listées.", date: "11 juin 2026", section: "Cartographie applic.", resolved: false },
  ]);

  // Comment popup state
  const [commentPopup, setCommentPopup] = useState<{
    briqueId: string; section: SectionKey; itemIdx: number; x: number; y: number; itemText: string; source: "consultant" | "client";
  } | null>(null);
  const [commentText, setCommentText] = useState("");
  const [allComments, setAllComments] = useState<ClientComment[]>([]);

  // Synthesis popup state
  const [synthPopup, setSynthPopup] = useState<{ briqueId: string; label: string; domain: string } | null>(null);

  const addComment = () => {
    if (!commentPopup || !commentText.trim()) return;
    const now = new Date().toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" });
    const isFromClient = commentPopup.source === "client";
    const c: ClientComment = {
      id: Date.now(),
      briqueId: commentPopup.briqueId,
      section: commentPopup.section,
      itemIdx: commentPopup.itemIdx,
      text: commentText,
      authorInitials: isFromClient ? "CL" : "MO",
      authorName: isFromClient ? "Client" : "Moi (Consultant)",
      date: now,
    };
    setAllComments(prev => [...prev, c]);
    if (isFromClient) {
      const sectionLabel = sectionTitles[commentPopup.section as SectionKey] || "Synthèse";
      setClientRemarks(prev => [...prev, {
        id: Date.now() + 1,
        initials: "CL",
        name: "Client",
        text: `💬 ${commentText}`,
        date: now,
        section: `${commentPopup.briqueId} › ${sectionLabel}`,
        resolved: false,
      }]);
    }
    setCommentText("");
    setCommentPopup(null);
  };

  const handleSuccess = () => {
    setArchiving(true);
    setTimeout(() => {
      setArchiving(false);
      setShowSuccess(true);
    }, 2400);
  };

  const resolveRemark = (id: number) => {
    setClientRemarks(prev => prev.map(r => r.id === id ? { ...r, resolved: true } : r));
  };

  const notifyClient = () => {
    setNotified(true);
    setShareStatus("waiting");
    setTimeout(() => setNotified(false), 2000);
  };

  const getSynthData = (briqueId: string) =>
    allSynthData[briqueId] || { obs: [], constats: [], besoins: [] };

  if (showSuccess) {
    return <SuccessModal />;
  }

  return (
    <>
    {archiving && <ArchivingOverlay />}

    {/* Synthesis popup */}
    {synthPopup && (() => {
      const data = getSynthData(synthPopup.briqueId);
      return (
        <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: "rgba(15,17,23,0.7)" }}
          onClick={() => setSynthPopup(null)}>
          <div className="rounded-xl w-[520px] max-h-[80vh] flex flex-col" style={{ background: "#FFFFFF", boxShadow: "0 20px 60px rgba(0,0,0,0.25)" }}
            onClick={e => e.stopPropagation()}>
            <div className="px-5 py-4 flex items-center justify-between shrink-0" style={{ borderBottom: "1px solid #E2E8F0" }}>
              <div>
                <h3 className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ background: getStatutCouleur(synthPopup.briqueId) }} />
                  {synthPopup.label}
                </h3>
                <p className="text-xs" style={{ color: "#94A3B8" }}>{synthPopup.domain}</p>
              </div>
              <button onClick={() => setSynthPopup(null)} className="w-7 h-7 rounded-md flex items-center justify-center" style={{ background: "#F1F5F9", color: "#94A3B8" }}>
                <X size={13} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {(Object.keys(sectionTitles) as SectionKey[]).map(sk => {
                const items = data[sk];
                if (items.length === 0) return null;
                return (
                  <div key={sk}>
                    <h4 className="text-xs font-semibold mb-2 flex items-center gap-2" style={{ color: "#0F172A" }}>
                      {sectionTitles[sk]}
                      <span className="text-[10px] font-normal" style={{ color: "#94A3B8" }}>({items.length})</span>
                    </h4>
                    <ul className="space-y-1">
                      {items.map((item, ii) => {
                        const hasComment = allComments.some(c => c.briqueId === synthPopup.briqueId && c.section === sk && c.itemIdx === ii);
                        return (
                          <li key={ii} className="group flex items-start gap-2 px-2 py-1.5 rounded-md cursor-pointer transition-all"
                            style={{ color: "#64748B", background: hasComment ? "rgba(139,92,246,0.04)" : "transparent" }}
                            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#F8FAFC"; }}
                            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = hasComment ? "rgba(139,92,246,0.04)" : "transparent"; }}
                            onClick={() => setCommentPopup({
                              briqueId: synthPopup.briqueId, section: sk, itemIdx: ii,
                              x: 0, y: 0, itemText: item, source: "consultant"
                            })}>
                            <span className="w-1 h-1 rounded-full shrink-0 mt-2" style={{ background: "#CBD5E1" }} />
                            <span className="flex-1 text-xs">{item}</span>
                            <button className="opacity-0 group-hover:opacity-100 flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded shrink-0 transition-all"
                              style={{ background: "#F1F5F9", color: "#94A3B8" }}
                              onClick={e => { e.stopPropagation(); setCommentPopup({
                                briqueId: synthPopup.briqueId, section: sk, itemIdx: ii,
                                x: 0, y: 0, itemText: item, source: "consultant"
                              }); }}>
                              <MessageSquare size={9} /> {hasComment ? allComments.filter(c => c.briqueId === synthPopup.briqueId && c.section === sk && c.itemIdx === ii).length : "Ajouter"}
                            </button>
                          </li>
                        );
                      })}
                    </ul>
                    {/* Show comments for this section */}
                    {allComments.filter(c => c.briqueId === synthPopup.briqueId && c.section === sk).map(c => (
                      <div key={c.id} className="ml-4 mt-1.5 px-2.5 py-1.5 rounded-md text-[10px]" style={{ background: "rgba(139,92,246,0.06)", borderLeft: "2px solid #8B5CF6" }}>
                        <span className="font-medium" style={{ color: "#8B5CF6" }}>{c.authorName}</span>
                        <span className="mx-1" style={{ color: "#94A3B8" }}>· {c.date}</span>
                        <p style={{ color: "#64748B" }}>{c.text}</p>
                      </div>
                    ))}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      );
    })()}

    {/* Comment popup */}
    {commentPopup && (
      <div className="fixed inset-0 z-[60] flex items-start justify-center pt-[20vh]" style={{ background: "rgba(15,17,23,0.3)" }}
        onClick={() => { setCommentPopup(null); setCommentText(""); }}>
        <div className="rounded-xl w-[380px] overflow-hidden" style={{ background: "#FFFFFF", boxShadow: "0 8px 30px rgba(0,0,0,0.2)" }}
          onClick={e => e.stopPropagation()}>
          <div className="px-4 py-3 flex items-center justify-between" style={{ borderBottom: "1px solid #E2E8F0", background: "#F8FAFC" }}>
            <span className="text-xs font-medium flex items-center gap-1.5" style={{ color: "#0F172A" }}>
              <MessageSquare size={12} style={{ color: "#8B5CF6" }} /> Ajouter un commentaire
            </span>
            <button onClick={() => { setCommentPopup(null); setCommentText(""); }} style={{ color: "#94A3B8" }}>
              <X size={13} />
            </button>
          </div>
          <div className="p-4">
            <p className="text-xs mb-2 italic" style={{ color: "#94A3B8" }}>« {commentPopup.itemText.substring(0, 80)}{commentPopup.itemText.length > 80 ? "..." : ""} »</p>
            <textarea value={commentText} onChange={e => setCommentText(e.target.value)}
              placeholder="Écrire un commentaire..."
              rows={3}
              className="w-full px-3 py-2 rounded-md text-xs outline-none resize-none"
              style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#0F172A" }}
              autoFocus />
            <div className="flex justify-end gap-2 mt-2">
              <button onClick={() => { setCommentPopup(null); setCommentText(""); }}
                className="px-3 h-7 rounded-md text-xs" style={{ background: "#F1F5F9", color: "#64748B" }}>
                Annuler
              </button>
              <button onClick={addComment}
                className="px-3 h-7 rounded-md text-xs font-medium" style={{ background: "#8B5CF6", color: "white" }}>
                <Send size={10} className="inline mr-1" /> Commenter
              </button>
            </div>
          </div>
        </div>
      </div>
    )}

    <div className="h-full flex flex-col overflow-hidden" style={{ background: "#F8FAFC" }}>
      {/* Sub-navigation */}
      <div className="px-5 py-2 flex items-center gap-2 shrink-0" style={{ borderBottom: "1px solid #E2E8F0", background: "#FFFFFF" }}>
        {[
          { id: "draft", label: "📄 Brouillon" },
          { id: "split", label: "✏️ Édition Split" },
          { id: "carto", label: "🗺️ Cartographie finale" },
          { id: "share", label: "🔗 Partage & Validation" },
        ].map(v => (
          <button key={v.id} onClick={() => setActiveView(v.id as any)}
            className="px-3 h-7 rounded text-xs font-medium transition-all"
            style={{
              background: activeView === v.id ? "rgba(232,93,122,0.15)" : "transparent",
              color: activeView === v.id ? "#E85D7A" : "#64748B",
              border: activeView === v.id ? "1px solid rgba(232,93,122,0.3)" : "1px solid transparent",
            }}>
            {v.label}
          </button>
        ))}
      </div>

      {/* Draft view — sans commentaire, alignée sur la structure cartographie */}
      {activeView === "draft" && (
        <div className="flex flex-1 overflow-hidden">
          {/* Domain navigator */}
          <div className="w-64 shrink-0 flex flex-col overflow-hidden" style={{ borderRight: "1px solid #E2E8F0" }}>
            <div className="px-4 py-3 shrink-0" style={{ borderBottom: "1px solid #E2E8F0" }}>
              <p className="text-xs uppercase tracking-widest" style={{ color: "#94A3B8" }}>Navigation</p>
            </div>
            <div className="flex-1 overflow-y-auto p-3 space-y-1">
              {m1Domains.map((d) => {
                const briqueNoms = domainBriqueIds[d.id] || [];
                return (
                  <div key={d.id}>
                    <button className="w-full text-left flex items-center gap-2 px-2 py-2 rounded-md transition-all"
                      style={{ color: "#64748B" }}
                      onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#F1F5F9"; }}
                      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; }}>
                      <span className="text-xs font-medium">{d.icon} {d.label}</span>
                      <span className="ml-auto text-[10px]" style={{ color: "#94A3B8" }}>{briqueNoms.length}</span>
                    </button>
                    <div className="ml-4 space-y-0.5">
                      {briqueNoms.map(nom => (
                        <button key={nom} className="w-full text-left text-xs px-2 py-1.5 rounded flex items-center justify-between"
                          style={{ color: "#94A3B8" }}
                          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.color = "#64748B"; }}
                          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.color = "#94A3B8"; }}>
                          <span>{nom}</span>
                          <span className="w-2 h-2 rounded-full" style={{ background: getStatutCouleur(nom) }} />
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Document */}
          <div className="flex-1 flex flex-col overflow-hidden">
            <div className="px-6 py-3 flex items-center gap-3 shrink-0" style={{ borderBottom: "1px solid #E2E8F0" }}>
              <div className="flex items-center gap-2 flex-1 px-3 py-2 rounded" style={{ background: "rgba(139,92,246,0.08)", border: "1px solid rgba(139,92,246,0.2)" }}>
                <Sparkles size={13} style={{ color: "#8B5CF6" }} />
                <p className="text-xs" style={{ color: "#8B5CF6" }}>Généré par IA — Brouillon</p>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto px-8 py-5 space-y-6">
              {m1Domains.map(domain => {
                const ids = domainBriqueIds[domain.id] || [];
                return (
                  <div key={domain.id}>
                    <h2 className="mb-4 flex items-center gap-2" style={{ borderBottom: "1px solid #E2E8F0", paddingBottom: 12 }}>
                      <span>{domain.icon}</span> {domain.label}
                    </h2>
                    {ids.map(nom => {
                      const data = getSynthData(nom);
                      return (
                        <div key={nom} className="mb-5">
                          <h3 className="text-sm font-semibold mb-2 flex items-center gap-2" style={{ color: "#0F172A" }}>
                            <span className="w-2 h-2 rounded-full" style={{ background: getStatutCouleur(nom) }} />
                            {nom}
                          </h3>
                          {(Object.keys(sectionTitles) as SectionKey[]).map(sk => {
                            const items = data[sk];
                            if (items.length === 0) return null;
                            return (
                              <div key={sk} className="mb-3">
                                <h4 className="mb-1.5" style={{ color: "#64748B", fontSize: 12 }}>{sectionTitles[sk]} ({items.length})</h4>
                                <ul className="space-y-1">
                                  {items.map((item, ii) => (
                                    <li key={ii} className="flex items-start gap-2 text-sm"
                                      style={{ color: "#64748B", borderRadius: 4, padding: "2px 4px" }}>
                                      <span className="shrink-0 mt-2 w-1 h-1 rounded-full" style={{ background: "#CBD5E1" }} />
                                      <span>{item}</span>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            );
                          })}
                        </div>
                      );
                    })}
                  </div>
                );
              })}
            </div>
            <div className="px-6 py-4 flex items-center justify-between shrink-0" style={{ borderTop: "1px solid #E2E8F0" }}>
              <GhostButton>← Retour</GhostButton>
              <div className="flex gap-2">
                <button onClick={() => setActiveView("carto")} className="px-4 h-9 rounded-md text-sm text-white" style={{ background: "#E85D7A" }}>
                  Cartographie finale →
                </button>
                <GoldButton>⚖️ Valider la cohérence globale</GoldButton>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Cartography view — squelette fonctionnel / briques cliquables → diagnostic */}
      {activeView === "carto" && (() => {
        const openSynth = (nom: string) => {
          const domain = m1Domains.find(d => (domainBriqueIds[d.id] || []).includes(nom));
          setSynthPopup({ briqueId: nom, label: nom, domain: domain?.label || "" });
        };
        return (
        <div className="flex-1 flex flex-col overflow-hidden">
          <div className="px-5 py-3 flex items-center gap-3 shrink-0" style={{ borderBottom: "1px solid #E2E8F0", background: "#FFFFFF" }}>
            <h3 className="font-bold" style={{ color: "#E84260", fontSize: 15 }}>Cartographie et Couverture fonctionnelle du SI existant</h3>
            <span className="text-xs" style={{ color: "#94A3B8" }}>Couverture du SI existant</span>
            <div className="ml-auto flex items-center gap-2">
              <button onClick={() => setActiveView("share")} className="px-3 h-7 rounded text-xs font-medium" style={{ background: "#E85D7A", color: "white" }}>
                🔗 Partager →
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-auto p-5">
            <div className="w-full" style={{ minWidth: 960, maxWidth: 1400, margin: "0 auto" }}>
              {/* 3-column grid: left (15%) | center (70%) | right (15%) */}
              <div className="grid gap-4" style={{ gridTemplateColumns: "15% 1fr 15%" }}>
                {/* Left column: Support */}
                <DomainColumn domaine={cartographie.colonnesLaterales[0]} onBriqueClick={openSynth} />

                {/* Center: 4 stacked bands */}
                <div className="flex flex-col gap-4">
                  {/* Header */}
                  <div className="text-center pb-2">
                    <h2 className="font-bold text-lg" style={{ color: "#E84260" }}>Cartographie et Couverture fonctionnelle du SI existant</h2>
                    <p className="text-xs" style={{ color: "#6B7280" }}>Couverture du SI existant</p>
                  </div>
                  {cartographie.domainesCentraux.map((d) => (
                    <div key={d.id} className={d.id === "chaine_valeur" ? "flex-1" : ""}>
                      <DomainBand domaine={d} onBriqueClick={openSynth} />
                    </div>
                  ))}
                </div>

                {/* Right column: Référentiel */}
                <DomainColumn domaine={cartographie.colonnesLaterales[1]} onBriqueClick={openSynth} />
              </div>

              {/* Legend */}
              <div className="mt-5 pt-4 flex items-center justify-between" style={{ borderTop: "1px solid #E2E8F0" }}>
                <Legende />
                <span className="text-xs" style={{ color: "#94A3B8" }}>
                  {cartographie.colonnesLaterales.reduce((s, c) => s + c.briques.length, 0) +
                    cartographie.domainesCentraux.reduce((s, d) => s + (d.briques?.length || 0) + (d.sousDomaines?.reduce((ss, sd) => ss + sd.briques.length, 0) || 0), 0)} briques
                </span>
              </div>
            </div>
          </div>
        </div>
        );
      })()}

      {/* Share view */}
      {activeView === "share" && (
        <div className="flex flex-1 overflow-hidden">
          {/* Left — controls + remarks */}
          <div className="w-[40%] flex flex-col overflow-hidden" style={{ borderRight: "1px solid #E2E8F0" }}>
            <div className="px-6 py-5 flex-1 overflow-y-auto">
              <h3 className="mb-1">Livrable Phase 1</h3>
              <p className="text-xs mb-4" style={{ color: "#64748B" }}>Partagé avec le client pour relecture</p>

              <ShareableLink
                url="https://sdsi.devoteam.com/share/u7f9x2a3b4c5"
                status="active"
                permission="read"
                expiresIn="30 jours"
                onCopy={() => {}}
                onToggleStatus={() => {}}
                onEmail={() => {}}
              />

              <div className="mt-5 mb-4 px-3 py-2.5 rounded-lg flex items-center gap-2" style={{ background: "#F8FAFC", border: "1px solid #E2E8F0" }}>
                <div className={`w-2 h-2 rounded-full ${shareStatus === "waiting" ? "animate-pulse bg-amber-400" : "bg-green-400"}`} />
                <span className="text-xs" style={{ color: shareStatus === "waiting" ? "#F59E0B" : "#10B981" }}>
                  {shareStatus === "waiting" ? "⏳ En attente de relecture client" : "✅ Validé par le client"}
                </span>
                <button onClick={() => setShareStatus(shareStatus === "waiting" ? "validated" : "waiting")}
                  className="ml-auto text-[10px] px-1.5 py-0.5 rounded" style={{ background: "#F1F5F9", color: "#94A3B8" }}>
                  Simuler validation
                </button>
              </div>

              {notified && (
                <div className="mb-4 px-3 py-2 rounded-lg flex items-center gap-2 text-xs" style={{ background: "rgba(139,92,246,0.1)", border: "1px solid rgba(139,92,246,0.25)", color: "#8B5CF6" }}>
                  🔔 Client notifié — en attente de sa relecture
                </div>
              )}

              <label className="block text-xs font-semibold mb-3" style={{ color: "#0F172A" }}>
                💬 Remarques du client
                <span className="ml-1.5 text-[10px] font-normal" style={{ color: "#94A3B8" }}>
                  ({clientRemarks.filter(r => !r.resolved).length} en attente)
                </span>
              </label>

              <div className="space-y-2.5 mb-4">
                {clientRemarks.map(r => (
                  <div key={r.id} className="flex gap-2.5 px-3 py-2.5 rounded-lg" style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", borderLeftWidth: 3, borderLeftColor: r.resolved ? "#10B981" : "#F59E0B" }}>
                    <div className="w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0" style={{ background: "#E85D7A", color: "white" }}>{r.initials}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 mb-0.5">
                        <span className="text-xs font-medium" style={{ color: "#0F172A" }}>{r.name}</span>
                        <span className="text-[10px]" style={{ color: "#94A3B8" }}>· {r.date}</span>
                      </div>
                      <p className="text-xs leading-relaxed mb-1" style={{ color: "#64748B" }}>{r.text}</p>
                      <span className="text-[10px] inline-block px-1.5 py-0.5 rounded" style={{ background: "#F1F5F9", color: "#94A3B8" }}>
                        Sur: {r.section}
                      </span>
                      <div className="flex items-center gap-2 mt-1.5">
                        {r.resolved ? (
                          <span className="text-[10px]" style={{ color: "#10B981" }}>✅ Résolue</span>
                        ) : (
                          <button onClick={() => resolveRemark(r.id)}
                            className="text-[10px] px-1.5 py-0.5 rounded transition-all"
                            style={{ background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.25)", color: "#10B981" }}>
                            ✅ Marquer résolue
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <label className="block text-xs font-semibold mb-2" style={{ color: "#0F172A" }}>
                Répondre au client
              </label>
              <textarea rows={3} placeholder="Tapez votre réponse ici..."
                className="w-full px-3 py-2 rounded-md text-xs outline-none resize-none"
                style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#0F172A" }} />
              <div className="flex gap-2 mt-2">
                <button className="text-xs px-3 h-7 rounded-md font-medium" style={{ background: "#E85D7A", color: "white" }}>
                  Envoyer la réponse
                </button>
                <button onClick={notifyClient}
                  className="text-xs px-3 h-7 rounded-md font-medium transition-all"
                  style={{ background: "rgba(139,92,246,0.12)", border: "1px solid rgba(139,92,246,0.3)", color: "#8B5CF6" }}>
                  🔔 Notifier le client
                </button>
              </div>
              <p className="text-[10px] mt-1.5" style={{ color: "#94A3B8" }}>
                Le consultant résout les remarques → notifie le client → boucle jusqu'à validation finale
              </p>
            </div>

            {shareStatus === "validated" && (
              <div className="px-6 py-4 shrink-0" style={{ borderTop: "1px solid #E2E8F0" }}>
                <GoldButton onClick={handleSuccess} className="w-full justify-center">
                  ⚖️ Confirmer la validation et clôturer la Phase AS-IS
                </GoldButton>
              </div>
            )}
          </div>

          {/* Right — Vue client interactive */}
          <div className="flex-1 flex flex-col overflow-hidden" style={{ background: "#FCFCFD" }}>
            <div className="px-5 py-3 shrink-0 flex items-center gap-2" style={{ borderBottom: "1px solid #E2E8F0", background: "#FFFFFF" }}>
              <span className="text-xs px-2 py-0.5 rounded" style={{ background: "rgba(232,93,122,0.1)", color: "#E85D7A", border: "1px solid rgba(232,93,122,0.2)" }}>
                👁️ Ce que le client voit
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded ml-auto flex items-center gap-1" style={{ background: "rgba(139,92,246,0.08)", border: "1px dashed rgba(139,92,246,0.3)", color: "#8B5CF6" }}>
                ✏️ Cliquez pour commenter
              </span>
            </div>
            <div className="flex-1 overflow-y-auto p-5 space-y-6">
              {/* Guide banner */}
              <div className="rounded-lg p-3 text-[11px] leading-relaxed flex items-start gap-2" style={{ background: "rgba(139,92,246,0.06)", border: "1px dashed rgba(139,92,246,0.3)", color: "#8B5CF6" }}>
                <MessageSquare size={14} className="shrink-0 mt-0.5" />
                <span>Cliquez sur n'importe quel élément ci-dessous (brique carto, observation, constat ou besoin) pour ajouter un commentaire.</span>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg flex items-center justify-center text-white font-bold text-sm" style={{ background: "#E85D7A" }}>S</div>
                <div>
                  <p className="text-base font-semibold" style={{ color: "#0F172A" }}>Livrable Phase AS-IS — Banque Centrale Maghreb</p>
                  <p className="text-xs" style={{ color: "#94A3B8" }}>Généré le 11 juin 2026 · Document partagé par Devoteam</p>
                </div>
              </div>

              {(() => { const totalCartoBriques = flattenCartoBriques().length; const couvert = flattenCartoBriques().filter(b => b.statut === "couvert").length; return (
              <div className="grid grid-cols-3 gap-3">
                {[
                  { label: "Briques cartographiées", val: totalCartoBriques.toString(), color: "#E84260" },
                  { label: "Ateliers conduits", val: "3", color: "#E85D7A" },
                  { label: "Taux de couverture", val: totalCartoBriques > 0 ? `${Math.round((couvert / totalCartoBriques) * 100)}%` : "0%", color: "#10B981" },
                ].map(s => (
                  <div key={s.label} className="px-4 py-3 rounded-lg text-center" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
                    <p className="text-xl font-bold" style={{ color: s.color }}>{s.val}</p>
                    <p className="text-xs mt-0.5" style={{ color: "#64748B" }}>{s.label}</p>
                  </div>
                ))}
              </div>
              );})()}

              {/* Cartographie — squelette fonctionnel (vue client interactive, briques cliquables → diagnostic + commentaire) */}
              <div>
                <h4 className="mb-3 font-bold" style={{ fontSize: 14, color: "#E84260" }}>Cartographie et Couverture fonctionnelle du SI existant</h4>
                {(() => {
                  const openSynthShare = (nom: string) => {
                    const domain = m1Domains.find(d => (domainBriqueIds[d.id] || []).includes(nom));
                    setSynthPopup({ briqueId: nom, label: nom, domain: domain?.label || "" });
                  };
                  return (
                  <div className="grid gap-3" style={{ gridTemplateColumns: "15% 1fr 15%" }}>
                    <DomainColumn domaine={cartographie.colonnesLaterales[0]} onBriqueClick={openSynthShare} />
                    <div className="flex flex-col gap-3">
                      {cartographie.domainesCentraux.map(d => (
                        <DomainBand key={d.id} domaine={d} onBriqueClick={openSynthShare} />
                      ))}
                    </div>
                    <DomainColumn domaine={cartographie.colonnesLaterales[1]} onBriqueClick={openSynthShare} />
                  </div>
                  );
                })()}
                <div className="mt-3">
                  <Legende />
                </div>
              </div>

              {/* Synthèse — chaque item clickable */}
              <div>
                <h4 className="mb-3 flex items-center gap-2" style={{ fontSize: 13 }}>
                  Synthèse des ateliers
                  <span className="text-[10px] font-normal px-1.5 py-0.5 rounded" style={{ background: "#F1F5F9", color: "#94A3B8" }}>
                    Cliquez pour commenter
                  </span>
                </h4>
                {m1Domains.map(domain => {
                  const ids = domainBriqueIds[domain.id] || [];
                  const items = ids.flatMap(id => {
                    const d = getSynthData(id);
                    return [...d.obs, ...d.constats, ...d.besoins];
                  });
                  const domainCommentCount = allComments.filter(c => ids.includes(c.briqueId)).length;
                  return (
                    <div key={domain.id} className="mb-4 p-4 rounded-lg transition-all"
                      style={{
                        background: "#FFFFFF",
                        border: domainCommentCount > 0 ? "1.5px solid rgba(139,92,246,0.2)" : "1px solid #E2E8F0",
                      }}>
                      <h5 className="mb-2 flex items-center gap-1.5" style={{ fontSize: 12, color: "#64748B" }}>
                        {domain.icon} {domain.label}
                        <span className="text-[10px] ml-auto px-1.5 py-0.5 rounded" style={{ background: "#F1F5F9", color: "#94A3B8" }}>
                          {items.length} éléments
                        </span>
                        {domainCommentCount > 0 && (
                          <span className="text-[10px] flex items-center gap-0.5 px-1.5 py-0.5 rounded" style={{ background: "rgba(139,92,246,0.1)", color: "#8B5CF6" }}>
                            <MessageSquare size={8} /> {domainCommentCount}
                          </span>
                        )}
                      </h5>
                      {ids.map(nom => {
                        const data = getSynthData(nom);
                        return (
                          <div key={nom} className="mb-2">
                            <p className="text-[11px] font-medium mb-1 flex items-center gap-1" style={{ color: "#0F172A" }}>
                              <span className="w-1.5 h-1.5 rounded-full" style={{ background: getStatutCouleur(nom) }} />
                              {nom}
                            </p>
                            {(Object.keys(sectionTitles) as SectionKey[]).map(sk => {
                              const sItems = data[sk];
                              if (sItems.length === 0) return null;
                              return (
                                <div key={sk} className="mb-1.5">
                                  <p className="text-[10px] font-medium ml-3" style={{ color: "#94A3B8" }}>{sectionTitles[sk]}</p>
                                  <ul className="space-y-0.5 ml-5">
                                    {sItems.map((item, ii) => {
                                      const hasComment = allComments.some(c => c.briqueId === nom && c.section === sk && c.itemIdx === ii);
                                      return (
                                        <li key={ii}
                                          className="group flex items-start gap-2 text-[11px] cursor-pointer transition-all relative rounded-sm px-1 -mx-1"
                                          style={{
                                            color: hasComment ? "#7C3AED" : "#64748B",
                                            background: hasComment ? "rgba(139,92,246,0.06)" : "transparent",
                                          }}
                                          onMouseEnter={e => { e.currentTarget.style.background = hasComment ? "rgba(139,92,246,0.1)" : "#F1F5F9"; }}
                                          onMouseLeave={e => { e.currentTarget.style.background = hasComment ? "rgba(139,92,246,0.06)" : "transparent"; }}
                                          onClick={() => setCommentPopup({
                                            briqueId: nom, section: sk, itemIdx: ii,
                                            x: 0, y: 0, itemText: item, source: "client",
                                          })}>
                                          <span className="w-1 h-1 rounded-full shrink-0 mt-1.5" style={{ background: hasComment ? "#8B5CF6" : "#CBD5E1" }} />
                                          <span className="flex-1">{item}</span>
                                          {hasComment && (
                                            <span className="shrink-0 flex items-center gap-0.5 text-[9px]" style={{ color: "#8B5CF6" }}>
                                              <MessageSquare size={8} /> {allComments.filter(c => c.briqueId === nom && c.section === sk && c.itemIdx === ii).length}
                                            </span>
                                          )}
                                          <span className="opacity-0 group-hover:opacity-100 text-[8px] ml-1 shrink-0 px-1 rounded" style={{ background: "#E2E8F0", color: "#94A3B8" }}>
                                            ✏️
                                          </span>
                                        </li>
                                      );
                                    })}
                                  </ul>
                                  {/* Commentaires inline */}
                                  {allComments.filter(c => c.briqueId === nom && c.section === sk).map(c => (
                                    <div key={c.id} className="ml-6 mt-1 px-2 py-1 rounded text-[10px]" style={{ background: "rgba(139,92,246,0.06)", borderLeft: "2px solid #8B5CF6" }}>
                                      <span className="font-medium" style={{ color: "#8B5CF6" }}>{c.authorName}</span>
                                      <span className="mx-1" style={{ color: "#94A3B8" }}>· {c.date}</span>
                                      <p style={{ color: "#64748B" }}>{c.text}</p>
                                    </div>
                                  ))}
                                </div>
                              );
                            })}
                          </div>
                        );
                      })}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Split edit view */}
      {activeView === "split" && (() => {
        const allCartoNoms = flattenCartoBriques();
        const openSynth = (nom: string) => {
          const domain = m1Domains.find(d => (domainBriqueIds[d.id] || []).includes(nom));
          setSynthPopup({ briqueId: nom, label: nom, domain: domain?.label || "" });
        };
        return (
        <div className="flex flex-1 overflow-hidden">
          {/* Left carto */}
          <div className="w-[30%] flex flex-col overflow-hidden" style={{ borderRight: "1px solid #E2E8F0" }}>
            <div className="px-4 py-3 shrink-0" style={{ borderBottom: "1px solid #E2E8F0" }}>
              <h4>Cartographie squelette</h4>
            </div>
            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {allCartoNoms.map(cb => (
                <div key={cb.nom} className="px-3 py-2 rounded-lg cursor-pointer flex items-center gap-2"
                  style={{ background: "#FFFFFF", border: "1px solid #E2E8F0", borderLeftWidth: 3, borderLeftColor: getStatutCouleur(cb.nom) }}
                  onClick={() => openSynth(cb.nom)}>
                  <div className="w-2 h-2 rounded-full" style={{ background: getStatutCouleur(cb.nom) }} />
                  <span className="text-xs" style={{ color: "#64748B" }}>{cb.nom}</span>
                </div>
              ))}
            </div>
            <div className="px-3 py-3 shrink-0" style={{ borderTop: "1px solid #E2E8F0" }}>
              <Legende />
            </div>
          </div>

          {/* Center document */}
          <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs" style={{ color: "#E85D7A" }}>🔗 Vue synchronisée avec la cartographie</span>
            </div>
            {m1Domains.map(domain => {
              const ids = domainBriqueIds[domain.id] || [];
              return (
                <div key={domain.id} className="rounded-lg p-4" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
                  <h3 className="mb-3">{domain.icon} {domain.label}</h3>
                  {ids.map(nom => {
                    const data = getSynthData(nom);
                    return (
                      <div key={nom} className="mb-3">
                        <p className="text-xs font-medium mb-1 flex items-center gap-1" style={{ color: "#0F172A" }}>
                          <span className="w-1.5 h-1.5 rounded-full" style={{ background: getStatutCouleur(nom) }} />
                          {nom}
                        </p>
                        {(Object.keys(sectionTitles) as SectionKey[]).map(sk => {
                          const sItems = data[sk];
                          if (sItems.length === 0) return null;
                          return (
                            <div key={sk} className="mb-1">
                              <p className="text-xs" style={{ color: "#94A3B8" }}>{sectionTitles[sk]}</p>
                              {sItems.map((item, ii) => (
                                <p key={ii} className="text-xs mb-0.5 pl-3"
                                  style={{ color: "#64748B", borderLeft: "2px solid #8B5CF6" }}>
                                  • {item}
                                </p>
                              ))}
                            </div>
                          );
                        })}
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>

          {/* Right AI bar */}
          <div className="w-56 shrink-0 flex flex-col overflow-hidden" style={{ borderLeft: "1px solid #E2E8F0" }}>
            <div className="px-4 py-3 shrink-0" style={{ borderBottom: "1px solid #E2E8F0" }}>
              <p className="text-xs font-medium flex items-center gap-1.5" style={{ color: "#8B5CF6" }}>
                <Sparkles size={12} /> Barre IA
              </p>
            </div>
            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {["Résume le domaine Sécurité", "Reformule en langage décisionnel", "Déplace ce constat"].map(chip => (
                <button key={chip} onClick={() => setAiPrompt(chip)}
                  className="w-full text-left text-[11px] px-2.5 py-2 rounded-lg transition-all"
                  style={{ background: "#F1F5F9", border: "1px solid #E2E8F0", color: "#64748B" }}
                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = "#8B5CF644"; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "#E2E8F0"; }}>
                  {chip}
                </button>
              ))}
            </div>
            <div className="p-3 shrink-0" style={{ borderTop: "1px solid #E2E8F0" }}>
              <textarea value={aiPrompt} onChange={e => setAiPrompt(e.target.value)} rows={3}
                placeholder="Demandez à l'IA d'ajuster..."
                className="w-full text-xs px-2 py-2 rounded-md resize-none outline-none"
                style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#0F172A" }} />
              <button className="w-full mt-2 h-7 rounded text-xs font-medium"
                style={{ background: "rgba(139,92,246,0.15)", border: "1px solid rgba(139,92,246,0.3)", color: "#8B5CF6" }}>
                <Sparkles size={10} className="inline mr-1" /> Appliquer
              </button>
            </div>
          </div>
        </div>
      );
      })()}
    </div>
    </>
  );
}

function ArchivingOverlay() {
  const [step, setStep] = useState(0);
  const steps = [
    "Génération du livrable final...",
    "Indexation dans la base de connaissance...",
    "Archivage terminé ✓"
  ];

  useEffect(() => {
    if (step >= steps.length - 1) return;
    const t = setTimeout(() => setStep(s => s + 1), 800);
    return () => clearTimeout(t);
  }, [step, steps.length]);

  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center" style={{ background: "rgba(15,17,23,0.92)" }}>
      <div className="rounded-2xl p-8 w-full max-w-[420px] mx-4" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: "rgba(139,92,246,0.1)" }}>
            <Archive size={18} style={{ color: "#8B5CF6" }} />
          </div>
          <div>
            <h4>Archivage du livrable</h4>
            <p className="text-xs" style={{ color: "#64748B" }}>Veuillez patienter...</p>
          </div>
        </div>
        <div className="space-y-2.5 mb-4">
          {steps.map((s, i) => (
            <div key={i} className="flex items-center gap-2.5 text-xs"
              style={{ color: i < step ? "#10B981" : i === step ? "#8B5CF6" : "#CBD5E1" }}>
              {i < step ? (
                <CheckCircle size={14} style={{ color: "#10B981" }} />
              ) : i === step ? (
                <span className="w-3.5 h-3.5 border-2 rounded-full animate-spin" style={{ borderColor: "#8B5CF6", borderTopColor: "transparent" }} />
              ) : (
                <span className="w-3.5 h-3.5 rounded-full" style={{ border: "2px solid #E2E8F0" }} />
              )}
              <span>{s}</span>
            </div>
          ))}
        </div>
        <div className="h-1 rounded-full" style={{ background: "#E2E8F0" }}>
          <div className="h-full rounded-full transition-all duration-500" style={{ width: `${((step + 1) / steps.length) * 100}%`, background: "#8B5CF6" }} />
        </div>
      </div>
    </div>
  );
}

function SuccessModal() {
  return (
    <div className="h-full flex items-center justify-center" style={{ background: "rgba(15,17,23,0.92)" }}>
      <div className="rounded-2xl p-8 w-full max-w-[520px] mx-4 text-center" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
        <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6" style={{ background: "rgba(16,185,129,0.12)", border: "2px solid #10B981" }}>
          <span className="text-4xl">✓</span>
        </div>
        <h1 className="mb-2" style={{ color: "#0F172A" }}>Phase AS-IS clôturée ✓</h1>
        <p className="text-sm mb-6" style={{ color: "#64748B" }}>Mission: Audit SI — Banque Centrale Maghreb</p>

        <div className="grid grid-cols-2 gap-3 mb-6">
          {[
            { icon: "📄", val: "12", label: "documents analysés" },
            { icon: "🗺️", val: "6",  label: "briques cartographiées" },
            { icon: "🎯", val: "3",  label: "ateliers conduits" },
            { icon: "📋", val: "78%", label: "couverture finale" },
          ].map(stat => (
            <div key={stat.label} className="px-4 py-3 rounded-xl" style={{ background: "#F1F5F9" }}>
              <p className="text-2xl font-bold mb-0.5" style={{ color: "#10B981" }}>{stat.icon} {stat.val}</p>
              <p className="text-xs" style={{ color: "#64748B" }}>{stat.label}</p>
            </div>
          ))}
        </div>

        <div className="flex items-center gap-2 justify-center mb-6 text-xs" style={{ color: "#10B981" }}>
          <div className="w-3 h-3 rounded-full" style={{ background: "#10B981" }} />
          ✅ Indexé dans la base de connaissance
        </div>

        <div className="h-px mb-6" style={{ background: "#E2E8F0" }} />
        <p className="text-sm mb-6" style={{ color: "#94A3B8" }}>Prochaine étape: Phase Cible → (verrouillé)</p>
        <div className="flex gap-3 justify-center">
          <button className="px-4 h-9 rounded-md text-sm" style={{ background: "#F1F5F9", border: "1px solid #E2E8F0", color: "#64748B" }}>
            Retour aux missions
          </button>
        </div>
      </div>
    </div>
  );
}
