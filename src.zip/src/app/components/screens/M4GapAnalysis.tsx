import { useState } from "react";
import { ChevronLeft, ChevronRight, Check, X, FileText, BookOpen, AlertTriangle, Target } from "lucide-react";
import { AIActionButton } from "../ui-kit";

interface GapQuestion {
  id: number;
  text: string;
  framework: string;
  sourceDoc: string | null;
  covered: boolean;
}

const frameworks = ["COBIT 2019", "ITIL 4", "ISO 27001", "Utilisateur"];

const gapQuestions: GapQuestion[] = [
  { id: 1,  text: "EDM01 — Cadre de gouvernance formalisé ?",                framework: "COBIT 2019", sourceDoc: "Politique_Sécurité_2024.pdf", covered: true },
  { id: 2,  text: "EDM02 — Réalisation des bénéfices mesurée ?",             framework: "COBIT 2019", sourceDoc: null,                       covered: false },
  { id: 3,  text: "APO01 — Gestion du SI documentée ?",                      framework: "COBIT 2019", sourceDoc: "Rapport_SI_Global.pdf",      covered: true },
  { id: 4,  text: "APO07 — Ressources humaines SI structurées ?",            framework: "COBIT 2019", sourceDoc: "Organigramme_DSI.pptx",      covered: true },
  { id: 5,  text: "DSS01 — Opérations IT standardisées ?",                   framework: "COBIT 2019", sourceDoc: null,                       covered: false },
  { id: 6,  text: "DSS05 — Sécurité des opérations ?",                       framework: "COBIT 2019", sourceDoc: "Politique_Sécurité_2024.pdf", covered: true },
  { id: 7,  text: "Stratégie IT alignée sur le métier ?",                    framework: "ITIL 4",     sourceDoc: "Cloud_Strategy_v2.pdf",     covered: true },
  { id: 8,  text: "Conception des services documentée ?",                    framework: "ITIL 4",     sourceDoc: null,                       covered: false },
  { id: 9,  text: "Transition & déploiement maîtrisés ?",                    framework: "ITIL 4",     sourceDoc: "Plan_migration_cloud.pdf", covered: true },
  { id: 10, text: "Exploitation & support niveaux définis ?",                framework: "ITIL 4",     sourceDoc: null,                       covered: false },
  { id: 11, text: "Amélioration continue processus IT ?",                    framework: "ITIL 4",     sourceDoc: "Rapport_SI_Global.pdf",      covered: true },
  { id: 12, text: "A.5 — Politique de sécurité formelle ?",                  framework: "ISO 27001",  sourceDoc: "Politique_Sécurité_2024.pdf", covered: true },
  { id: 13, text: "A.6 — Organisation de la sécurité ?",                     framework: "ISO 27001",  sourceDoc: null,                       covered: false },
  { id: 14, text: "A.7 — Sécurité RH appliquée ?",                           framework: "ISO 27001",  sourceDoc: null,                       covered: false },
  { id: 15, text: "A.8 — Gestion des actifs SI ?",                          framework: "ISO 27001",  sourceDoc: "Infra_réseau_mapping_v3.pptx", covered: true },
  { id: 16, text: "A.11 — Sécurité physique & environnement ?",              framework: "ISO 27001",  sourceDoc: null,                       covered: false },
];

interface M4GapAnalysisProps {
  onNext: () => void;
  onBack: () => void;
  additionalQuestions?: string[];
}

export function M4GapAnalysis({ onNext, onBack, additionalQuestions = [] }: M4GapAnalysisProps) {
  const [selectedFramework, setSelectedFramework] = useState<string>("COBIT 2019");
  const [userCovered, setUserCovered] = useState<Record<number, boolean>>({});

  const userQuestions: GapQuestion[] = additionalQuestions.map((q, i) => ({
    id: 1000 + i,
    text: q,
    framework: "Utilisateur",
    sourceDoc: null,
    covered: userCovered[i] ?? false,
  }));

  const allQuestions = [...gapQuestions, ...userQuestions];
  const filtered = allQuestions.filter(q => q.framework === selectedFramework || (selectedFramework === "Utilisateur" && q.framework === "Utilisateur"));
  const covered = filtered.filter(q => q.covered);
  const gaps = filtered.filter(q => !q.covered);
  const coveragePct = filtered.length > 0 ? Math.round((covered.length / filtered.length) * 100) : 0;

  return (
    <div className="h-full flex flex-col" style={{ background: "#F8FAFC" }}>
      {/* Header */}
      <div className="px-6 py-4 flex items-center justify-between shrink-0" style={{ borderBottom: "1px solid #E2E8F0", background: "#FFFFFF" }}>
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="w-8 h-8 rounded-lg flex items-center justify-center transition-all" style={{ background: "#F1F5F9", color: "#64748B", border: "1px solid #E2E8F0" }}>
            <ChevronLeft size={16} />
          </button>
          <div>
            <h2 className="text-base font-semibold" style={{ color: "#0F172A" }}>Analyse d'écart (GAP)</h2>
            <p className="text-xs mt-0.5" style={{ color: "#64748B" }}>Questions framework couvertes par l'analyse documentaire vs écart à combler en ateliers</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1 px-3 h-7 rounded-md text-xs font-medium" style={{ background: coveragePct >= 70 ? "rgba(16,185,129,0.1)" : coveragePct >= 40 ? "rgba(245,158,11,0.1)" : "rgba(239,68,68,0.1)", color: coveragePct >= 70 ? "#10B981" : coveragePct >= 40 ? "#D97706" : "#EF4444" }}>
            <Target size={12} /> {coveragePct}% couvert
          </span>
          <button onClick={onNext}
            className="flex items-center gap-2 px-4 h-9 rounded-lg text-sm font-medium transition-all"
            style={{ background: "#E85D7A", color: "white" }}>
            Configurer les ateliers <ChevronRight size={14} />
          </button>
        </div>
      </div>

      {/* Framework selector */}
      <div className="px-6 py-3 flex items-center gap-2 shrink-0" style={{ borderBottom: "1px solid #E2E8F0", background: "#FFFFFF" }}>
        {frameworks.map(fw => (
          <button key={fw} onClick={() => setSelectedFramework(fw)}
            className="px-3 h-8 rounded-md text-xs font-medium transition-all"
            style={{
              background: selectedFramework === fw ? "rgba(232,93,122,0.12)" : "#F1F5F9",
              border: `1px solid ${selectedFramework === fw ? "rgba(232,93,122,0.3)" : "#E2E8F0"}`,
              color: selectedFramework === fw ? "#E85D7A" : "#64748B",
            }}>
            {fw}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6">
        {/* Stats */}
        <div className="flex gap-4 mb-6">
          {[
            { label: "Questions totales", value: filtered.length.toString(), color: "#64748B" },
            { label: "Couvertes par documents", value: covered.length.toString(), color: "#10B981" },
            { label: "Écart (GAP)", value: gaps.length.toString(), color: "#EF4444" },
            { label: "Taux de couverture", value: `${coveragePct}%`, color: coveragePct >= 70 ? "#10B981" : coveragePct >= 40 ? "#D97706" : "#EF4444" },
          ].map(stat => (
            <div key={stat.label} className="flex-1 rounded-xl p-4" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
              <p className="text-2xl font-bold" style={{ color: stat.color, fontFamily: "JetBrains Mono, monospace" }}>{stat.value}</p>
              <p className="text-xs mt-1" style={{ color: "#94A3B8" }}>{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Coverage progress bar */}
        <div className="rounded-xl p-4 mb-6" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium" style={{ color: "#0F172A" }}>Couverture globale — {selectedFramework}</span>
            <span className="text-xs" style={{ color: "#94A3B8" }}>{covered.length}/{filtered.length} questions</span>
          </div>
          <div className="h-3 rounded-full overflow-hidden flex" style={{ background: "#F1F5F9" }}>
            <div style={{ width: `${coveragePct}%`, background: "linear-gradient(90deg, #10B981, #34D399)", transition: "width 0.5s" }} />
            <div style={{ width: `${100 - coveragePct}%`, background: "linear-gradient(90deg, #F87171, #EF4444)", transition: "width 0.5s" }} />
          </div>
          <div className="flex justify-between mt-1">
            <span className="text-[10px] flex items-center gap-1" style={{ color: "#10B981" }}><Check size={10} /> Couvert ({covered.length})</span>
            <span className="text-[10px] flex items-center gap-1" style={{ color: "#EF4444" }}><AlertTriangle size={10} /> GAP ({gaps.length})</span>
          </div>
        </div>

        {/* Two columns: Covered vs GAP */}
        <div className="flex gap-6">
          {/* Covered */}
          <div className="flex-1">
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2" style={{ color: "#10B981" }}>
              <Check size={14} /> Couverts par l'analyse documentaire
              <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: "rgba(16,185,129,0.1)", color: "#10B981", fontFamily: "JetBrains Mono, monospace" }}>{covered.length}</span>
            </h3>
            <div className="space-y-2">
              {covered.map(q => {
                const isUser = q.id >= 1000;
                return (
                <div key={q.id} onClick={isUser ? () => setUserCovered(prev => ({ ...prev, [q.id - 1000]: false })) : undefined}
                  className="rounded-lg p-3 flex items-start gap-2"
                  style={{ background: "#FFFFFF", border: "1px solid #E2E8F0", borderLeftWidth: 3, borderLeftColor: "#10B981", cursor: isUser ? "pointer" : undefined }}>
                  <Check size={12} style={{ color: "#10B981", flexShrink: 0, marginTop: 2 }} />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs leading-relaxed" style={{ color: "#0F172A" }}>{q.text}</p>
                    {q.sourceDoc && (
                      <div className="flex items-center gap-1 mt-1">
                        <FileText size={9} style={{ color: "#94A3B8" }} />
                        <span className="text-[9px]" style={{ color: "#94A3B8" }}>{q.sourceDoc}</span>
                      </div>
                    )}
                    {isUser && <p className="text-[9px] mt-1" style={{ color: "#10B981" }}>Question utilisateur — Cliquez pour passer en GAP</p>}
                  </div>
                </div>
                );
              })}
            </div>
          </div>

          {/* GAP */}
          <div className="flex-1">
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2" style={{ color: "#EF4444" }}>
              <AlertTriangle size={14} /> Écart (GAP) à combler
              <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: "rgba(239,68,68,0.1)", color: "#EF4444", fontFamily: "JetBrains Mono, monospace" }}>{gaps.length}</span>
            </h3>
            <div className="space-y-2">
              {gaps.map(q => {
                const isUser = q.id >= 1000;
                return (
                <div key={q.id} onClick={isUser ? () => setUserCovered(prev => ({ ...prev, [q.id - 1000]: true })) : undefined}
                  className="rounded-lg p-3 flex items-start gap-2"
                  style={{ background: "rgba(239,68,68,0.04)", border: "1px solid rgba(239,68,68,0.2)", borderLeftWidth: 3, borderLeftColor: "#EF4444", cursor: isUser ? "pointer" : undefined }}>
                  <X size={12} style={{ color: "#EF4444", flexShrink: 0, marginTop: 2 }} />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs leading-relaxed" style={{ color: "#0F172A" }}>{q.text}</p>
                    {isUser ? (
                      <p className="text-[9px] mt-1" style={{ color: "#8B5CF6" }}>Question utilisateur — Cliquez pour marquer comme couverte</p>
                    ) : (
                      <p className="text-[9px] mt-1" style={{ color: "#EF4444" }}>Aucun document ne couvre cette question → À cibler en atelier</p>
                    )}
                  </div>
                </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Empty state */}
        {filtered.length === 0 && (
          <div className="text-center py-16">
            <BookOpen size={32} style={{ color: "#CBD5E1", margin: "0 auto 12px" }} />
            <p className="text-sm" style={{ color: "#94A3B8" }}>Sélectionnez un framework pour voir l'analyse d'écart</p>
          </div>
        )}
      </div>
    </div>
  );
}
