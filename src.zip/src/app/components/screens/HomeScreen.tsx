import { CoverageRing, TagChip } from "../ui-kit";

const missions = [
  { id: 1, client: "Banque Centrale Maghreb", sector: "🏦 Banque",      module: 3, coverage: 42, status: "active",    date: "Démarré 3 juin 2026", zone: "EMEA" },
  { id: 2, client: "Orange Tunisie",          sector: "📡 Télécoms",    module: 5, coverage: 89, status: "completed", date: "Clôturé 15 mai 2026", zone: "EMEA" },
  { id: 3, client: "Caisse d'Assurance",      sector: "🏛️ Public",      module: 2, coverage: 20, status: "active",    date: "Démarré 1 juin 2026", zone: "EMEA" },
  { id: 4, client: "STEG",                    sector: "⚡ Énergie",     module: 1, coverage: 0,  status: "new",       date: "Créé 10 juin 2026", zone: "EMEA" },
];

const statusMap: Record<string, { label: string; color: string; bg: string }> = {
  active:    { label: "En cours",  color: "#E85D7A", bg: "rgba(232,93,122,0.08)" },
  completed: { label: "Clôturé",   color: "#10B981", bg: "rgba(16,185,129,0.08)" },
  new:       { label: "Nouveau",   color: "#F59E0B", bg: "rgba(245,158,11,0.08)" },
};

interface HomeScreenProps { onSelectMission: () => void; onResumeMission: (module: number) => void; }

export function HomeScreen({ onSelectMission, onResumeMission }: HomeScreenProps) {
  const active = missions.filter(m => m.status === "active").length;
  const completed = missions.filter(m => m.status === "completed").length;
  const avgCoverage = Math.round(missions.reduce((sum, m) => sum + m.coverage, 0) / missions.length);

  return (
    <div className="h-full overflow-y-auto" style={{ background: "#F8FAFC" }}>
      <div className="max-w-[1080px] mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 style={{ fontSize: 24 }}>Missions SDSI</h1>
            <p className="text-sm mt-1" style={{ color: "#64748B" }}>{missions.length} missions · {active} en cours</p>
          </div>
          <button onClick={onSelectMission}
            className="flex items-center gap-2 px-4 h-9 rounded-md text-sm font-medium text-white"
            style={{ background: "#E85D7A" }}>
            + Nouvelle mission
          </button>
        </div>

        {/* Stats row */}
        <div className="flex gap-4 mb-6">
          {[
            { label: "Total missions", value: missions.length.toString(), color: "#64748B" },
            { label: "En cours", value: active.toString(), color: "#E85D7A" },
            { label: "Clôturées", value: completed.toString(), color: "#10B981" },
            { label: "Couverture moyenne", value: `${avgCoverage}%`, color: avgCoverage >= 70 ? "#10B981" : "#D97706" },
          ].map(stat => (
            <div key={stat.label} className="flex-1 rounded-xl p-4" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
              <p className="text-2xl font-bold" style={{ color: stat.color, fontFamily: "JetBrains Mono, monospace" }}>{stat.value}</p>
              <p className="text-xs mt-1" style={{ color: "#94A3B8" }}>{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Mission cards */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          {missions.map(m => {
            const s = statusMap[m.status];
            return (
              <div key={m.id}
                className="rounded-xl p-5 cursor-pointer transition-all"
                style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = "#CBD5E1"; (e.currentTarget as HTMLElement).style.boxShadow = "0 4px 16px rgba(0,0,0,0.08)"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "#E2E8F0"; (e.currentTarget as HTMLElement).style.boxShadow = "none"; }}
                onClick={onSelectMission}>
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="mb-0.5" style={{ fontSize: 15 }}>{m.client}</h3>
                    <p className="text-xs" style={{ color: "#64748B" }}>{m.sector}</p>
                  </div>
                  <span className="text-xs px-2 py-0.5 rounded font-medium"
                    style={{ background: s.bg, color: s.color }}>
                    {s.label}
                  </span>
                </div>
                <div className="flex items-center gap-4">
                  <CoverageRing pct={m.coverage} size={40} />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="text-xs px-2 py-0.5 rounded"
                        style={{ background: "rgba(232,93,122,0.08)", color: "#E85D7A", fontFamily: "JetBrains Mono, monospace" }}>
                        M{m.module} · {m.zone}
                      </span>
                      {m.status === "active" && (
                        <button onClick={e => { e.stopPropagation(); onResumeMission(m.module); }}
                          className="text-[11px] px-2 h-[22px] rounded flex items-center gap-1 font-medium transition-all"
                          style={{ background: "#E85D7A", color: "white" }}>
                          ▶ Reprendre
                        </button>
                      )}
                    </div>
                    <p className="text-[11px]" style={{ color: "#94A3B8", fontFamily: "JetBrains Mono, monospace" }}>{m.date}</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </div>
  );
}
