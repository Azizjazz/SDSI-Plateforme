import { useState, useEffect } from "react";
import { Upload, FileText, FileSpreadsheet, Presentation, CheckCircle, AlertTriangle, Clock, X, ExternalLink, ChevronDown, ChevronRight, Search, Check } from "lucide-react";
import { TagChip } from "../ui-kit";
import { initialExpectedDocs, TREE_DATA } from "../../data/admin-data";
import type { ExpectedDoc, TreeNodeData } from "../../data/admin-data";

const fileIcons: Record<string, React.ReactNode> = {
  PDF: <FileText size={14} style={{ color: "#EF4444" }} />,
  PPT: <Presentation size={14} style={{ color: "#F59E0B" }} />,
  XLS: <FileSpreadsheet size={14} style={{ color: "#10B981" }} />,
  DOC: <FileText size={14} style={{ color: "#E85D7A" }} />,
};

const docContents: Record<number, { title: string; pages: number; content: string }> = {
  1: { title: "Politique_Sécurité_2024.pdf", pages: 8, content: "Document de politique de sécurité SI mis à jour en 2024. Définit les règles de gestion des accès, la politique IAM, les procédures de réponse aux incidents, et la classification des données. Le document identifie des lacunes : politique IAM non mise à jour depuis 2021, absence de procédure formalisée de réponse aux incidents, et firewall Cisco ASA avec firmware obsolète." },
  2: { title: "Infra_réseau_mapping_v3.pptx", pages: 24, content: "Cartographie complète de l'infrastructure réseau. Architecture hub-and-spoke datant de 2018. Trois sites régionaux (Paris, Lyon, Marseille) reliés par MPLS 10 Mbps. Aucune redondance WAN identifiée sur les sites secondaires. Inventaire des équipements : routeurs Cisco 2900, switches Catalyst 3750, firewalls ASA 5500." },
  3: { title: "Budget_DSI_2024_2026.xlsx", pages: 5, content: "Prévision budgétaire DSI 2024-2026. Répartition des investissements par domaine : infrastructure 40%, sécurité 25%, applications 20%, RH 10%, autres 5%. Budget total 2.4M€ sur 3 ans. Inclut les coûts de maintenance des contrats Cisco SmartNet et HP." },
  4: { title: "Plan_migration_cloud.pdf", pages: 12, content: "Stratégie de migration cloud hybride planifiée pour 2025. Priorité sur les applications non-critiques vers Azure. ExpressRoute envisagé pour la connectivité hybride. Phases de migration : évaluation (Q1 2025), migration pilote (Q2 2025), déploiement progressif (Q3-Q4 2025)." },
  5: { title: "Organigramme_DSI.pptx", pages: 3, content: "Organigramme de la DSI : Directeur DSI, 4 pôles (Infrastructure, Applications, Sécurité, Support). Effectif total : 32 personnes. Rattachement hiérarchique à la Direction Générale." },
  6: { title: "Audit_réseau_2023.xlsx", pages: 6, content: "Rapport d'audit réseau 2023. Résultats des tests de vulnérabilité, analyse de performance des liens MPLS, recommandations pour la mise à niveau des équipements Cisco en fin de support. Constats : 12 routeurs avec firmware critique non mis à jour, 3 points de défaillance unique identifiés." },
};

const docSummaries: Record<string, { summary: string; keyPoints: string[] }> = {
  "Politique_Sécurité_2024.pdf": { summary: "Définit la politique de sécurité du SI, les contrôles d'accès, et les exigences réglementaires (RGPD, SOX, Bâle III).", keyPoints: ["Périmètre: DSI et directions métiers", "Conformité RGPD/SOX/Bâle III", "Contrôle d'accès et authentification"] },
  "Infra_réseau_mapping_v3.pptx": { summary: "Cartographie détaillée de l'infrastructure réseau : topologie hub-and-spoke, inventaire équipements Cisco, architecture de sécurité.", keyPoints: ["Architecture hub-and-spoke", "50 serveurs physiques, 200 VMs", "Équipements Cisco EOL 2025"] },
  "Organigramme_DSI.pptx": { summary: "Organigramme de la DSI, rôles et responsabilités, reporting hiérarchique et relations avec les directions métiers.", keyPoints: ["~2 500 utilisateurs internes", "800 utilisateurs externes", "Structure DSI complète"] },
  "Audit_réseau_2023.xlsx": { summary: "Résultats d'audit réseau 2023 : performances, vulnérabilités, recommandations et plan d'action.", keyPoints: ["Audit complet du réseau", "Vulnérabilités identifiées", "Recommandations priorisées"] },
  "Plan_migration_cloud.pdf": { summary: "Plan de migration vers le cloud (AWS/Azure) avec calendrier, applications cibles et analyse des risques.", keyPoints: ["Migration cloud 60% cible", "ERP SAP, CRM Salesforce", "Systèmes critiques identifiés"] },
  "Budget_DSI_2024_2026.xlsx": { summary: "Budget prévisionnel DSI 2024-2026 par catégorie : investissements, fonctionnement, projets et maintenance.", keyPoints: ["Budget triennal détaillé", "Investissements vs fonctionnement", "Projets et maintenance"] },
};

interface IngestionDoc {
  id: number;
  name: string;
  type: string;
  size: string;
  status: "tagged" | "processing" | "uploading" | "error";
  progress: number;
  tags: string[];
  mappedTo: string | null;
}

const initialDocs: IngestionDoc[] = [
  { id: 1, name: "Politique_Sécurité_2024.pdf", type: "PDF", size: "2.4 MB", status: "tagged", progress: 100, tags: ["Politique sécurité", "Sécurité technique"], mappedTo: null },
  { id: 2, name: "Infra_réseau_mapping_v3.pptx", type: "PPT", size: "8.1 MB", status: "tagged", progress: 100, tags: ["Réseaux", "Architectures"], mappedTo: null },
  { id: 3, name: "Budget_DSI_2024_2026.xlsx", type: "XLS", size: "1.2 MB", status: "processing", progress: 62, tags: [], mappedTo: null },
  { id: 4, name: "Plan_migration_cloud.pdf", type: "PDF", size: "3.7 MB", status: "tagged", progress: 100, tags: ["Projets & Budget"], mappedTo: null },
  { id: 5, name: "Organigramme_DSI.pptx", type: "PPT", size: "5.0 MB", status: "error", progress: 34, tags: [], mappedTo: null },
  { id: 6, name: "Audit_réseau_2023.xlsx", type: "XLS", size: "4.3 MB", status: "uploading", progress: 27, tags: [], mappedTo: null },
];

function flattenTreeLeaves(nodes: TreeNodeData[]): { id: string; label: string; path: string }[] {
  const result: { id: string; label: string; path: string }[] = [];
  function walk(list: TreeNodeData[], parentPath: string) {
    for (const n of list) {
      const fullPath = parentPath ? `${parentPath} / ${n.label}` : n.label;
      if (n.children.length === 0) {
        result.push({ id: n.id, label: n.label, path: fullPath });
      } else {
        walk(n.children, fullPath);
      }
    }
  }
  walk(nodes, "");
  return result;
}

const allLeafTags = flattenTreeLeaves(TREE_DATA);

function TreeTagDropdown({ selected, onChange, onClose }: {
  selected: string[]; onChange: (tags: string[]) => void; onClose: () => void;
}) {
  const [search, setSearch] = useState("");
  const [expanded, setExpanded] = useState(new Set(["as-is"]));
  const filtered = allLeafTags.filter(t =>
    t.label.toLowerCase().includes(search.toLowerCase()) ||
    t.path.toLowerCase().includes(search.toLowerCase())
  );

  function renderNode(node: TreeNodeData, depth: number): React.ReactNode {
    const hasChildren = node.children.length > 0;
    const isExpanded = expanded.has(node.id);
    const isSelected = selected.includes(node.id);

    return (
      <div key={node.id}>
        <div className="flex items-center gap-1.5 px-1 py-1 rounded cursor-pointer transition-all"
          style={{ paddingLeft: 8 + depth * 14 }}
          onClick={() => {
            if (hasChildren) {
              setExpanded(prev => { const n = new Set(prev); n.has(node.id) ? n.delete(node.id) : n.add(node.id); return n; });
            } else {
              const next = isSelected ? selected.filter(s => s !== node.id) : [...selected, node.id];
              onChange(next);
            }
          }}>
          {hasChildren ? (
            <ChevronRight size={11} style={{ color: "#94A3B8", transform: isExpanded ? "rotate(90deg)" : "", transition: "transform 0.15s" }} />
          ) : (
            <div className="w-3 h-3 rounded border flex items-center justify-center shrink-0"
              style={{ borderColor: isSelected ? "#E85D7A" : "#CBD5E1", background: isSelected ? "#E85D7A" : "transparent" }}>
              {isSelected && <Check size={8} color="white" />}
            </div>
          )}
          <span style={{ fontSize: 12, color: isSelected ? "#E85D7A" : "#334155", fontWeight: isSelected ? 500 : 400 }}>{node.label}</span>
          {hasChildren && (
            <span style={{ fontSize: 10, color: "#94A3B8" }}>({node.children.length})</span>
          )}
        </div>
        {hasChildren && isExpanded && (
          <div>{node.children.map(c => renderNode(c, depth + 1))}</div>
        )}
      </div>
    );
  }

  return (
    <div className="absolute right-0 top-full mt-1 z-50 w-72 rounded-xl overflow-hidden shadow-lg"
      style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}
      onClick={e => e.stopPropagation()}>
      <div className="px-3 py-2.5" style={{ borderBottom: "1px solid #E2E8F0" }}>
        <p className="text-xs font-medium mb-2" style={{ color: "#0F172A" }}>Tags hiérarchiques</p>
        <div className="flex items-center gap-1.5 px-2 h-7 rounded text-xs" style={{ background: "#F1F5F9", border: "1px solid #E2E8F0" }}>
          <Search size={11} style={{ color: "#94A3B8" }} />
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Rechercher..." className="flex-1 bg-transparent outline-none text-xs" style={{ color: "#0F172A" }} />
        </div>
      </div>
      <div className="max-h-56 overflow-y-auto p-2">
        {search ? (
          filtered.map(t => {
            const isSelected = selected.includes(t.id);
            return (
              <div key={t.id} onClick={() => {
                const next = isSelected ? selected.filter(s => s !== t.id) : [...selected, t.id];
                onChange(next);
              }}
                className="flex items-center gap-2 px-2 py-1.5 rounded cursor-pointer"
                style={{ color: isSelected ? "#E85D7A" : "#64748B" }}>
                <div className="w-3.5 h-3.5 rounded border flex items-center justify-center shrink-0"
                  style={{ borderColor: isSelected ? "#E85D7A" : "#CBD5E1", background: isSelected ? "#E85D7A" : "transparent" }}>
                  {isSelected && <Check size={8} color="white" />}
                </div>
                <span className="text-xs">{t.path}</span>
              </div>
            );
          })
        ) : (
          TREE_DATA.map(n => renderNode(n, 0))
        )}
      </div>
      <div className="px-3 py-2 flex items-center justify-between" style={{ borderTop: "1px solid #E2E8F0", background: "#F8FAFC" }}>
        <span className="text-[11px]" style={{ color: "#94A3B8" }}>{selected.length} sélectionné{selected.length > 1 ? "s" : ""}</span>
        <button onClick={onClose} className="text-[11px] px-2.5 h-6 rounded font-medium" style={{ background: "#E85D7A", color: "white" }}>
          Valider
        </button>
      </div>
    </div>
  );
}

interface M2UploadProps { onNext: () => void; }

export function M2Upload({ onNext }: M2UploadProps) {
  const [docs, setDocs] = useState<IngestionDoc[]>(initialDocs);
  const [expectedDocs] = useState<ExpectedDoc[]>(initialExpectedDocs);
  const [expandedSummary, setExpandedSummary] = useState<string | null>(null);
  const [viewingDoc, setViewingDoc] = useState<IngestionDoc | null>(null);
  const [viewingExpectedId, setViewingExpectedId] = useState<string | null>(null);
  const [tagDropdown, setTagDropdown] = useState<string | null>(null);
  const [docTags, setDocTags] = useState<Record<string, string[]>>({});

  useEffect(() => {
    const t = setInterval(() => {
      setDocs(prev => prev.map(d => {
        if (d.status === "uploading" && d.progress < 100) {
          const p = Math.min(d.progress + Math.floor(Math.random() * 8) + 2, 100);
          return { ...d, progress: p, status: p >= 100 ? "processing" : "uploading" };
        }
        if (d.status === "processing" && d.progress < 100) {
          const p = Math.min(d.progress + Math.floor(Math.random() * 5) + 1, 100);
          return { ...d, progress: p, status: p >= 100 ? "tagged" : "processing" };
        }
        return d;
      }));
    }, 400);
    return () => clearInterval(t);
  }, []);

  const docForExpected = (expectedId: string): IngestionDoc | undefined => {
    const suggestionMap: Record<string, string> = {
      "politique-secu": "Politique_Sécurité_2024.pdf",
      "infra-mapping": "Infra_réseau_mapping_v3.pptx",
      "budget-dsi": "Budget_DSI_2024_2026.xlsx",
      "plan-migration": "Plan_migration_cloud.pdf",
      "orga-dsi": "Organigramme_DSI.pptx",
      "audit-reseau": "Audit_réseau_2023.xlsx",
    };
    const nameSuggestion = suggestionMap[expectedId];
    const foundByName = docs.find(d => d.name === nameSuggestion);
    if (foundByName) return foundByName;
    const mapped = docs.find(d => d.mappedTo === expectedId);
    if (mapped) return mapped;
    return undefined;
  };

  const statusForExpected = (expectedId: string): "provided" | "missing" | "later" => {
    const mapped = docForExpected(expectedId);
    if (!mapped) return "missing";
    if (mapped.status === "tagged" || mapped.status === "processing") return "provided";
    if (mapped.status === "uploading") return "later";
    return "missing";
  };

  const getTagsForExpected = (expectedId: string): string[] => {
    if (docTags[expectedId]) return docTags[expectedId];
    const mapped = docForExpected(expectedId);
    return mapped?.tags || [];
  };

  const handleTagsChange = (expectedId: string, tags: string[]) => {
    setDocTags(prev => ({ ...prev, [expectedId]: tags }));
    const mapped = docForExpected(expectedId);
    if (mapped) {
      setDocs(prev => prev.map(d => d.id === mapped.id ? { ...d, tags } : d));
    }
  };

  const summaryForDoc = (doc: IngestionDoc) => docSummaries[doc.name];
  const contentForDoc = (doc: IngestionDoc) => docContents[doc.id];

  return (
    <div className="h-full flex flex-col overflow-hidden" style={{ background: "#F8FAFC" }}>
      {/* Upload zone */}
      <div className="px-6 pt-5 pb-3 shrink-0">
        <div className="rounded-xl flex flex-col items-center justify-center gap-2 cursor-pointer transition-all py-6"
          style={{ border: "2px dashed #E2E8F0", background: "#FFFFFF" }}
          onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = "#E85D7A"; (e.currentTarget as HTMLElement).style.background = "rgba(232,93,122,0.04)"; }}
          onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "#E2E8F0"; (e.currentTarget as HTMLElement).style.background = "#FFFFFF"; }}>
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "#F1F5F9" }}>
            <Upload size={18} style={{ color: "#94A3B8" }} />
          </div>
          <div className="text-center">
            <p className="text-sm font-medium" style={{ color: "#64748B" }}>Déposez les documents du client</p>
            <p className="text-xs mt-0.5" style={{ color: "#94A3B8" }}>PDF · DOCX · XLSX · PPTX — Glissez ou <span style={{ color: "#E85D7A" }}>parcourez</span></p>
          </div>
        </div>
      </div>

      {/* Big table */}
      <div className="flex-1 overflow-auto px-6 pb-5">
        <div className="rounded-xl overflow-hidden" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
          <table className="w-full text-sm" style={{ borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "#F8FAFC", borderBottom: "1px solid #E2E8F0", position: "sticky", top: 0, zIndex: 10 }}>
                <th className="text-left px-4 py-3 text-xs font-semibold" style={{ color: "#64748B", width: 120 }}>Complétude</th>
                <th className="text-left px-4 py-3 text-xs font-semibold" style={{ color: "#64748B" }}>Document attendu</th>
                <th className="text-left px-4 py-3 text-xs font-semibold" style={{ color: "#64748B" }}>Document ingéré</th>
                <th className="text-left px-4 py-3 text-xs font-semibold" style={{ color: "#64748B" }}>Aperçu / Résumé</th>
                <th className="text-left px-4 py-3 text-xs font-semibold" style={{ color: "#64748B", width: 200 }}>Tags</th>
              </tr>
            </thead>
            <tbody>
              {expectedDocs.map(expected => {
                const doc = docForExpected(expected.id);
                const status = statusForExpected(expected.id);
                const tags = getTagsForExpected(expected.id);
                const summary = doc ? summaryForDoc(doc) : null;
                const showSummary = expandedSummary === expected.id;
                const showTags = tagDropdown === expected.id;
                const isDocumentViewerOpen = viewingExpectedId === expected.id;

                return (
                  <tr key={expected.id} style={{ borderBottom: "1px solid #E2E8F0" }}
                    onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#FAFAFA"; }}
                    onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; }}>
                    {/* Complétude */}
                    <td className="px-4 py-3 align-top">
                      {status === "provided" ? (
                        <div className="flex items-center gap-1">
                          <CheckCircle size={12} style={{ color: "#10B981" }} />
                          <span className="text-[11px] font-medium" style={{ color: "#10B981" }}>Reçu</span>
                        </div>
                      ) : status === "later" ? (
                        <div className="flex items-center gap-1">
                          <Clock size={12} style={{ color: "#F59E0B" }} />
                          <span className="text-[11px] font-medium" style={{ color: "#F59E0B" }}>En cours</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1">
                          <AlertTriangle size={12} style={{ color: "#94A3B8" }} />
                          <span className="text-[11px] font-medium" style={{ color: "#94A3B8" }}>Manquant</span>
                        </div>
                      )}
                      {doc && doc.status === "uploading" && (
                        <div className="mt-1">
                          <div className="h-1 rounded-full w-16" style={{ background: "#E2E8F0" }}>
                            <div className="h-full rounded-full" style={{ width: `${doc.progress}%`, background: "#F59E0B" }} />
                          </div>
                        </div>
                      )}
                      {doc && doc.status === "error" && (
                        <span className="text-[10px]" style={{ color: "#EF4444" }}>Erreur</span>
                      )}
                    </td>

                    {/* Generic document name */}
                    <td className="px-4 py-3 align-top">
                      <p className="text-sm font-medium" style={{ color: "#0F172A" }}>{expected.name}</p>
                      <p className="text-[11px] mt-0.5" style={{ color: "#94A3B8" }}>{expected.description}</p>
                    </td>

                    {/* Mapped document */}
                    <td className="px-4 py-3 align-top">
                      {doc ? (
                        <div className="flex items-center gap-2">
                          {fileIcons[doc.type] || fileIcons.PDF}
                          <button onClick={() => { setViewingDoc(doc); setViewingExpectedId(expected.id); }}
                            className="text-sm text-left hover:underline cursor-pointer transition-all"
                            style={{ color: "#2563EB" }}>
                            {doc.name}
                          </button>
                        </div>
                      ) : (
                        <span className="text-xs" style={{ color: "#CBD5E1", fontStyle: "italic" }}>Aucun document mappé</span>
                      )}
                    </td>

                    {/* Overview / Summary */}
                    <td className="px-4 py-3 align-top">
                      {summary ? (
                        <div>
                          <button onClick={() => setExpandedSummary(showSummary ? null : expected.id)}
                            className="flex items-center gap-1 text-xs text-left transition-all"
                            style={{ color: "#64748B" }}>
                            {showSummary ? <ChevronDown size={11} /> : <ChevronRight size={11} />}
                            <span>{showSummary ? "Masquer le résumé" : "Voir le résumé"}</span>
                          </button>
                          {showSummary && (
                            <div className="mt-1.5 p-2.5 rounded-lg" style={{ background: "#F8FAFC", border: "1px solid #E2E8F0" }}>
                              <p className="text-xs leading-relaxed" style={{ color: "#334155" }}>{summary.summary}</p>
                              {summary.keyPoints.length > 0 && (
                                <ul className="mt-1.5 space-y-0.5">
                                  {summary.keyPoints.map((kp, i) => (
                                    <li key={i} className="flex items-start gap-1.5 text-[11px]" style={{ color: "#64748B" }}>
                                      <span className="w-1 h-1 rounded-full mt-1 shrink-0" style={{ background: "#8B5CF6" }} />
                                      {kp}
                                    </li>
                                  ))}
                                </ul>
                              )}
                            </div>
                          )}
                        </div>
                      ) : (
                        <span className="text-xs" style={{ color: "#CBD5E1", fontStyle: "italic" }}>En attente d'analyse</span>
                      )}
                    </td>

                    {/* Tags */}
                    <td className="px-4 py-3 align-top relative">
                      <div className="flex flex-wrap gap-1">
                        {tags.slice(0, 3).map(t => <TagChip key={t} label={t} color="gray" />)}
                        {tags.length > 3 && <span className="text-[10px]" style={{ color: "#94A3B8" }}>+{tags.length - 3}</span>}
                        <button onClick={() => setTagDropdown(showTags ? null : expected.id)}
                          className="w-5 h-5 rounded flex items-center justify-center transition-all shrink-0"
                          style={{ border: "1px solid #E2E8F0", color: "#94A3B8" }}>
                          <span style={{ fontSize: 12, lineHeight: 1 }}>+</span>
                        </button>
                      </div>
                      {showTags && (
                        <TreeTagDropdown
                          selected={tags}
                          onChange={tags => handleTagsChange(expected.id, tags)}
                          onClose={() => setTagDropdown(null)}
                        />
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          <div className="px-4 py-3 flex items-center justify-between" style={{ borderTop: "1px solid #E2E8F0", background: "#F8FAFC" }}>
            <span className="text-xs" style={{ color: "#94A3B8" }}>
              {expectedDocs.filter(e => statusForExpected(e.id) === "provided").length}/{expectedDocs.length} documents reçus
            </span>
            <button onClick={onNext}
              className="flex items-center gap-2 px-4 h-9 rounded-md text-sm font-medium transition-all"
              style={{ background: "#E85D7A", color: "white" }}>
              Basculer vers la vue en colonnes →
            </button>
          </div>
        </div>
      </div>

      {/* Document viewer modal */}
      {viewingDoc && viewingExpectedId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: "rgba(15,23,42,0.5)" }}
          onClick={() => { setViewingDoc(null); setViewingExpectedId(null); }}>
          <div className="w-[640px] max-h-[85vh] rounded-xl overflow-hidden flex flex-col" style={{ background: "#FFFFFF", boxShadow: "0 20px 60px rgba(0,0,0,0.3)" }}
            onClick={e => e.stopPropagation()}>
            <div className="px-5 py-4 flex items-center justify-between shrink-0" style={{ borderBottom: "1px solid #E2E8F0" }}>
              <div className="flex items-center gap-2.5">
                {fileIcons[viewingDoc.type || "PDF"]}
                <div>
                  <p className="text-sm font-semibold" style={{ color: "#0F172A" }}>{viewingDoc.name}</p>
                  <p className="text-[11px]" style={{ color: "#94A3B8", fontFamily: "JetBrains Mono, monospace" }}>{contentForDoc(viewingDoc)?.pages || "?"} pages · {viewingDoc.size}</p>
                </div>
              </div>
              <button onClick={() => { setViewingDoc(null); setViewingExpectedId(null); }}
                className="w-7 h-7 rounded-md flex items-center justify-center transition-all" style={{ color: "#94A3B8" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#F1F5F9"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; }}>
                <X size={14} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-5">
              {contentForDoc(viewingDoc) ? (
                <div className="rounded-xl p-5" style={{ background: "#F8FAFC", border: "1px solid #E2E8F0" }}>
                  <div className="flex items-center gap-2 mb-3">
                    <FileText size={14} style={{ color: "#E85D7A" }} />
                    <span className="text-[11px] font-semibold uppercase tracking-wider" style={{ color: "#64748B" }}>Aperçu du document</span>
                  </div>
                  <p className="text-sm leading-relaxed" style={{ color: "#334155" }}>
                    {contentForDoc(viewingDoc)?.content}
                  </p>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-12">
                  <FileText size={32} style={{ color: "#CBD5E1" }} />
                  <p className="text-sm mt-3" style={{ color: "#94A3B8" }}>Contenu non disponible pour ce document</p>
                </div>
              )}
            </div>
            <div className="px-5 py-3 flex items-center justify-end gap-2 shrink-0" style={{ borderTop: "1px solid #E2E8F0", background: "#F8FAFC" }}>
              <button onClick={() => { setViewingDoc(null); setViewingExpectedId(null); }}
                className="px-3 h-8 rounded-md text-xs transition-all" style={{ border: "1px solid #E2E8F0", color: "#64748B", background: "#FFFFFF" }}>
                Fermer
              </button>
              <button className="flex items-center gap-1.5 px-3 h-8 rounded-md text-xs transition-all"
                style={{ background: "#E85D7A", color: "white" }}
                onClick={() => { setViewingDoc(null); setViewingExpectedId(null); }}>
                <ExternalLink size={11} /> Ouvrir dans le navigateur
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
