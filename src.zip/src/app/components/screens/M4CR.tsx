import { useState, useEffect } from "react";
import { Pencil, Trash2, Plus } from "lucide-react";
import { AIBadge, GoldButton, GhostButton } from "../ui-kit";

const crBlocks = [
  { id: "ctx",    type: "section", title: "Contexte de l'atelier",  aiGenerated: true,  content: "Atelier conduit le 11 juin 2026 au siège de la Banque Centrale Maghreb. Participants: M. Khalil Ben Ali (DSI), S. Consultant (Devoteam). Durée: 2h15." },
  { id: "part",   type: "list",    title: "Participants",            aiGenerated: false, items: ["M. Khalil Ben Ali — Directeur des Systèmes d'Information", "Sarah Consultant — Consultante Senior Devoteam"] },
  { id: "obs",    type: "list",    title: "Observations clés",       aiGenerated: true,  items: ["Architecture hub-and-spoke datant de 2018, non adaptée à la croissance des flux", "Absence de redondance WAN sur les 3 sites régionaux", "Aucun plan de migration documenté à ce jour"] },
  { id: "const",  type: "list",    title: "Constats",                aiGenerated: true,  items: ["Infrastructure réseau en fin de vie (EOL Cisco 2025)", "Pas de RSSI full-time — gouvernance sécurité fragile", "Budget SI sous-dimensionné vs benchmarks sectoriels"] },
  { id: "besoins",type: "list",    title: "Besoins identifiés",      aiGenerated: true,  items: ["Migration vers architecture SD-WAN à horizon 2 ans", "Recrutement d'un RSSI ou externalisation MSSP", "Audit de sécurité externe annuel"] },
  { id: "zones",  type: "danger",  title: "Zones d'ombre persistantes", aiGenerated: false, items: ["État réel du datacenter secondaire de Sfax", "Inventaire applicatif complet non disponible"] },
  { id: "next",   type: "list",    title: "Prochaines étapes",       aiGenerated: false, items: ["Atelier RSSI prévu le 16 juin 2026", "Demande d'inventaire applicatif complet à la DSI"] },
];

const maturityUpdates = [
  { label: "Infrastructure Réseaux",   from: "unknown",  to: "obsolete" },
  { label: "Gouvernance SI",           from: "unknown",  to: "partial"  },
  { label: "Politique Sécurité",       from: "unknown",  to: "partial"  },
];

const maturityColors: Record<string, string> = {
  covered: "#10B981", partial: "#F59E0B", obsolete: "#EF4444", unknown: "#6B7280",
};

const maturityLabels: Record<string, string> = {
  covered: "Couvert", partial: "Partiel", obsolete: "Obsolète", unknown: "Inconnu",
};

interface M4CRProps { onNext: () => void; }

export function M4CR({ onNext }: M4CRProps) {
  const [phase, setPhase] = useState<"loading" | "editor">("loading");
  const [progress, setProgress] = useState(0);
  const [step, setStep] = useState(0);
  const steps = ["Synthèse des notes...", "Intégration des réponses client...", "Structuration du CR..."];

  useEffect(() => {
    if (phase !== "loading") return;
    const t = setInterval(() => {
      setProgress(p => {
        if (p >= 100) { clearInterval(t); setPhase("editor"); return 100; }
        return p + 4;
      });
    }, 60);
    const s = setInterval(() => setStep(st => Math.min(st + 1, steps.length - 1)), 600);
    return () => { clearInterval(t); clearInterval(s); };
  }, [phase]);

  if (phase === "loading") {
    return (
      <div className="h-full flex items-center justify-center" style={{ background: "#F8FAFC" }}>
        <div className="rounded-xl p-8 w-full max-w-md" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
          <div className="flex items-center gap-3 mb-5">
            <span className="text-2xl">✨</span>
            <h3>Génération du compte rendu en cours...</h3>
          </div>
          <div className="h-1 rounded-full mb-3" style={{ background: "#E2E8F0" }}>
            <div className="h-full rounded-full transition-all duration-300"
              style={{ width: `${progress}%`, background: "linear-gradient(90deg, #E85D7A, #10B981)" }} />
          </div>
          <p className="text-sm" style={{ color: "#8B5CF6" }}>{steps[step]}</p>
          <p className="text-xs mt-2" style={{ color: "#94A3B8" }}>~15 secondes</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex overflow-hidden" style={{ background: "#F8FAFC" }}>
      {/* Main document */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="px-6 py-4 flex items-center gap-3 shrink-0" style={{ borderBottom: "1px solid #E2E8F0", background: "#FFFFFF" }}>
          <div>
            <div className="flex items-center gap-2">
              <h3>Compte Rendu — Direction SI — 11 juin 2026</h3>
              <AIBadge />
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto px-8 py-5 space-y-4">
          {crBlocks.map(block => (
            <div key={block.id} className="group rounded-lg overflow-hidden"
              style={{
                background: "#FFFFFF",
                border: `1px solid ${block.type === "danger" ? "rgba(239,68,68,0.3)" : "#E2E8F0"}`,
                borderLeft: `3px solid ${block.aiGenerated ? "#8B5CF6" : "#E85D7A"}`,
              }}>
              <div className="px-4 py-3 flex items-center justify-between" style={{ borderBottom: "1px solid #E2E8F0" }}>
                <div className="flex items-center gap-2">
                  <h4 style={{ fontSize: 13 }}>{block.title}</h4>
                  {block.type === "danger" && <span className="text-xs" style={{ color: "#EF4444" }}>⚠️ Zone d'ombre</span>}
                </div>
                <div className="flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="p-1 rounded" style={{ color: "#94A3B8" }}><Pencil size={12} /></button>
                  <button className="p-1 rounded" style={{ color: "#94A3B8" }}><Trash2 size={12} /></button>
                  <button className="p-1 rounded" style={{ color: "#94A3B8" }}><Plus size={12} /></button>
                </div>
              </div>
              <div className="px-4 py-3">
                {block.type === "section" && (
                  <p className="text-sm leading-relaxed" style={{ color: "#64748B" }}>{block.content}</p>
                )}
                {(block.type === "list" || block.type === "danger") && block.items && (
                  <ul className="space-y-1.5">
                    {block.items.map((item, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm" style={{ color: "#64748B" }}>
                        <span className="shrink-0 mt-2 w-1 h-1 rounded-full" style={{ background: block.type === "danger" ? "#EF4444" : (block.aiGenerated ? "#8B5CF6" : "#E85D7A") }} />
                        {item}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="px-6 py-4 flex items-center justify-between shrink-0" style={{ borderTop: "1px solid #E2E8F0" }}>
          <GhostButton>← Relancer la génération</GhostButton>
          <GoldButton onClick={onNext}>⚖️ Enregistrer le CR</GoldButton>
        </div>
      </div>

      {/* Right sidebar — mapping */}
      <div className="w-60 shrink-0 flex flex-col overflow-hidden" style={{ borderLeft: "1px solid #E2E8F0" }}>
        <div className="px-4 py-3 shrink-0" style={{ borderBottom: "1px solid #E2E8F0", background: "#FFFFFF" }}>
          <h4 style={{ fontSize: 12 }}>Briques mises à jour</h4>
          <p className="text-[11px] mt-0.5" style={{ color: "#94A3B8" }}>3 briques après enregistrement</p>
        </div>
        <div className="flex-1 p-3 space-y-2 overflow-y-auto">
          {maturityUpdates.map((u, i) => (
            <div key={i} className="px-3 py-2.5 rounded-lg" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
              <p className="text-xs mb-2" style={{ color: "#0F172A" }}>{u.label}</p>
              <div className="flex items-center gap-2">
                <span className="text-[11px] px-1.5 py-0.5 rounded" style={{ background: `${maturityColors[u.from]}15`, color: maturityColors[u.from] }}>{maturityLabels[u.from]}</span>
                <span style={{ color: "#94A3B8", fontSize: 12 }}>→</span>
                <span className="text-[11px] px-1.5 py-0.5 rounded" style={{ background: `${maturityColors[u.to]}15`, color: maturityColors[u.to] }}>{maturityLabels[u.to]}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
