import { useState } from "react";
import {
  ChevronLeft, ChevronRight, X, Check, Plus, Pencil, Lock,
  Calendar, Users, Building2, BookOpen, Sparkles, LayoutGrid, List,
} from "lucide-react";
import { AIActionButton, GoldButton } from "../ui-kit";

const dsiEntities = [
  { id: "dsi", label: "Direction SI" },
  { id: "rssi", label: "RSSI" },
  { id: "infra", label: "Equipe Infrastructure" },
  { id: "data", label: "Equipe Data & Analytics" },
  { id: "dev", label: "Equipe Developpement" },
];

const themes = ["Data", "Securite", "Infra", "IT"];

const frameworks = [
  {
    name: "COBIT 2019",
    subs: [
      "EDM01 - Cadre de gouvernance",
      "EDM02 - Realisation des benefices",
      "APO01 - Gestion du SI",
      "APO07 - Ressources humaines",
      "DSS01 - Operations",
      "DSS05 - Securite",
    ],
  },
  {
    name: "ITIL 4",
    subs: ["Strategie", "Conception", "Transition", "Exploitation", "Amelioration continue"],
  },
  {
    name: "ISO 27001",
    subs: [
      "Politique securite (A.5)",
      "Organisation securite (A.6)",
      "Securite RH (A.7)",
      "Gestion actifs (A.8)",
      "Securite physique (A.11)",
    ],
  },
];

const questionsFromPrevious = [
  "Quel est le taux de virtualisation actuel ?",
  "Disposez-vous d'un PCA documente ?",
  "Quelle est la politique de retention des backups ?",
  "Avez-vous realise un audit securite recemment ?",
  "Quels sont les projets SI en cours ?",
];

const generatedSlots = [
  { id: 1, label: "Atelier 1 - Gouvernance SI", day: "Lun 9", duration: 3, consultant: "SC", participant: "M. Ben Ali" },
  { id: 2, label: "Atelier 2 - Securite SI",    day: "Mer 11", duration: 4, consultant: "AL", participant: null },
  { id: 3, label: "Atelier 3 - Infrastructure",  day: "Lun 16", duration: 3, consultant: null, participant: null },
  { id: 4, label: "Atelier 4 - Data & Analytics", day: "Mer 18", duration: 2, consultant: "JD", participant: "M. Trabelsi" },
];

const teamMembers = [
  { initials: "SC", name: "Sarah Consultant", role: "Consultant Senior" },
  { initials: "AL", name: "Alex Lefevre", role: "Consultant Manager" },
  { initials: "JD", name: "Jean Dupont", role: "Consultant" },
  { initials: "PM", name: "Paul Martin", role: "Expert Technique" },
];

const days = ["Lun 9", "Mar 10", "Mer 11", "Jeu 12", "Ven 13", "Lun 16", "Mar 17", "Mer 18", "Jeu 19", "Ven 20"];

function CardSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl p-5" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
      <p className="text-xs font-semibold mb-3 uppercase tracking-wider" style={{ color: "#64748B" }}>{title}</p>
      {children}
    </div>
  );
}

interface M4GanttProps { onCockpit: () => void; }

export function M4Gantt({ onCockpit }: M4GanttProps) {
  const [step, setStep] = useState<"config" | "planning">("config");
  const [role] = useState("Chef de Projet");
  const [workshopCount, setWorkshopCount] = useState(4);

  const [dateDebut, setDateDebut] = useState("2026-06-09");
  const [dateFin, setDateFin] = useState("2026-06-20");
  const [atelierType, setAtelierType] = useState<"technique" | "metier" | null>(null);
  const [techniqueSubType, setTechniqueSubType] = useState<"thematique" | "entite" | null>(null);
  const [selectedThemes, setSelectedThemes] = useState<string[]>([]);
  const [selectedEntity, setSelectedEntity] = useState<string | null>(null);
  const [selectedFramework, setSelectedFramework] = useState<string | null>(null);
  const [selectedSubs, setSelectedSubs] = useState<string[]>([]);
  const [metierEntities, setMetierEntities] = useState<string[]>([]);
  const [metierMembers, setMetierMembers] = useState<string[]>([]);

  const [selectedSlot, setSelectedSlot] = useState<number | null>(null);
  const [questions, setQuestions] = useState(questionsFromPrevious.map((t, i) => ({ id: i + 1, text: t, slotId: (i % generatedSlots.length) + 1 })));
  const [planningView, setPlanningView] = useState<"gantt" | "questions">("gantt");

  const canConfig = role === "Chef de Projet";

  const toggleSub = (sub: string) => {
    setSelectedSubs(prev => prev.includes(sub) ? prev.filter(s => s !== sub) : [...prev, sub]);
  };

  const toggleMetierEntity = (id: string) => {
    setMetierEntities(prev => prev.includes(id) ? prev.filter(e => e !== id) : [...prev, id]);
  };

  const toggleMember = (initials: string) => {
    setMetierMembers(prev => prev.includes(initials) ? prev.filter(m => m !== initials) : [...prev, initials]);
  };

  const generatePlanning = () => {
    setStep("planning");
  };

  const toggleTheme = (th: string) => {
    setSelectedThemes(prev => prev.includes(th) ? prev.filter(t => t !== th) : [...prev, th]);
  };

  // ── Config step ──
  if (step === "config") {
    return (
      <div className="h-full overflow-y-auto" style={{ background: "#F8FAFC" }}>
        <div className="max-w-3xl mx-auto p-6 space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold" style={{ color: "#0F172A" }}>Configuration des ateliers</h2>
              <p className="text-xs mt-0.5" style={{ color: "#94A3B8" }}>Parametrez avant de generer le planning visuel</p>
            </div>
            <span className="px-2 py-0.5 rounded text-xs font-medium" style={{ background: "rgba(232,93,122,0.1)", color: "#E85D7A" }}>
              {role}
            </span>
          </div>

          {!canConfig ? (
            <div className="rounded-xl p-8 text-center" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
              <Lock size={24} style={{ color: "#CBD5E1", margin: "0 auto 12px" }} />
              <p className="text-sm" style={{ color: "#64748B" }}>Seul le Chef de Projet peut configurer les ateliers.</p>
            </div>
          ) : (
            <>
              <CardSection title="1. Période temporelle & nombre d'ateliers">
                <div className="flex items-center gap-4 mb-4">
                  <div className="flex items-center gap-2">
                    <Calendar size={14} style={{ color: "#94A3B8" }} />
                    <span className="text-xs" style={{ color: "#64748B" }}>Du</span>
                    <input type="date" value={dateDebut} onChange={e => setDateDebut(e.target.value)}
                      className="h-8 px-2 rounded text-xs outline-none"
                      style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#0F172A" }} />
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs" style={{ color: "#64748B" }}>Au</span>
                    <input type="date" value={dateFin} onChange={e => setDateFin(e.target.value)}
                      className="h-8 px-2 rounded text-xs outline-none"
                      style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#0F172A" }} />
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xs" style={{ color: "#64748B" }}>Nombre d'ateliers :</span>
                  <div className="flex items-center gap-1">
                    <button onClick={() => setWorkshopCount(Math.max(1, workshopCount - 1))}
                      className="w-7 h-7 rounded flex items-center justify-center transition-all"
                      style={{ border: "1px solid #E2E8F0", color: "#64748B", background: "#FFFFFF" }}>
                      −
                    </button>
                    <input type="number" value={workshopCount} onChange={e => setWorkshopCount(Math.max(1, parseInt(e.target.value) || 1))}
                      className="w-14 h-7 text-center rounded text-xs outline-none"
                      style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#0F172A", fontFamily: "JetBrains Mono, monospace" }} />
                    <button onClick={() => setWorkshopCount(Math.min(10, workshopCount + 1))}
                      className="w-7 h-7 rounded flex items-center justify-center transition-all"
                      style={{ border: "1px solid #E2E8F0", color: "#64748B", background: "#FFFFFF" }}>
                      +
                    </button>
                  </div>
                  <span className="text-[10px]" style={{ color: "#94A3B8" }}>max. 10</span>
                </div>
              </CardSection>

              <CardSection title="2. Type d'atelier">
                <div className="flex gap-3">
                  {(["technique", "metier"] as const).map(t => (
                    <button key={t} onClick={() => { setAtelierType(t); setTechniqueSubType(null); setSelectedFramework(null); setSelectedSubs([]); }}
                      className="flex-1 h-10 rounded-lg text-sm font-medium transition-all"
                      style={{
                        background: atelierType === t ? "rgba(232,93,122,0.1)" : "#FFFFFF",
                        color: atelierType === t ? "#E85D7A" : "#64748B",
                        border: atelierType === t ? "1.5px solid #E85D7A" : "1px solid #E2E8F0",
                      }}>
                      {t === "technique" ? "Technique" : "Metier"}
                    </button>
                  ))}
                </div>

                {atelierType === "technique" && (
                  <div className="mt-4 space-y-4">
                    <p className="text-xs font-medium" style={{ color: "#64748B" }}>Organisation par :</p>
                    <div className="flex gap-3">
                      <button onClick={() => setTechniqueSubType("thematique")}
                        className="flex items-center gap-2 px-4 h-9 rounded-lg text-xs font-medium transition-all"
                        style={{
                          background: techniqueSubType === "thematique" ? "rgba(232,93,122,0.1)" : "#FFFFFF",
                          color: techniqueSubType === "thematique" ? "#E85D7A" : "#64748B",
                          border: techniqueSubType === "thematique" ? "1.5px solid #E85D7A" : "1px solid #E2E8F0",
                        }}>
                        <BookOpen size={14} /> Thematique
                      </button>
                      <button onClick={() => setTechniqueSubType("entite")}
                        className="flex items-center gap-2 px-4 h-9 rounded-lg text-xs font-medium transition-all"
                        style={{
                          background: techniqueSubType === "entite" ? "rgba(232,93,122,0.1)" : "#FFFFFF",
                          color: techniqueSubType === "entite" ? "#E85D7A" : "#64748B",
                          border: techniqueSubType === "entite" ? "1.5px solid #E85D7A" : "1px solid #E2E8F0",
                        }}>
                        <Building2 size={14} /> Entite client DSI
                      </button>
                    </div>

                    {techniqueSubType === "thematique" && (
                      <div>
                        <p className="text-xs mb-2" style={{ color: "#64748B" }}>Choisir une ou plusieurs thematiques :</p>
                        <div className="flex flex-wrap gap-2">
                          {themes.map(th => {
                            const sel = selectedThemes.includes(th);
                            return (
                              <button key={th} onClick={() => toggleTheme(th)}
                                className="px-3 h-8 rounded-lg text-xs font-medium transition-all"
                                style={{
                                  background: sel ? "rgba(232,93,122,0.1)" : "#FFFFFF",
                                  color: sel ? "#E85D7A" : "#64748B",
                                  border: sel ? "1.5px solid #E85D7A" : "1px solid #E2E8F0",
                                }}>
                                {th}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {techniqueSubType === "entite" && (
                      <div>
                        <p className="text-xs mb-2" style={{ color: "#64748B" }}>Choisir une entite DSI :</p>
                        <select value={selectedEntity || ""} onChange={e => setSelectedEntity(e.target.value || null)}
                          className="w-full h-9 px-3 rounded-lg text-xs outline-none"
                          style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#0F172A" }}>
                          <option value="">Selectionner...</option>
                          {dsiEntities.map(e => <option key={e.id} value={e.id}>{e.label}</option>)}
                        </select>
                      </div>
                    )}
                  </div>
                )}

                {atelierType === "metier" && (
                  <div className="mt-4 space-y-4">
                    <div>
                      <p className="text-xs mb-2" style={{ color: "#64748B" }}>Entites metier concernees :</p>
                      <div className="flex flex-wrap gap-2">
                        {dsiEntities.map(e => (
                          <button key={e.id} onClick={() => toggleMetierEntity(e.id)}
                            className="px-3 h-8 rounded-lg text-xs font-medium transition-all"
                            style={{
                              background: metierEntities.includes(e.id) ? "rgba(232,93,122,0.1)" : "#FFFFFF",
                              color: metierEntities.includes(e.id) ? "#E85D7A" : "#64748B",
                              border: metierEntities.includes(e.id) ? "1.5px solid #E85D7A" : "1px solid #E2E8F0",
                            }}>
                            {e.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <p className="text-xs mb-2" style={{ color: "#64748B" }}>Membres de l'equipe a associer :</p>
                      <div className="flex flex-wrap gap-2">
                        {teamMembers.map(m => (
                          <button key={m.initials} onClick={() => toggleMember(m.initials)}
                            className="flex items-center gap-1.5 px-3 h-8 rounded-lg text-xs font-medium transition-all"
                            style={{
                              background: metierMembers.includes(m.initials) ? "rgba(232,93,122,0.1)" : "#FFFFFF",
                              color: metierMembers.includes(m.initials) ? "#E85D7A" : "#64748B",
                              border: metierMembers.includes(m.initials) ? "1.5px solid #E85D7A" : "1px solid #E2E8F0",
                            }}>
                            <span className="w-4 h-4 rounded-full flex items-center justify-center text-[8px] font-bold"
                              style={{ background: metierMembers.includes(m.initials) ? "#E85D7A" : "#CBD5E1", color: "white" }}>
                              {m.initials}
                            </span>
                            {m.name}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </CardSection>

              {atelierType === "technique" && (
                <CardSection title="3. Framework de reference">
                  <div className="flex gap-2 mb-4">
                    {frameworks.map(fw => (
                      <button key={fw.name} onClick={() => { setSelectedFramework(fw.name); setSelectedSubs([]); }}
                        className="px-3 h-8 rounded-lg text-xs font-medium transition-all"
                        style={{
                          background: selectedFramework === fw.name ? "rgba(232,93,122,0.1)" : "#FFFFFF",
                          color: selectedFramework === fw.name ? "#E85D7A" : "#64748B",
                          border: selectedFramework === fw.name ? "1.5px solid #E85D7A" : "1px solid #E2E8F0",
                        }}>
                        {fw.name}
                      </button>
                    ))}
                  </div>

                  {selectedFramework && (
                    <div>
                      <p className="text-xs mb-2" style={{ color: "#64748B" }}>Sections a couvrir :</p>
                      <div className="space-y-1">
                        {frameworks.find(f => f.name === selectedFramework)?.subs.map(sub => {
                          const sel = selectedSubs.includes(sub);
                          return (
                            <label key={sub}
                              className="flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer transition-all"
                              style={{ background: sel ? "rgba(232,93,122,0.06)" : "#F8FAFC" }}>
                              <input type="checkbox" checked={sel} onChange={() => toggleSub(sub)}
                                className="shrink-0 accent-[#E85D7A]" />
                              <span className="text-xs" style={{ color: "#64748B" }}>{sub}</span>
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </CardSection>
              )}

              <CardSection title={atelierType === "technique" ? "4. Questions de l'atelier" : "3. Questions de l'atelier"}>
                <p className="text-xs mb-3" style={{ color: "#64748B" }}>
                  Questions issues du module precedent ({questions.length}) :
                </p>
                <div className="space-y-1.5 mb-4">
                  {questions.map(q => (
                    <div key={q.id} className="flex items-center gap-2 px-3 py-2 rounded-lg" style={{ background: "#F8FAFC", border: "1px solid #E2E8F0" }}>
                      <Check size={11} style={{ color: "#10B981" }} />
                      <span className="text-xs" style={{ color: "#0F172A" }}>{q.text}</span>
                    </div>
                  ))}
                </div>

                {atelierType === "technique" && selectedSubs.length > 0 && (
                  <>
                    <p className="text-xs mb-2" style={{ color: "#64748B" }}>
                      Questions generees depuis les sections selectionnees ({selectedSubs.length}) :
                    </p>
                    <div className="space-y-1.5">
                      {selectedSubs.map((sub, i) => (
                        <div key={i} className="flex items-center gap-2 px-3 py-2 rounded-lg" style={{ background: "rgba(232,93,122,0.04)", border: "1px solid rgba(232,93,122,0.15)" }}>
                          <Sparkles size={11} style={{ color: "#E85D7A" }} />
                          <span className="text-xs" style={{ color: "#0F172A" }}>Question basee sur {sub}</span>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </CardSection>

              <div className="flex justify-end pt-2">
                <button onClick={generatePlanning}
                  className="h-10 px-6 rounded-lg text-sm font-semibold transition-all"
                  style={{ background: "#E85D7A", color: "white" }}>
                  Generer le Planning
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    );
  }

  // ── Planning step ──
  const selectedSlotData = generatedSlots.find(s => s.id === selectedSlot);
  const currentUserRole = "Chef de Projet";
  const isSenior = ["Consultant Senior", "Consultant Manager", "Partner", "Directeur de Mission", "Chef de Projet"].includes(currentUserRole);
  const canEdit = isSenior;

  return (
    <div className="h-full flex overflow-hidden" style={{ background: "#F8FAFC" }}>
      <div className="flex-1 flex flex-col overflow-hidden">
        <div className="px-5 py-3 flex items-center gap-3 shrink-0" style={{ borderBottom: "1px solid #E2E8F0", background: "#FFFFFF" }}>
          <button onClick={() => setStep("config")} className="flex items-center gap-1 text-xs" style={{ color: "#94A3B8" }}>
            <ChevronLeft size={12} /> Retour config
          </button>
          <h3 className="text-sm font-semibold" style={{ color: "#0F172A" }}>Planning des Ateliers</h3>
          <div className="flex rounded-md overflow-hidden ml-2" style={{ border: "1px solid #E2E8F0" }}>
            <button onClick={() => setPlanningView("gantt")}
              className="flex items-center gap-1.5 px-3 h-7 text-xs transition-all"
              style={{ background: planningView === "gantt" ? "#F1F5F9" : "transparent", color: planningView === "gantt" ? "#0F172A" : "#64748B", fontWeight: planningView === "gantt" ? 500 : 400 }}>
              <LayoutGrid size={12} /> Planning
            </button>
            <button onClick={() => setPlanningView("questions")}
              className="flex items-center gap-1.5 px-3 h-7 text-xs transition-all"
              style={{ background: planningView === "questions" ? "#F1F5F9" : "transparent", color: planningView === "questions" ? "#0F172A" : "#64748B", fontWeight: planningView === "questions" ? 500 : 400, borderLeft: "1px solid #E2E8F0" }}>
              <List size={12} /> Questions
            </button>
          </div>
          <span className="px-2 py-0.5 rounded text-[11px]" style={{ background: "rgba(232,93,122,0.1)", color: "#E85D7A" }}>
            {currentUserRole}
            {!canEdit && <Lock size={10} />}
          </span>
          <div className="ml-auto flex items-center gap-2">
            <button className="w-7 h-7 rounded flex items-center justify-center" style={{ background: "#F1F5F9", border: "1px solid #E2E8F0", color: "#64748B" }}>
              <ChevronLeft size={14} />
            </button>
            <span className="text-sm px-3" style={{ color: "#0F172A" }}>Juin 2026</span>
            <button className="w-7 h-7 rounded flex items-center justify-center" style={{ background: "#F1F5F9", border: "1px solid #E2E8F0", color: "#64748B" }}>
              <ChevronRight size={14} />
            </button>
          </div>
        </div>

        {planningView === "gantt" ? (
          <div className="flex-1 overflow-auto">
            <div className="min-w-[800px]">
              <div className="flex sticky top-0 z-10" style={{ background: "#FFFFFF", borderBottom: "1px solid #E2E8F0" }}>
                <div className="w-64 shrink-0 px-4 py-2 text-xs font-medium" style={{ color: "#94A3B8" }}>Atelier</div>
                {days.map(d => (
                  <div key={d} className="flex-1 text-center py-2 text-xs" style={{ color: "#94A3B8", fontFamily: "JetBrains Mono, monospace", borderLeft: "1px solid #E2E8F0" }}>
                    {d}
                  </div>
                ))}
              </div>

              {generatedSlots.map(slot => {
                const startIdx = days.indexOf(slot.day);
                return (
                  <div key={slot.id} className="flex items-center group" style={{ borderBottom: "1px solid #E2E8F0", minHeight: 52 }}>
                    <div className="w-64 shrink-0 px-4 py-3">
                      <p className="text-xs leading-tight" style={{ color: "#0F172A" }}>{slot.label}</p>
                      <div className="flex gap-3 mt-1">
                        {slot.consultant && (
                          <span className="flex items-center gap-1 text-[10px]" style={{ color: "#94A3B8" }}>
                            <Users size={10} /> {slot.consultant}
                          </span>
                        )}
                        {slot.participant && (
                          <span className="text-[10px]" style={{ color: "#94A3B8" }}>{slot.participant}</span>
                        )}
                      </div>
                    </div>
                    <div className="flex-1 relative h-full flex items-center" style={{ minHeight: 52 }}>
                      {days.map((_, i) => (
                        <div key={i} className="absolute top-0 bottom-0" style={{ left: `${(i / days.length) * 100}%`, width: "1px", background: "#F1F5F9" }} />
                      ))}
                      <div
                        className="absolute flex items-center justify-center h-9 rounded-md cursor-pointer transition-all"
                        style={{
                          left: `${(startIdx / days.length) * 100}%`,
                          width: `${(slot.duration / days.length) * 100}%`,
                          background: "rgba(232,93,122,0.12)",
                          border: "1px solid #E85D7A",
                          borderLeftWidth: 3,
                        }}
                        onClick={() => setSelectedSlot(selectedSlot === slot.id ? null : slot.id)}>
                        <span className="text-[11px] px-2 truncate font-medium" style={{ color: "#E85D7A" }}>
                          {slot.label.split(" - ")[0] || slot.label}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto p-6">
            <p className="text-xs font-semibold mb-4" style={{ color: "#0F172A" }}>Distribution des questions par atelier</p>
            <div className="space-y-4">
              {generatedSlots.map((slot, si) => (
                <div key={slot.id} className="rounded-xl overflow-hidden" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
                  <div className="px-4 py-3 flex items-center justify-between" style={{ background: "rgba(232,93,122,0.06)", borderBottom: "1px solid #E2E8F0" }}>
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold" style={{ background: "#E85D7A", color: "white" }}>
                        {si + 1}
                      </span>
                      <span className="text-sm font-medium" style={{ color: "#0F172A" }}>{slot.label}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px]" style={{ color: "#94A3B8" }}>{slot.day}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: "#F1F5F9", color: "#64748B" }}>{slot.duration}h</span>
                    </div>
                  </div>
                  <div className="p-4 space-y-2">
                    {questions.filter(q => q.slotId === slot.id).map(q => (
                      <div key={q.id} className="flex items-start gap-2 px-3 py-2 rounded-lg" style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", borderLeftWidth: 2, borderLeftColor: "#8B5CF6" }}>
                        <span className="w-4 h-4 rounded-full flex items-center justify-center text-[8px] font-bold shrink-0 mt-0.5" style={{ background: "rgba(139,92,246,0.15)", color: "#7C3AED" }}>
                          {q.id}
                        </span>
                        <p className="text-xs leading-relaxed" style={{ color: "#0F172A" }}>{q.text}</p>
                      </div>
                    ))}
                    {questions.filter(q => q.slotId === slot.id).length === 0 && (
                      <p className="text-xs text-center py-4" style={{ color: "#94A3B8" }}>Aucune question associée</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {selectedSlot && selectedSlotData && (
        <div className="w-80 shrink-0 flex flex-col overflow-hidden" style={{ borderLeft: "1px solid #E2E8F0", background: "#FFFFFF" }}>
          <div className="px-4 py-3 flex items-center justify-between shrink-0" style={{ borderBottom: "1px solid #E2E8F0" }}>
            <h4 className="text-sm font-semibold" style={{ color: "#0F172A" }}>{selectedSlotData.label}</h4>
            <button onClick={() => setSelectedSlot(null)} style={{ color: "#94A3B8" }}>
              <X size={14} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            <div>
              <p className="text-xs font-semibold mb-3 uppercase tracking-wider" style={{ color: "#64748B" }}>Guide complet atelier</p>
              <div className="space-y-4">
                <div>
                  <label className="block mb-1 text-xs" style={{ color: "#94A3B8" }}>Periode</label>
                  <p className="text-sm" style={{ color: "#0F172A" }}>{selectedSlotData.day}</p>
                </div>
                <div>
                  <label className="block mb-1 text-xs" style={{ color: "#94A3B8" }}>Consultant assigne</label>
                  {selectedSlotData.consultant ? (
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold"
                        style={{ background: "#E85D7A", color: "white" }}>{selectedSlotData.consultant}</div>
                      <span className="text-sm" style={{ color: "#0F172A" }}>{selectedSlotData.consultant}</span>
                    </div>
                  ) : (
                    <button className="text-xs px-2 py-1 rounded" style={{ background: "#F1F5F9", border: "1px dashed #E2E8F0", color: "#94A3B8" }}>
                      + Assigner
                    </button>
                  )}
                </div>
                <div>
                  <label className="block mb-1 text-xs" style={{ color: "#94A3B8" }}>Participant client</label>
                  {selectedSlotData.participant ? (
                    <p className="text-sm" style={{ color: "#0F172A" }}>{selectedSlotData.participant}</p>
                  ) : (
                    <button className="text-xs px-2 py-1 rounded flex items-center gap-1" style={{ background: "#F1F5F9", border: "1px dashed #E2E8F0", color: "#94A3B8" }}>
                      + Assigner
                    </button>
                  )}
                </div>
                <div>
                  <label className="block mb-1 text-xs" style={{ color: "#94A3B8" }}>Equipe Devoteam</label>
                  <div className="space-y-1">
                    {teamMembers.map(m => (
                      <div key={m.initials} className="flex items-center gap-2 px-2 py-1.5 rounded" style={{ background: "#F8FAFC" }}>
                        <div className="w-5 h-5 rounded-full flex items-center justify-center text-[8px] font-bold"
                          style={{ background: "#E85D7A", color: "white" }}>{m.initials}</div>
                        <span className="text-xs flex-1" style={{ color: "#64748B" }}>{m.name}</span>
                        <span className="text-[9px]" style={{ color: "#94A3B8" }}>{m.role}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block mb-1.5 text-xs" style={{ color: "#94A3B8" }}>Questions associees ({questions.filter(q => q.slotId === selectedSlotData.id).length})</label>
                  <div className="space-y-1.5">
                    {questions.filter(q => q.slotId === selectedSlotData.id).map(q => (
                      <div key={q.id} className="px-3 py-2 rounded-lg flex items-start gap-2"
                        style={{ background: "#F8FAFC", border: "1px solid #E2E8F0" }}>
                        <Pencil size={10} style={{ color: "#94A3B8", marginTop: 2, flexShrink: 0 }} />
                        <p className="text-xs flex-1" style={{ color: "#0F172A" }}>{q.text}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="p-4 shrink-0" style={{ borderTop: "1px solid #E2E8F0" }}>
            <GoldButton onClick={onCockpit} className="w-full justify-center">
              Demarrer l'atelier
            </GoldButton>
          </div>
        </div>
      )}
    </div>
  );
}
