import { FileText, FileSpreadsheet, Presentation, List, LayoutGrid } from "lucide-react";
import { TagChip } from "../ui-kit";

const columns = [
  { id: "asis",     label: "AS-IS",             icon: "📋", color: "#E85D7A",  count: 4 },
  { id: "cible",    label: "Cible",              icon: "🎯", color: "#8B5CF6",  count: 2 },
  { id: "roadmap",  label: "Feuille de Route",   icon: "🗺️", color: "#10B981",  count: 1 },
  { id: "transv",   label: "Transverse / Méta",  icon: "🏷️", color: "#6B7280",  count: 1 },
];

const docs = [
  { id: 1, name: "Politique_Sécurité_2024.pdf",    type: "PDF", col: "asis",    tags: ["Technique", "Sécurité"],       maturity: "partial"  },
  { id: 2, name: "Infra_réseau_mapping_v3.pptx",   type: "PPT", col: "asis",    tags: ["Technique", "Infrastructure"], maturity: "obsolete" },
  { id: 3, name: "Organigramme_DSI.pptx",          type: "PPT", col: "asis",    tags: ["AS-IS"],                      maturity: "partial"  },
  { id: 4, name: "Audit_réseau_2023.xlsx",         type: "XLS", col: "asis",    tags: ["Technique"],                  maturity: "unknown"  },
  { id: 5, name: "Plan_migration_cloud.pdf",       type: "PDF", col: "cible",   tags: ["Technique"],                  maturity: "covered"  },
  { id: 6, name: "Cloud_Strategy_v2.pdf",          type: "PDF", col: "cible",   tags: ["Roadmap"],                    maturity: "covered"  },
  { id: 7, name: "Budget_DSI_2024_2026.xlsx",      type: "XLS", col: "roadmap", tags: ["Transverse"],                 maturity: "partial"  },
  { id: 8, name: "Rapport_SI_Global.pdf",          type: "PDF", col: "transv",  tags: ["Transverse"],                 maturity: "unknown"  },
];

const fileIcons: Record<string, React.ReactNode> = {
  PDF: <FileText size={13} style={{ color: "#EF4444" }} />,
  PPT: <Presentation size={13} style={{ color: "#F59E0B" }} />,
  XLS: <FileSpreadsheet size={13} style={{ color: "#10B981" }} />,
};

const maturityColors: Record<string, string> = {
  covered: "#10B981", partial: "#F59E0B", obsolete: "#EF4444", unknown: "#6B7280",
};

const tagColorMap: Record<string, any> = {
  "Technique": "amber", "Sécurité": "red", "Infrastructure": "amber",
  "AS-IS": "blue", "Roadmap": "teal", "Transverse": "gray",
};

interface M2KanbanProps { onAnalyze: () => void; }

export function M2Kanban({ onAnalyze }: M2KanbanProps) {
  return (
    <div className="h-full flex flex-col overflow-hidden" style={{ background: "#F8FAFC" }}>
      {/* Filter toolbar */}
      <div className="px-6 py-3 flex items-center gap-3 shrink-0" style={{ borderBottom: "1px solid #E2E8F0" }}>
        <div className="flex-1" />
        <select className="h-8 px-3 rounded-md text-xs outline-none" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0", color: "#64748B" }}>
          <option>Tous les tags</option>
          <option>Technique</option>
          <option>Transverse</option>
        </select>
        <div className="flex rounded-md overflow-hidden" style={{ border: "1px solid #E2E8F0" }}>
          {[{ icon: LayoutGrid, active: true }, { icon: List, active: false }].map(({ icon: Icon, active }) => (
            <button key={String(active)} className="w-8 h-8 flex items-center justify-center transition-all"
              style={{ background: active ? "#F1F5F9" : "transparent", color: active ? "#0F172A" : "#64748B" }}>
              <Icon size={14} />
            </button>
          ))}
        </div>
      </div>

      {/* Kanban columns */}
      <div className="flex flex-1 overflow-hidden px-5 py-4 gap-4">
        {columns.map(col => {
          const colDocs = docs.filter(d => d.col === col.id);
          return (
            <div key={col.id} className="flex-1 flex flex-col rounded-xl overflow-hidden" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
              {/* Column header */}
              <div className="px-3 py-3 flex items-center gap-2 shrink-0" style={{ borderBottom: `2px solid ${col.color}22`, background: `${col.color}08` }}>
                <span>{col.icon}</span>
                <span className="text-sm font-semibold flex-1" style={{ color: col.color }}>{col.label}</span>
                <span className="w-5 h-5 rounded-full text-[11px] font-bold flex items-center justify-center"
                  style={{ background: `${col.color}20`, color: col.color, fontFamily: "JetBrains Mono, monospace" }}>
                  {colDocs.length}
                </span>
              </div>

              {/* Cards */}
              <div className="flex-1 overflow-y-auto p-3 space-y-2">
                {colDocs.map(doc => (
                  <div key={doc.id}
                    className="group rounded-lg p-3 cursor-pointer transition-all"
                    style={{ background: "#F1F5F9", border: "1px solid #E2E8F0" }}
                    onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = "#94A3B8"; (e.currentTarget as HTMLElement).style.boxShadow = "0 2px 8px rgba(0,0,0,0.3)"; }}
                    onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "#E2E8F0"; (e.currentTarget as HTMLElement).style.boxShadow = "none"; }}>
                    <div className="flex items-center gap-1.5 mb-2">
                      {fileIcons[doc.type]}
                      <span className="text-[11px]" style={{ color: "#94A3B8", fontFamily: "JetBrains Mono, monospace" }}>{doc.type}</span>
                      <div className="ml-auto w-2 h-2 rounded-full shrink-0" style={{ background: maturityColors[doc.maturity] }} />
                    </div>
                    <p className="text-xs leading-snug mb-2" style={{ color: "#0F172A" }}>{doc.name}</p>
                    <div className="flex flex-wrap gap-1">
                      {doc.tags.map(t => <TagChip key={t} label={t} color={tagColorMap[t] || "gray"} />)}
                    </div>
                    <button
                      className="mt-2 w-full h-7 rounded-md text-xs font-medium opacity-0 group-hover:opacity-100 transition-all"
                      style={{ background: "rgba(232,93,122,0.15)", color: "#E85D7A", border: "1px solid rgba(232,93,122,0.2)" }}
                      onClick={onAnalyze}>
                      Analyser →
                    </button>
                  </div>
                ))}
                {colDocs.length === 0 && (
                  <div className="text-center py-8 text-xs" style={{ color: "#E2E8F0" }}>Aucun document</div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
