import { useState } from "react";
import { Search, Plus, X, ChevronLeft, UserPlus, Briefcase, FileText, Tags, Check } from "lucide-react";
import { TREE_DATA, initialExpectedDocs } from "../../data/admin-data";
import type { ExpectedDoc, TreeNodeData } from "../../data/admin-data";

interface Consultant {
  id: string;
  initials: string;
  name: string;
  email: string;
  role: string;
  available: boolean;
}

interface Mission {
  id: number;
  client: string;
  sector: string;
  zone: string;
  status: string;
  module: number;
  coverage: number;
  consultants: string[];
  startDate: string;
}

const initialConsultants: Consultant[] = [
  { id: "1", initials: "SC", name: "Sarah Consultant", email: "sarah.consultant@devoteam.com", role: "Consultant Senior", available: true },
  { id: "2", initials: "AL", name: "Alex Lefevre", email: "alex.lefevre@devoteam.com", role: "Consultant Manager", available: true },
  { id: "3", initials: "JD", name: "Jean Dupont", email: "jean.dupont@devoteam.com", role: "Consultant", available: false },
  { id: "4", initials: "PM", name: "Paul Martin", email: "paul.martin@devoteam.com", role: "Expert Technique", available: true },
];

const initialMissions: Mission[] = [
  { id: 1, client: "Banque Centrale Maghreb", sector: "Banque", zone: "EMEA", status: "active", module: 3, coverage: 42, consultants: ["SC", "AL"], startDate: "3 juin 2026" },
  { id: 2, client: "Orange Tunisie", sector: "Télécoms", zone: "EMEA", status: "active", module: 5, coverage: 89, consultants: ["JD"], startDate: "1 juin 2026" },
  { id: 3, client: "Caisse d'Assurance", sector: "Public", zone: "EMEA", status: "active", module: 2, coverage: 20, consultants: [], startDate: "10 juin 2026" },
];



const TYPE_STYLES: Record<string, { dot: string; badge: { bg: string; color: string; label: string }; chip: { bg: string; color: string } }> = {
  "as-is-primary": { dot: "#1E40AF", badge: { bg: "#1e3a8a", color: "#bfdbfe", label: "AS-IS" }, chip: { bg: "#dbeafe", color: "#1e3a8a" } },
  "as-is": { dot: "#3B82F6", badge: { bg: "#eff6ff", color: "#1d4ed8", label: "AS-IS" }, chip: { bg: "#eff6ff", color: "#1d4ed8" } },
  "cible": { dot: "#16a34a", badge: { bg: "#dcfce7", color: "#15803d", label: "Cible" }, chip: { bg: "#dcfce7", color: "#15803d" } },
  "feuille": { dot: "#d97706", badge: { bg: "#fef3c7", color: "#92400e", label: "Feuille de route" }, chip: { bg: "#fef3c7", color: "#92400e" } }
};



const roles = ["Consultant Senior", "Consultant Manager", "Consultant", "Partner", "Directeur de Mission", "Expert Technique"];

const moduleLabels: Record<number, string> = {
  1: "M1 — Initialisation",
  2: "M2 — Ingestion",
  3: "M3 — Analyse",
  4: "M4 — Ateliers",
  5: "M5 — Synthèse",
};

const statusMap: Record<string, { label: string; color: string; bg: string }> = {
  active: { label: "En cours", color: "#E85D7A", bg: "rgba(232,93,122,0.08)" },
  completed: { label: "Clôturé", color: "#10B981", bg: "rgba(16,185,129,0.08)" },
  new: { label: "Nouveau", color: "#F59E0B", bg: "rgba(245,158,11,0.08)" },
};




const levelColors = ["", "#3B82F6", "#6366f1", "#8b5cf6", "#ec4899", "#f59e0b"];

function countTreeLeaves(node: TreeNodeData): number {
  if (node.children.length === 0) return 1;
  return node.children.reduce((acc, c) => acc + countTreeLeaves(c), 0);
}

function nodeMatches(q: string, label: string): boolean {
  return label.toLowerCase().includes(q.toLowerCase());
}

function subtreeHasMatch(node: TreeNodeData, q: string): boolean {
  if (!q) return true;
  if (nodeMatches(q, node.label)) return true;
  return node.children.some(c => subtreeHasMatch(c, q));
}

function TreeNodeComponent({ node, expanded, toggle, depth, searchQ }: {
  node: TreeNodeData; expanded: Set<string>; toggle: (id: string) => void; depth: number; searchQ: string;
}) {
  const hasChildren = node.children.length > 0;
  const isExpanded = expanded.has(node.id);
  const style = TYPE_STYLES[node.type] || TYPE_STYLES["as-is"];
  const isMatch = searchQ && node.label.toLowerCase().includes(searchQ.toLowerCase());

  return (
    <div style={{ marginLeft: depth === 0 ? 0 : 20, position: "relative" }}>
      {depth > 0 && (
        <div style={{ position: "absolute", left: -12, top: 0, bottom: 0, width: 1, background: "#E2E8F0" }} />
      )}
      <div onClick={() => hasChildren && toggle(node.id)}
        style={{
          display: "flex", alignItems: "center", gap: 8,
          padding: "7px 10px", borderRadius: 8,
          cursor: hasChildren ? "pointer" : "default",
          background: isMatch ? "#fef9c3" : "transparent",
          border: isMatch ? "1px solid #fde047" : "1px solid transparent",
          transition: "background 0.15s", marginBottom: 2, position: "relative"
        }}
        onMouseEnter={e => { if (!isMatch) (e.currentTarget as HTMLElement).style.background = "#F1F5F9"; }}
        onMouseLeave={e => { if (!isMatch) (e.currentTarget as HTMLElement).style.background = "transparent"; }}>
        {depth > 0 && (
          <div style={{ position: "absolute", left: -12, top: "50%", width: 12, height: 1, background: "#E2E8F0" }} />
        )}
        <span style={{ fontSize: 14, color: "#94A3B8", width: 16, textAlign: "center", flexShrink: 0 }}>
          {hasChildren ? (isExpanded ? "▾" : "▸") : "·"}
        </span>
        <span style={{ width: 8, height: 8, borderRadius: "50%", background: style.dot, flexShrink: 0 }} />
        <span style={{ fontSize: 14, fontWeight: depth === 0 ? 500 : 400, color: "#0F172A", flex: 1 }}>
          {node.label}
        </span>
        <span style={{
          fontSize: 10, padding: "2px 7px", borderRadius: 99, fontWeight: 500,
          background: `${levelColors[node.level]}18`,
          color: levelColors[node.level], flexShrink: 0
        }}>
          N{node.level}
        </span>
        {depth === 0 && (
          <span style={{
            fontSize: 10, padding: "2px 8px", borderRadius: 99, fontWeight: 500,
            background: style.badge.bg, color: style.badge.color, flexShrink: 0
          }}>
            {style.badge.label}
          </span>
        )}
        {hasChildren && (
          <span style={{ fontSize: 11, color: "#94A3B8", flexShrink: 0 }}>
            {countTreeLeaves(node)} feuilles
          </span>
        )}
      </div>
      {hasChildren && isExpanded && (
        <div style={{ marginLeft: 20, borderLeft: "1px solid #E2E8F0" }}>
          {node.children.filter(c => subtreeHasMatch(c, searchQ)).map(child => (
            <TreeNodeComponent key={child.id} node={child} expanded={expanded} toggle={toggle} depth={depth + 1} searchQ={searchQ} />
          ))}
        </div>
      )}
    </div>
  );
}

interface AdminScreenProps {
  onBack: () => void;
  onNavigateToMission?: (module: number) => void;
}

export function AdminScreen({ onBack, onNavigateToMission }: AdminScreenProps) {
  const [tab, setTab] = useState<"consultants" | "missions" | "documents" | "tags">("consultants");
  const [consultants, setConsultants] = useState<Consultant[]>(initialConsultants);
  const [search, setSearch] = useState("");
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newConsultant, setNewConsultant] = useState({ name: "", email: "", role: roles[0] });
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [assignConsultant, setAssignConsultant] = useState<Consultant | null>(null);
  const [selectedMission, setSelectedMission] = useState<number | null>(null);
  const [missions, setMissions] = useState<Mission[]>(initialMissions);
  const [expectedDocs, setExpectedDocs] = useState<ExpectedDoc[]>(initialExpectedDocs);
  const [newDocName, setNewDocName] = useState("");
  const [newDocDesc, setNewDocDesc] = useState("");

  const addDocument = () => {
    if (!newDocName.trim()) return;
    setExpectedDocs([...expectedDocs, {
      id: `doc-${Date.now()}`,
      name: newDocName.trim(),
      description: newDocDesc.trim(),
    }]);
    setNewDocName("");
    setNewDocDesc("");
  };

  const removeDocument = (id: string) => {
    setExpectedDocs(expectedDocs.filter(d => d.id !== id));
  };

  // Tree state
  const allExpandableIds = (() => {
    const ids: string[] = [];
    function walk(nodes: typeof TREE_DATA) {
      for (const n of nodes) {
        if (n.children.length > 0) {
          ids.push(n.id);
          walk(n.children);
        }
      }
    }
    walk(TREE_DATA);
    return ids;
  })();

  const [treeExpanded, setTreeExpanded] = useState(new Set(["as-is"]));
  const [treeSearch, setTreeSearch] = useState("");

  const toggleTreeNode = (id: string) => {
    setTreeExpanded(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const expandAllTree = () => setTreeExpanded(new Set(allExpandableIds));
  const collapseAllTree = () => setTreeExpanded(new Set());

  const totalNodes = (() => {
    function count(nodes: typeof TREE_DATA): number {
      return nodes.reduce((a, n) => a + 1 + (n.children.length > 0 ? count(n.children) : 0), 0);
    }
    return count(TREE_DATA);
  })();

  const totalLeaves = TREE_DATA.reduce((a, n) => a + countTreeLeaves(n), 0);

  const filtered = consultants.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.email.toLowerCase().includes(search.toLowerCase()) ||
    c.role.toLowerCase().includes(search.toLowerCase())
  );

  const createConsultant = () => {
    if (!newConsultant.name.trim() || !newConsultant.email.trim()) return;
    const initials = newConsultant.name.split(" ").map((n: string) => n[0]).join("").toUpperCase().slice(0, 2);
    setConsultants([...consultants, { id: Date.now().toString(), initials, ...newConsultant, available: true }]);
    setNewConsultant({ name: "", email: "", role: roles[0] });
    setShowCreateModal(false);
  };

  const assignToMission = () => {
    if (!assignConsultant || selectedMission === null) return;
    setMissions(missions.map(m =>
      m.id === selectedMission
        ? { ...m, consultants: [...m.consultants, assignConsultant.initials] }
        : m
    ));
    setConsultants(consultants.map(c =>
      c.id === assignConsultant.id ? { ...c, available: false } : c
    ));
    setShowAssignModal(false);
    setAssignConsultant(null);
    setSelectedMission(null);
  };

  return (
    <div className="h-full flex flex-col" style={{ background: "#F8FAFC" }}>
      {/* Header */}
      <div className="px-6 py-4 flex items-center justify-between shrink-0" style={{ borderBottom: "1px solid #E2E8F0", background: "#FFFFFF" }}>
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="w-8 h-8 rounded-lg flex items-center justify-center transition-all" style={{ background: "#F1F5F9", color: "#64748B", border: "1px solid #E2E8F0" }}>
            <ChevronLeft size={16} />
          </button>
          <div>
            <h2 className="text-base font-semibold" style={{ color: "#0F172A" }}>Administration</h2>
            <p className="text-xs mt-0.5" style={{ color: "#64748B" }}>Gestion des ressources, missions et référentiels</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="px-6 py-3 flex items-center gap-2 shrink-0" style={{ borderBottom: "1px solid #E2E8F0", background: "#FFFFFF" }}>
        {[
          { id: "consultants", label: "Consultants", icon: UserPlus },
          { id: "missions", label: "Missions", icon: Briefcase },
          { id: "documents", label: "Documents attendus", icon: FileText },
          { id: "tags", label: "Tags", icon: Tags },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id as any)}
            className="flex items-center gap-1.5 px-3 h-8 rounded-md text-xs font-medium transition-all"
            style={{
              background: tab === t.id ? "rgba(232,93,122,0.12)" : "#F1F5F9",
              border: `1px solid ${tab === t.id ? "rgba(232,93,122,0.3)" : "#E2E8F0"}`,
              color: tab === t.id ? "#E85D7A" : "#64748B",
            }}>
            <t.icon size={13} />
            {t.label}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        {/* === TAB CONSULTANTS === */}
        {tab === "consultants" && (
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="flex-1 flex items-center gap-2 px-3 h-10 rounded-lg" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
                <Search size={14} style={{ color: "#94A3B8" }} />
                <input value={search} onChange={e => setSearch(e.target.value)}
                  placeholder="Rechercher un consultant..."
                  className="flex-1 bg-transparent outline-none text-sm" style={{ color: "#0F172A" }} />
              </div>
              <button onClick={() => setShowCreateModal(true)}
                className="flex items-center gap-1.5 px-4 h-10 rounded-lg text-sm font-medium text-white"
                style={{ background: "#E85D7A" }}>
                <Plus size={14} /> Nouveau consultant
              </button>
            </div>
            <div className="space-y-2">
              {filtered.map(c => (
                <div key={c.id} className="flex items-center gap-3 px-4 py-3 rounded-lg"
                  style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
                  <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0"
                    style={{ background: "#E85D7A", color: "white" }}>{c.initials}</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium" style={{ color: "#0F172A" }}>{c.name}</p>
                    <p className="text-xs" style={{ color: "#94A3B8", fontFamily: "JetBrains Mono, monospace" }}>{c.email}</p>
                  </div>
                  <span className="text-[11px] px-2 py-0.5 rounded" style={{ background: "rgba(139,92,246,0.1)", color: "#8B5CF6" }}>{c.role}</span>
                  <span className="flex items-center gap-1 text-xs px-2 py-0.5 rounded"
                    style={{
                      background: c.available ? "rgba(16,185,129,0.1)" : "rgba(239,68,68,0.1)",
                      color: c.available ? "#10B981" : "#EF4444",
                    }}>
                    {c.available ? "Disponible" : "En mission"}
                  </span>
                  {c.available && (
                    <button onClick={() => { setAssignConsultant(c); setShowAssignModal(true); }}
                      className="flex items-center gap-1 px-3 h-7 rounded text-xs font-medium transition-all"
                      style={{ background: "rgba(232,93,122,0.1)", color: "#E85D7A", border: "1px solid rgba(232,93,122,0.2)" }}>
                      <UserPlus size={11} /> Affecter
                    </button>
                  )}
                </div>
              ))}
              {filtered.length === 0 && (
                <div className="text-center py-12">
                  <p className="text-sm" style={{ color: "#94A3B8" }}>Aucun consultant trouvé</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* === TAB MISSIONS === */}
        {tab === "missions" && (
          <div>
            <p className="text-xs mb-4" style={{ color: "#64748B" }}>Cliquez sur une mission pour accéder à sa phase en cours</p>
            <div className="rounded-lg overflow-hidden" style={{ border: "1px solid #E2E8F0", background: "#FFFFFF" }}>
              <table className="w-full text-sm">
                <thead>
                  <tr style={{ background: "#F8FAFC", borderBottom: "1px solid #E2E8F0" }}>
                    <th className="text-left px-4 py-3 text-xs font-semibold" style={{ color: "#64748B" }}>Client</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold" style={{ color: "#64748B" }}>Secteur</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold" style={{ color: "#64748B" }}>Zone</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold" style={{ color: "#64748B" }}>Phase</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold" style={{ color: "#64748B" }}>Statut</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold" style={{ color: "#64748B" }}>Couverture</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold" style={{ color: "#64748B" }}>Consultants</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold" style={{ color: "#64748B" }}>Date</th>
                  </tr>
                </thead>
                <tbody>
                  {missions.map(m => {
                    const s = statusMap[m.status === "active" ? "active" : m.status] || statusMap.active;
                    return (
                      <tr key={m.id}
                        onClick={() => onNavigateToMission?.(m.module)}
                        className="cursor-pointer transition-all"
                        style={{ borderBottom: "1px solid #E2E8F0" }}
                        onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#F8FAFC"; }}
                        onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; }}>
                        <td className="px-4 py-3 text-sm font-medium" style={{ color: "#0F172A" }}>{m.client}</td>
                        <td className="px-4 py-3 text-xs" style={{ color: "#64748B" }}>{m.sector}</td>
                        <td className="px-4 py-3 text-xs" style={{ color: "#94A3B8", fontFamily: "JetBrains Mono, monospace" }}>{m.zone}</td>
                        <td className="px-4 py-3">
                          <span className="text-[11px] px-2 py-0.5 rounded" style={{ background: "rgba(232,93,122,0.08)", color: "#E85D7A", fontFamily: "JetBrains Mono, monospace" }}>
                            M{m.module}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <span className="text-[11px] px-2 py-0.5 rounded font-medium" style={{ background: s.bg, color: s.color }}>{s.label}</span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <div className="w-16 h-1.5 rounded-full overflow-hidden" style={{ background: "#F1F5F9" }}>
                              <div style={{ width: `${m.coverage}%`, height: "100%", background: m.coverage >= 70 ? "#10B981" : m.coverage >= 40 ? "#D97706" : "#EF4444" }} />
                            </div>
                            <span className="text-xs" style={{ color: "#94A3B8", fontFamily: "JetBrains Mono, monospace" }}>{m.coverage}%</span>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex gap-1">
                            {m.consultants.length > 0 ? m.consultants.map(init => (
                              <span key={init} className="w-6 h-6 rounded-full flex items-center justify-center text-[9px] font-bold"
                                style={{ background: "#F1F5F9", color: "#64748B", border: "1px solid #E2E8F0" }}>{init}</span>
                            )) : (
                              <span className="text-xs" style={{ color: "#94A3B8" }}>—</span>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3 text-xs" style={{ color: "#94A3B8", fontFamily: "JetBrains Mono, monospace" }}>{m.startDate}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* === TAB DOCUMENTS ATTENDUS (Référence) === */}
        {tab === "documents" && (
          <div>
            <p className="text-xs mb-4" style={{ color: "#64748B" }}>
              Référence des documents attendus pour la mission. Ajoutez ou retirez des documents de cette liste de référence.
            </p>

            {/* Add form */}
            <div className="flex items-center gap-2 mb-4 p-3 rounded-lg" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
              <input value={newDocName} onChange={e => setNewDocName(e.target.value)}
                placeholder="Nom du document"
                className="h-9 px-3 rounded-md text-sm outline-none flex-1"
                style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#0F172A" }}
                onFocus={e => e.currentTarget.style.borderColor = "#E85D7A"}
                onBlur={e => e.currentTarget.style.borderColor = "#E2E8F0"}
                onKeyDown={e => e.key === "Enter" && addDocument()} />
              <input value={newDocDesc} onChange={e => setNewDocDesc(e.target.value)}
                placeholder="Description (optionnelle)"
                className="h-9 px-3 rounded-md text-sm outline-none flex-1"
                style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#0F172A" }}
                onFocus={e => e.currentTarget.style.borderColor = "#E85D7A"}
                onBlur={e => e.currentTarget.style.borderColor = "#E2E8F0"}
                onKeyDown={e => e.key === "Enter" && addDocument()} />
              <button onClick={addDocument}
                className="flex items-center gap-1.5 px-4 h-9 rounded-md text-sm font-medium text-white shrink-0"
                style={{ background: "#E85D7A" }}>
                <Plus size={14} /> Ajouter
              </button>
            </div>

            <div className="rounded-lg overflow-hidden" style={{ border: "1px solid #E2E8F0", background: "#FFFFFF" }}>
              <table className="w-full text-sm">
                <thead>
                  <tr style={{ background: "#F8FAFC", borderBottom: "1px solid #E2E8F0" }}>
                    <th className="text-left px-4 py-3 text-xs font-semibold" style={{ color: "#64748B" }}>Document</th>
                    <th className="text-left px-4 py-3 text-xs font-semibold" style={{ color: "#64748B" }}>Description</th>
                    <th className="w-12" />
                  </tr>
                </thead>
                <tbody>
                  {expectedDocs.map(d => (
                    <tr key={d.id} style={{ borderBottom: "1px solid #E2E8F0" }}
                      onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#F8FAFC"; }}
                      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; }}>
                      <td className="px-4 py-3 text-sm font-medium" style={{ color: "#0F172A" }}>{d.name}</td>
                      <td className="px-4 py-3 text-xs" style={{ color: "#64748B", maxWidth: 380 }}>{d.description}</td>
                      <td className="px-4 py-3">
                        <button onClick={() => removeDocument(d.id)}
                          className="w-7 h-7 rounded flex items-center justify-center transition-all"
                          style={{ color: "#94A3B8" }}
                          onMouseEnter={e => { e.currentTarget.style.background = "#FEE2E2"; e.currentTarget.style.color = "#EF4444"; }}
                          onMouseLeave={e => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "#94A3B8"; }}>
                          <X size={14} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="mt-4 text-xs" style={{ color: "#64748B" }}>
              Total : <strong>{expectedDocs.length}</strong> document{expectedDocs.length > 1 ? "s" : ""} référencé{expectedDocs.length > 1 ? "s" : ""}
            </div>
          </div>
        )}

        {/* === TAB TAGS — Arbre hiérarchique SDSI === */}
        {tab === "tags" && (
          <div>
            <p className="text-xs mb-4" style={{ color: "#64748B" }}>
              Arbre hiérarchique des tags SDSI. L'attribution des tags s'effectue par document dans la page d'ingestion (M2 — Kanban).
            </p>

            {/* Controls bar */}
            <div className="flex items-center justify-between flex-wrap gap-3 mb-4">
              <span className="text-xs" style={{ color: "#64748B" }}>
                <strong style={{ color: "#0F172A" }}>{totalNodes}</strong> nœuds · <strong style={{ color: "#0F172A" }}>{totalLeaves}</strong> feuilles · 5 niveaux
              </span>
              <div className="flex gap-2">
                <button onClick={expandAllTree} className="text-xs px-3 h-7 rounded font-medium transition-all"
                  style={{ background: "#F1F5F9", color: "#64748B", border: "1px solid #E2E8F0" }}
                  onMouseEnter={e => e.currentTarget.style.background = "#E2E8F0"}
                  onMouseLeave={e => e.currentTarget.style.background = "#F1F5F9"}>
                  Tout déplier
                </button>
                <button onClick={collapseAllTree} className="text-xs px-3 h-7 rounded font-medium transition-all"
                  style={{ background: "#F1F5F9", color: "#64748B", border: "1px solid #E2E8F0" }}
                  onMouseEnter={e => e.currentTarget.style.background = "#E2E8F0"}
                  onMouseLeave={e => e.currentTarget.style.background = "#F1F5F9"}>
                  Tout replier
                </button>
              </div>
            </div>

            {/* Search */}
            <div className="flex items-center gap-2 px-3 h-9 rounded-lg mb-4" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
              <Search size={13} style={{ color: "#94A3B8" }} />
              <input value={treeSearch} onChange={e => {
                setTreeSearch(e.target.value);
                if (e.target.value) setTreeExpanded(new Set(allExpandableIds));
              }} placeholder="Rechercher un nœud..."
                className="flex-1 bg-transparent outline-none text-sm" style={{ color: "#0F172A" }} />
            </div>

            {/* Legend */}
            <div className="flex items-center gap-2 mb-4 flex-wrap">
              {[
                { type: "as-is", label: "AS-IS" },
                { type: "cible", label: "Cible" },
                { type: "feuille", label: "Feuille de route" }
              ].map(t => (
                <span key={t.type} className="inline-flex items-center gap-1.5 text-[11px] px-2.5 h-6 rounded-full font-medium"
                  style={{ background: TYPE_STYLES[t.type].chip.bg, color: TYPE_STYLES[t.type].chip.color }}>
                  <span style={{ width: 7, height: 7, borderRadius: "50%", background: TYPE_STYLES[t.type].dot }} />
                  {t.label}
                </span>
              ))}
              <span className="text-[11px]" style={{ color: "#94A3B8" }}>· N1–N5 = niveaux hiérarchiques</span>
            </div>

            {/* Tree */}
            <div className="rounded-xl p-4" style={{ background: "#FFFFFF", border: "0.5px solid #E2E8F0" }}>
              {TREE_DATA.filter(n => subtreeHasMatch(n, treeSearch)).map(node => (
                <TreeNodeComponent
                  key={node.id}
                  node={node}
                  expanded={treeExpanded}
                  toggle={toggleTreeNode}
                  depth={0}
                  searchQ={treeSearch}
                />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Create Consultant Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 flex items-center justify-center z-50" style={{ background: "rgba(15,23,42,0.5)" }}>
          <div className="rounded-xl p-6 w-full max-w-md mx-4" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0", boxShadow: "0 20px 60px rgba(0,0,0,0.15)" }}>
            <div className="flex items-center justify-between mb-5">
              <h3>Nouveau consultant</h3>
              <button onClick={() => setShowCreateModal(false)} style={{ color: "#94A3B8" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.color = "#64748B"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.color = "#94A3B8"; }}>
                <X size={16} />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block mb-1 text-xs" style={{ color: "#64748B" }}>Nom complet</label>
                <input value={newConsultant.name} onChange={e => setNewConsultant({ ...newConsultant, name: e.target.value })}
                  placeholder="ex: Jean Dupont"
                  className="w-full h-9 px-3 rounded-md text-sm outline-none transition-all"
                  style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#0F172A" }}
                  onFocus={e => { e.currentTarget.style.borderColor = "#E85D7A"; }}
                  onBlur={e => { e.currentTarget.style.borderColor = "#E2E8F0"; }} />
              </div>
              <div>
                <label className="block mb-1 text-xs" style={{ color: "#64748B" }}>Adresse e-mail</label>
                <input value={newConsultant.email} onChange={e => setNewConsultant({ ...newConsultant, email: e.target.value })}
                  placeholder="prenom.nom@devoteam.com"
                  className="w-full h-9 px-3 rounded-md text-sm outline-none transition-all"
                  style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#0F172A" }}
                  onFocus={e => { e.currentTarget.style.borderColor = "#E85D7A"; }}
                  onBlur={e => { e.currentTarget.style.borderColor = "#E2E8F0"; }} />
              </div>
              <div>
                <label className="block mb-1 text-xs" style={{ color: "#64748B" }}>Rôle</label>
                <select value={newConsultant.role} onChange={e => setNewConsultant({ ...newConsultant, role: e.target.value })}
                  className="w-full h-9 px-3 rounded-md text-sm outline-none transition-all"
                  style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#0F172A" }}
                  onFocus={e => { e.currentTarget.style.borderColor = "#E85D7A"; }}
                  onBlur={e => { e.currentTarget.style.borderColor = "#E2E8F0"; }}>
                  {roles.map(r => <option key={r}>{r}</option>)}
                </select>
              </div>
            </div>
            <div className="flex items-center justify-end gap-3 mt-6">
              <button onClick={() => setShowCreateModal(false)}
                className="px-4 h-9 rounded-md text-sm transition-all"
                style={{ border: "1px solid #E2E8F0", color: "#64748B", background: "#FFFFFF" }}>
                Annuler
              </button>
              <button onClick={createConsultant}
                className="px-4 h-9 rounded-md text-sm font-medium text-white"
                style={{ background: "#E85D7A" }}>
                Créer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Assign to Mission Modal */}
      {showAssignModal && assignConsultant && (
        <div className="fixed inset-0 flex items-center justify-center z-50" style={{ background: "rgba(15,23,42,0.5)" }}>
          <div className="rounded-xl p-6 w-full max-w-md mx-4" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0", boxShadow: "0 20px 60px rgba(0,0,0,0.15)" }}>
            <div className="flex items-center justify-between mb-5">
              <h3>Affecter {assignConsultant.name}</h3>
              <button onClick={() => setShowAssignModal(false)} style={{ color: "#94A3B8" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.color = "#64748B"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.color = "#94A3B8"; }}>
                <X size={16} />
              </button>
            </div>
            <div className="space-y-3">
              {missions.map(m => (
                <button key={m.id} onClick={() => setSelectedMission(m.id)}
                  className="w-full text-left px-4 py-3 rounded-lg flex items-center justify-between transition-all"
                  style={{
                    background: selectedMission === m.id ? "rgba(232,93,122,0.06)" : "#F8FAFC",
                    border: `1px solid ${selectedMission === m.id ? "#E85D7A" : "#E2E8F0"}`,
                  }}>
                  <div>
                    <p className="text-sm font-medium" style={{ color: "#0F172A" }}>{m.client}</p>
                    <p className="text-xs mt-0.5" style={{ color: "#64748B" }}>{m.sector} · M{m.module} · {m.startDate}</p>
                  </div>
                  {selectedMission === m.id && (
                    <div className="w-5 h-5 rounded-full flex items-center justify-center" style={{ background: "#E85D7A" }}>
                      <Check size={10} color="white" />
                    </div>
                  )}
                </button>
              ))}
            </div>
            <div className="flex items-center justify-end gap-3 mt-6">
              <button onClick={() => setShowAssignModal(false)}
                className="px-4 h-9 rounded-md text-sm transition-all"
                style={{ border: "1px solid #E2E8F0", color: "#64748B", background: "#FFFFFF" }}>
                Annuler
              </button>
              <button onClick={assignToMission} disabled={selectedMission === null}
                className="px-4 h-9 rounded-md text-sm font-medium text-white"
                style={{ background: selectedMission === null ? "#CBD5E1" : "#E85D7A" }}>
                Affecter
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
