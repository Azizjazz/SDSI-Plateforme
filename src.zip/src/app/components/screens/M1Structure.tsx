import { useState } from "react";
import { Upload, ChevronRight, ChevronLeft, FileText, Pen, Plus, X, Check, AlertTriangle, BookOpen, Activity, Shield, Network, Target, FileOutput, Users, GitBranch, ChevronDown } from "lucide-react";
import { GhostButton, TagChip } from "../ui-kit";

const cdcPageContent: Record<number, { title: string; content: string }> = {
  2: { title: "Périmètre du projet", content: "Le présent cahier des charges définit le périmètre de la mission d'audit SI de la Banque Centrale Maghreb. La cartographie fonctionnelle et applicative devra couvrir l'ensemble des directions métiers et supports. Les systèmes d'information métier incluent le core banking, le système de paiement, et le portail réglementaire." },
  3: { title: "Gouvernance SI & Réseaux", content: "La gouvernance SI est actuellement assurée par le DSI et son comité de direction. Le réseau principal repose sur une architecture hub-and-spoke déployée en 2018. Les trois sites régionaux (Tunis, Sfax, Sousse) sont interconnectés via des liens MPLS 10 Mbps. La politique SI définit les orientations stratégiques mais n'a pas été mise à jour depuis 2021." },
  4: { title: "Infrastructure réseau", content: "L'infrastructure réseau se compose de routeurs Cisco 2900 series sur le backbone, avec des switches Catalyst 3750 en distribution. Les firewalls Cisco ASA 5500 assurent la sécurité périmétrique. L'étude de capacité montre une saturation des liens MPLS prévue pour 2026. Aucune redondance WAN n'est en place sur les sites secondaires." },
  5: { title: "Politique de sécurité", content: "La politique de sécurité SI a été établie en 2020 et couvre les domaines suivants : gestion des accès (IAM), classification des données, réponse aux incidents, et continuité d'activité. Des lacunes ont été identifiées : absence de procédure formalisée de réponse aux incidents, politique IAM non révisée depuis 2021, et absence de tests PCA réguliers." },
  6: { title: "SSI & Gouvernance sécurité", content: "Le RSSI est un poste partagé avec d'autres entités du groupe. Un audit de conformité ISO 27001 est en cours. Les recommandations incluent la mise en place d'un SOC (Security Operations Center) et le déploiement d'outils de détection d'intrusion sur le périmètre critique." },
  7: { title: "Conformité réglementaire", content: "La banque est soumise à la réglementation BCT (Banque Centrale de Tunisie) ainsi qu'aux normes Bâle III. Les exigences de conformité couvrent la continuité d'activité (PCA), la gestion des risques SI, et le reporting réglementaire. Un gap analysis BCT est attendu pour le prochain trimestre." },
  8: { title: "Datacenter", content: "Le datacenter principal est situé au siège de Tunis. Un site de reprise (DRP) est en cours de déploiement à Sousse. La capacité actuelle du datacenter est de 42U avec un taux d'occupation de 78%. La virtualisation est assurée par VMware vSphere 7.0 sur un cluster de 8 hyperviseurs." },
  9: { title: "Cartographie fonctionnelle", content: "Les processus transverses incluent : la gestion des sinistres, le reporting financier, et la conformité réglementaire. Les systèmes d'information métier couvrent les domaines suivants : Core Banking (SAB), Paiement (SIP), Réglementaire (REG), et Décisionnel (BI)." },
  10: { title: "Sécurité SI — suite", content: "Analyse des risques sécurité selon la méthodologie EBIOS. Les menaces identifiées incluent les attaques par ransomware, le vol de données, et l'indisponibilité des systèmes critiques. Un budget de 600 K€ est alloué aux projets sécurité pour 2025." },
  11: { title: "Cartographie applicative", content: "L'inventaire applicatif recense 47 applications dont 12 sont considérées comme critiques. Le Core Banking System (SAB) est l'application la plus stratégique. Les applications sont hébergées à 60% sur site et à 40% chez des hébergeurs tiers. La cartographie des flux inter-applicatifs est partiellement documentée." },
  12: { title: "Gouvernance SI — suite", content: "Le comité SI se réunit mensuellement avec la présence du DSI, des directeurs métiers, et du responsable conformité. Les décisions sont formalisées mais leur suivi n'est pas systématique. Un RACI est en cours de déploiement pour clarifier les responsabilités DSI / Métiers." },
  14: { title: "ERP & Core Banking", content: "Le système core banking (SAB) est une solution maison développée en Java/J2EE avec une base de données Oracle. L'ERP financier est SAP ECC 6.0. Les interfaces entre SAB et SAP sont assurées par des batchs ETL. La feuille de route prévoit une migration vers SAP S/4HANA d'ici 2027." },
  15: { title: "Organisation DSI", content: "La DSI est structurée en 4 pôles : Infrastructure & Réseaux (12 personnes), Applications & Projets (10 personnes), Sécurité & Conformité (5 personnes), et Support & Exploitation (5 personnes). Le rattachement hiérarchique est direct à la Direction Générale. L'organigramme est disponible en annexe." },
  18: { title: "Compétences & Formation", content: "Un plan de formation DSI est en place pour les compétences Cloud et Cybersécurité. Le turnover est de 8% par an. Les principaux départs concernent le pôle Infrastructure. Un programme de certification (CISSP, AWS, ITIL) est en cours pour les équipes clés." },
};

const totalCdcPages = 23;

const detectedDomains = [
  { label: "Support", color: "#E85D7A", description: "Achats, Juridique, Compta, RH, Bureau d'ordre", pages: [3, 15, 18] },
  { label: "Canaux", color: "#8B5CF6", description: "Site web, Réseaux Sociaux", pages: [2] },
  { label: "Pilotage", color: "#0EA5E9", description: "Risques, Conformité, Audit, Contrôle", pages: [3, 7, 12] },
  { label: "Chaîne de valeur", color: "#10B981", description: "Refinancement, Titrisation, Garanties, Trésorerie", pages: [2, 9, 14] },
  { label: "Gestion du SI", color: "#F59E0B", description: "Sécurité, Infra, Réseaux, Services", pages: [4, 5, 6, 8, 10] },
  { label: "Référentiel", color: "#94A3B8", description: "Banques, SFD, Bailleurs de fonds", pages: [7, 14] },
];

const defaultDomains = [
  { label: "Support", color: "#E85D7A", description: "Achats, Juridique, Compta, RH, Bureau d'ordre" },
  { label: "Canaux", color: "#8B5CF6", description: "Site web, Réseaux Sociaux" },
  { label: "Pilotage", color: "#0EA5E9", description: "Risques, Conformité, Audit, Contrôle" },
  { label: "Chaîne de valeur", color: "#10B981", description: "Refinancement, Titrisation, Garanties, Trésorerie" },
  { label: "Gestion du SI", color: "#F59E0B", description: "Sécurité, Infra, Réseaux, Services" },
  { label: "Référentiel", color: "#94A3B8", description: "Banques, SFD, Bailleurs de fonds" },
];

interface SectionItem {
  title: string;
  depth: number;
  pages?: number[];
}

const detectedSections: SectionItem[] = [
  { title: "Diagnostic de Support", depth: 0, pages: [3, 15, 18] },
  { title: "Achats et Stocks", depth: 1, pages: [15] },
  { title: "Juridique", depth: 1, pages: [3] },
  { title: "Ressources Humaines", depth: 1, pages: [15, 18] },
  { title: "Diagnostic de Canaux", depth: 0, pages: [2] },
  { title: "Site web et Réseaux Sociaux", depth: 1, pages: [2] },
  { title: "Diagnostic de Pilotage", depth: 0, pages: [3, 7, 12] },
  { title: "Risques et Conformité", depth: 1, pages: [7] },
  { title: "Contrôle et Audit", depth: 1, pages: [12] },
  { title: "Diagnostic de Chaîne de valeur", depth: 0, pages: [2, 9, 14] },
  { title: "Refinancement", depth: 1, pages: [14] },
  { title: "Titrisation et Garanties", depth: 1, pages: [9] },
  { title: "Diagnostic de Gestion du SI", depth: 0, pages: [4, 5, 6, 8, 10] },
  { title: "Sécurité SI", depth: 1, pages: [5, 6, 10] },
  { title: "Infrastructure et Réseaux", depth: 1, pages: [4, 8] },
  { title: "Diagnostic de Référentiel", depth: 0, pages: [7, 14] },
  { title: "Banques et SFD", depth: 1, pages: [7] },
  { title: "Bailleurs de fonds", depth: 1, pages: [14] },
];

const defaultSections: SectionItem[] = [
  { title: "Diagnostic de Support", depth: 0 },
  { title: "Achats et Stocks", depth: 1 },
  { title: "Juridique", depth: 1 },
  { title: "Ressources Humaines", depth: 1 },
  { title: "Diagnostic de Canaux", depth: 0 },
  { title: "Site web", depth: 1 },
  { title: "Réseaux Sociaux", depth: 1 },
  { title: "Diagnostic de Pilotage", depth: 0 },
  { title: "Risques", depth: 1 },
  { title: "Conformité", depth: 1 },
  { title: "Audit", depth: 1 },
  { title: "Diagnostic de Chaîne de valeur", depth: 0 },
  { title: "Refinancement", depth: 1 },
  { title: "Titrisation", depth: 1 },
  { title: "Garanties", depth: 1 },
  { title: "Diagnostic de Gestion du SI", depth: 0 },
  { title: "Sécurité SI", depth: 1 },
  { title: "Infrastructure", depth: 1 },
  { title: "Réseaux", depth: 1 },
  { title: "Diagnostic de Référentiel", depth: 0 },
  { title: "Banques", depth: 1 },
  { title: "SFD", depth: 1 },
  { title: "Bailleurs de fonds", depth: 1 },
];

const iconMap: Record<string, any> = {
  "Périmètre": BookOpen,
  "Gouvernance": Network,
  "Infrastructure": Activity,
  "Sécurité": Shield,
  "Conformité": Target,
  "Cartographie": FileOutput,
  "Compétences": BookOpen,
  "Contexte": BookOpen,
  "Organisation": Users,
};

function pickIcon(title: string) {
  const key = Object.keys(iconMap).find(k => title.includes(k));
  return key ? iconMap[key] : FileText;
}

interface M1StructureProps {
  onNext: () => void;
  onBack: () => void;
}

export function M1Structure({ onNext, onBack }: M1StructureProps) {
  const [cdcIngested, setCdcIngested] = useState(false);
  const [ingesting, setIngesting] = useState(false);
  const [viewingPage, setViewingPage] = useState<number | null>(null);
  const [structureDetected, setStructureDetected] = useState<boolean | null>(null);
  const [usingDefault, setUsingDefault] = useState(false);
  const [editingCarto, setEditingCarto] = useState(false);
  const [editingDiagnostic, setEditingDiagnostic] = useState(false);
  const [validatedCarto, setValidatedCarto] = useState(false);
  const [validatedDiagnostic, setValidatedDiagnostic] = useState(false);
  const [simulateFailure, setSimulateFailure] = useState(false);
  const [domains, setDomains] = useState(defaultDomains);
  const [sections, setSections] = useState<SectionItem[]>(defaultSections);
  const [cartoCustomized, setCartoCustomized] = useState(false);
  const [diagCustomized, setDiagCustomized] = useState(false);

  const isDetected = structureDetected === true;
  const showContent = cdcIngested && (isDetected || usingDefault);

  const handleIngest = () => {
    setIngesting(true);
    setTimeout(() => {
      setIngesting(false);
      setCdcIngested(true);
      setStructureDetected(simulateFailure ? false : true);
    }, 2000);
  };

  const acceptFallback = () => {
    setUsingDefault(true);
    setDomains(defaultDomains);
    setSections(defaultSections);
  };

  const addDomain = () => {
    const colors = ["#E85D7A", "#8B5CF6", "#10B981", "#F59E0B", "#EF4444", "#3B82F6"];
    const used = domains.map(d => d.color);
    const avail = colors.find(c => !used.includes(c));
    setDomains([...domains, { label: "Nouveau domaine", color: avail || "#94A3B8", description: "Description du domaine" }]);
  };

  const removeDomain = (i: number) => setDomains(domains.filter((_, idx) => idx !== i));

  const updateDomain = (i: number, field: "label" | "description", val: string) => {
    const next = [...domains];
    next[i] = { ...next[i], [field]: val };
    setDomains(next);
  };

  const addSection = () => {
    const last = sections[sections.length - 1];
    const depth = last?.depth === 0 ? 1 : 0;
    setSections([...sections, { title: "Nouvelle section", depth }]);
  };

  const removeSection = (i: number) => setSections(sections.filter((_, idx) => idx !== i));

  const updateSectionTitle = (i: number, val: string) => {
    const next = [...sections];
    next[i] = { ...next[i], title: val };
    setSections(next);
  };

  const toggleSectionDepth = (i: number) => {
    const next = [...sections];
    next[i] = { ...next[i], depth: next[i].depth === 0 ? 1 : 0 };
    setSections(next);
  };

  const startEditingCarto = () => {
    if (isDetected && !cartoCustomized) {
      setDomains(detectedDomains.map(d => ({ label: d.label, color: d.color, description: d.description })));
      setCartoCustomized(true);
    }
    setEditingCarto(true);
  };

  const startEditingDiagnostic = () => {
    if (isDetected && !diagCustomized) {
      setSections(detectedSections.map(s => ({ title: s.title, depth: s.depth })));
      setDiagCustomized(true);
    }
    setEditingDiagnostic(true);
  };

  const currentDomains = isDetected && !cartoCustomized ? detectedDomains : domains;
  const currentSections = isDetected && !diagCustomized ? detectedSections : sections;

  const resetAll = () => {
    setCdcIngested(false);
    setStructureDetected(null);
    setUsingDefault(false);
    setEditingCarto(false);
    setEditingDiagnostic(false);
    setValidatedCarto(false);
    setValidatedDiagnostic(false);
    setCartoCustomized(false);
    setDiagCustomized(false);
    setViewingPage(null);
  };

  return (
    <div className="h-full flex flex-col" style={{ background: "#F8FAFC" }}>
      <div className="flex-1 flex" style={{ minHeight: 0 }}>
        {/* LEFT — Analyse des besoins */}
        <div className="w-[50%] flex flex-col" style={{ borderRight: "1px solid #E2E8F0" }}>
        <div className="px-5 py-3 flex items-center justify-between shrink-0" style={{ borderBottom: "1px solid #E2E8F0" }}>
          <h3>Analyse des besoins</h3>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          {!cdcIngested ? (
            <div>
              <div className="rounded-xl flex flex-col items-center justify-center gap-2 cursor-pointer transition-all py-10 mb-3"
                style={{ border: "2px dashed #E2E8F0", background: "#FFFFFF" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = "#E85D7A"; (e.currentTarget as HTMLElement).style.background = "rgba(232,93,122,0.04)"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "#E2E8F0"; (e.currentTarget as HTMLElement).style.background = "#FFFFFF"; }}
                onClick={handleIngest}>
                <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "#F1F5F9" }}>
                  {ingesting ? (
                    <span className="w-4 h-4 border-2 rounded-full animate-spin" style={{ borderColor: "#E85D7A", borderTopColor: "transparent" }} />
                  ) : (
                    <Upload size={18} style={{ color: "#94A3B8" }} />
                  )}
                </div>
                <div className="text-center">
                  {ingesting ? (
                    <p className="text-sm font-medium" style={{ color: "#E85D7A" }}>⏳ Analyse du CDC en cours...</p>
                  ) : (
                    <>
                      <p className="text-sm font-medium" style={{ color: "#64748B" }}>Ingérer le cahier des charges</p>
                      <p className="text-xs mt-0.5" style={{ color: "#94A3B8" }}>PDF · DOCX — Glissez ou <span style={{ color: "#E85D7A" }}>parcourez</span></p>
                    </>
                  )}
                </div>
              </div>
              <label className="flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer select-none"
                style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
                <input type="checkbox" checked={simulateFailure} onChange={e => setSimulateFailure(e.target.checked)}
                  className="w-3.5 h-3.5 rounded cursor-pointer accent-[#E85D7A]" />
                <span className="text-xs" style={{ color: "#64748B" }}>Simuler un échec de détection (fallback vers structure par défaut)</span>
              </label>
            </div>
          ) : !showContent ? (
            <div className="flex-1 flex items-center justify-center h-full">
              <p className="text-sm" style={{ color: "#94A3B8" }}>Analyse terminée — veuillez confirmer dans la fenêtre</p>
            </div>
          ) : (
            <div className="space-y-5">
              {isDetected && (
                <p className="text-xs px-3 py-2 rounded-lg flex items-center gap-2" style={{ background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.2)", color: "#10B981" }}>
                  <Check size={12} />
                  CDC analysé — {detectedDomains.length} domaines · {detectedSections.length} sections identifiés
                </p>
              )}
              {!isDetected && (
                <p className="text-xs px-3 py-2 rounded-lg flex items-center gap-2" style={{ background: "rgba(245,158,11,0.08)", border: "1px solid rgba(245,158,11,0.2)", color: "#92400E" }}>
                  <AlertTriangle size={12} />
                  Aucune structure détectée — template par défaut chargée
                </p>
              )}

              {/* === Structure Cartographique (domains only) === */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <h4>Structure Cartographique</h4>
                  <div className="ml-auto flex items-center gap-1.5">
                    {validatedCarto ? (
                      <span className="flex items-center gap-1 px-2 h-6 rounded text-[10px] font-medium" style={{ background: "rgba(16,185,129,0.1)", color: "#10B981" }}>
                        <Check size={10} /> Validé
                      </span>
                    ) : (
                      <button onClick={() => setValidatedCarto(true)}
                        className="flex items-center gap-1 px-2 h-6 rounded text-[10px] transition-all"
                        style={{ border: "1px solid #D97706", color: "#D97706", background: "rgba(217,119,6,0.08)" }}>
                        Valider
                      </button>
                    )}
                    <button onClick={editingCarto ? () => setEditingCarto(false) : startEditingCarto}
                      className="flex items-center gap-1 px-2 h-6 rounded text-[10px] transition-all"
                      style={{ border: "1px solid #CBD5E1", color: "#64748B", background: editingCarto ? "rgba(232,93,122,0.1)" : "#FFFFFF" }}>
                      <Pen size={10} /> {editingCarto ? "Terminé" : "Modifier"}
                    </button>
                  </div>
                </div>
                <div className="space-y-2">
                  {(editingCarto ? domains : currentDomains).map((d: any, i: number) => (
                    <div key={i} className="flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all"
                      style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
                      <span className="w-3 h-3 rounded-full shrink-0" style={{ background: d.color }} />
                      {editingCarto ? (
                        <>
                          <div className="flex-1 min-w-0 space-y-1">
                            <input value={d.label} onChange={e => updateDomain(i, "label", e.target.value)}
                              className="w-full text-sm font-medium outline-none rounded px-1.5 py-0.5"
                              style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#0F172A" }} />
                            <input value={d.description} onChange={e => updateDomain(i, "description", e.target.value)}
                              className="w-full text-[11px] outline-none rounded px-1.5 py-0.5"
                              style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#64748B" }} />
                          </div>
                          <button onClick={() => removeDomain(i)} className="p-1 rounded shrink-0" style={{ color: "#EF4444" }}><X size={12} /></button>
                        </>
                      ) : (
                        <>
                          <div className="flex-1">
                            <p className="text-sm font-medium" style={{ color: "#0F172A" }}>{d.label}</p>
                            <p className="text-[11px]" style={{ color: "#94A3B8" }}>{d.description}</p>
                          </div>
                          {isDetected && d.pages && (
                            <div className="flex gap-0.5">
                              {d.pages.map((p: number) => (
                                <span key={p} onClick={() => setViewingPage(p)}
                                  className="cursor-pointer text-[10px] px-1.5 py-0.5 rounded transition-all"
                                  style={{ background: "rgba(232,93,122,0.1)", color: "#E85D7A", fontFamily: "JetBrains Mono, monospace" }}
                                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(232,93,122,0.2)"; }}
                                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(232,93,122,0.1)"; }}>
                                  p.{p}
                                </span>
                              ))}
                            </div>
                          )}
                          <ChevronRight size={12} style={{ color: "#CBD5E1" }} />
                        </>
                      )}
                    </div>
                  ))}
                </div>
                {editingCarto && (
                  <button onClick={addDomain}
                    className="flex items-center gap-1.5 w-full mt-2 px-3 py-2 rounded-lg text-xs transition-all justify-center"
                    style={{ border: "1px dashed #CBD5E1", color: "#94A3B8" }}
                    onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = "#E85D7A"; (e.currentTarget as HTMLElement).style.color = "#E85D7A"; }}
                    onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "#CBD5E1"; (e.currentTarget as HTMLElement).style.color = "#94A3B8"; }}>
                    <Plus size={12} /> Ajouter un domaine
                  </button>
                )}
              </div>

              {/* === Structure du document de diagnostic (with hierarchy) === */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <h4>Structure du document de diagnostic</h4>
                  <div className="ml-auto flex items-center gap-1.5">
                    {validatedDiagnostic ? (
                      <span className="flex items-center gap-1 px-2 h-6 rounded text-[10px] font-medium" style={{ background: "rgba(16,185,129,0.1)", color: "#10B981" }}>
                        <Check size={10} /> Validé
                      </span>
                    ) : (
                      <button onClick={() => setValidatedDiagnostic(true)}
                        className="flex items-center gap-1 px-2 h-6 rounded text-[10px] transition-all"
                        style={{ border: "1px solid #D97706", color: "#D97706", background: "rgba(217,119,6,0.08)" }}>
                        Valider
                      </button>
                    )}
                    <button onClick={editingDiagnostic ? () => setEditingDiagnostic(false) : startEditingDiagnostic}
                      className="flex items-center gap-1 px-2 h-6 rounded text-[10px] transition-all"
                      style={{ border: "1px solid #CBD5E1", color: "#64748B", background: editingDiagnostic ? "rgba(232,93,122,0.1)" : "#FFFFFF" }}>
                      <Pen size={10} /> {editingDiagnostic ? "Terminé" : "Modifier"}
                    </button>
                  </div>
                </div>
                <div className="rounded-lg overflow-hidden" style={{ border: "1px solid #E2E8F0", background: "#FFFFFF" }}>
                  {(editingDiagnostic ? sections : currentSections).map((section, i) => {
                    const isParent = section.depth === 0;
                    const Icon = pickIcon(section.title);
                    return (
                      <div key={i}
                        className="flex items-center gap-3 transition-all"
                        style={{
                          paddingLeft: isParent ? 12 : 32,
                          paddingRight: 12,
                          paddingTop: isParent ? 10 : 8,
                          paddingBottom: isParent ? 10 : 8,
                          borderBottom: i < (editingDiagnostic ? sections : currentSections).length - 1 ? "1px solid #E2E8F0" : "none",
                          background: isParent ? "#F8FAFC" : "#FFFFFF",
                        }}>
                        {editingDiagnostic ? (
                          <>
                            <button onClick={() => toggleSectionDepth(i)}
                              className="p-0.5 rounded shrink-0 transition-all"
                              style={{ color: "#94A3B8" }}>
                              {section.depth === 0 ? <ChevronDown size={10} /> : <ChevronRight size={10} />}
                            </button>
                            <input value={section.title} onChange={e => updateSectionTitle(i, e.target.value)}
                              className="flex-1 text-sm outline-none rounded px-1.5 py-0.5"
                              style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: "#0F172A" }} />
                            <button onClick={() => removeSection(i)} className="p-1 rounded shrink-0" style={{ color: "#EF4444" }}><X size={12} /></button>
                          </>
                        ) : (
                          <>
                            {isParent ? (
                              <Icon size={13} style={{ color: "#E85D7A" }} />
                            ) : (
                              <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: "#CBD5E1" }} />
                            )}
                            <span className="flex-1 text-sm" style={{ color: isParent ? "#0F172A" : "#64748B", fontWeight: isParent ? 500 : 400 }}>{section.title}</span>
                            {isDetected && section.pages && (
                              <div className="flex gap-0.5">
                                {section.pages.map(p => (
                                  <span key={p} onClick={() => setViewingPage(p)}
                                    className="cursor-pointer text-[10px] px-1.5 py-0.5 rounded transition-all"
                                    style={{ background: "rgba(232,93,122,0.1)", color: "#E85D7A", fontFamily: "JetBrains Mono, monospace" }}
                                    onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(232,93,122,0.2)"; }}
                                    onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "rgba(232,93,122,0.1)"; }}>
                                    p.{p}
                                  </span>
                                ))}
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    );
                  })}
                </div>
                {editingDiagnostic && (
                  <button onClick={addSection}
                    className="flex items-center gap-1.5 w-full mt-2 px-3 py-2 rounded-lg text-xs transition-all justify-center"
                    style={{ border: "1px dashed #CBD5E1", color: "#94A3B8" }}
                    onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = "#E85D7A"; (e.currentTarget as HTMLElement).style.color = "#E85D7A"; }}
                    onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "#CBD5E1"; (e.currentTarget as HTMLElement).style.color = "#94A3B8"; }}>
                    <Plus size={12} /> Ajouter une section
                  </button>
                )}
              </div>

              <button className="text-xs transition-all w-full text-center py-2" style={{ color: "#94A3B8" }}
                onClick={resetAll}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.color = "#64748B"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.color = "#94A3B8"; }}>
                ↺ Réinitialiser l'analyse
              </button>
            </div>
          )}
        </div>
      </div>

      {/* RIGHT — CDC page viewer */}
      <div className="flex-1 h-full flex flex-col">
        <div className="px-5 py-3 flex items-center justify-between shrink-0" style={{ borderBottom: "1px solid #E2E8F0" }}>
          <div>
            <p className="text-sm font-semibold" style={{ color: "#0F172A" }}>CDC: audit_si_banque_centrale_2024.pdf</p>
            {viewingPage !== null && (
              <p className="text-[11px]" style={{ color: "#94A3B8", fontFamily: "JetBrains Mono, monospace" }}>
                Page {viewingPage} / {totalCdcPages}
              </p>
            )}
          </div>
          {!cdcIngested && <p className="text-xs" style={{ color: "#94A3B8" }}>En attente du CDC...</p>}
        </div>

        <div className="flex-1 overflow-y-auto p-5">
          {!cdcIngested ? (
            <div className="h-full flex items-center justify-center">
              <div className="text-center max-w-xs">
                <div className="w-14 h-14 rounded-xl flex items-center justify-center mx-auto mb-4" style={{ background: "#F1F5F9" }}>
                  <FileText size={24} style={{ color: "#CBD5E1" }} />
                </div>
                <p className="text-sm font-medium" style={{ color: "#94A3B8" }}>Aucun CDC ingéré</p>
                <p className="text-xs mt-1" style={{ color: "#CBD5E1" }}>Ingérez le cahier des charges dans le panneau de gauche pour visualiser son contenu</p>
              </div>
            </div>
          ) : !isDetected ? (
            <div className="h-full flex items-center justify-center">
              <div className="text-center max-w-xs">
                <div className="w-14 h-14 rounded-xl flex items-center justify-center mx-auto mb-4" style={{ background: "#F1F5F9" }}>
                  <FileText size={24} style={{ color: "#CBD5E1" }} />
                </div>
                <p className="text-sm font-medium" style={{ color: "#94A3B8" }}>CDC non interprétable</p>
                <p className="text-xs mt-1" style={{ color: "#CBD5E1" }}>Aucune structure n'a pu être extraite. Utilisez le panneau de gauche pour éditer manuellement la structure par défaut.</p>
              </div>
            </div>
          ) : viewingPage === null ? (
            <div className="h-full flex items-center justify-center">
              <div className="text-center max-w-xs">
                <div className="w-14 h-14 rounded-xl flex items-center justify-center mx-auto mb-4" style={{ background: "#F1F5F9" }}>
                  <FileText size={24} style={{ color: "#CBD5E1" }} />
                </div>
                <p className="text-sm font-medium" style={{ color: "#94A3B8" }}>Sélectionnez une référence</p>
                <p className="text-xs mt-1" style={{ color: "#CBD5E1" }}>Cliquez sur une référence de page dans le panneau de gauche pour afficher le contenu du CDC</p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="rounded-xl p-5" style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
                <div className="flex items-center gap-2 mb-3">
                  <FileText size={14} style={{ color: "#E85D7A" }} />
                  <span className="text-[11px] font-semibold uppercase tracking-wider" style={{ color: "#64748B" }}>{cdcPageContent[viewingPage]?.title || `Page ${viewingPage}`}</span>
                </div>
                <p className="text-sm leading-relaxed" style={{ color: "#334155" }}>{cdcPageContent[viewingPage]?.content || `Contenu de la page ${viewingPage} du cahier des charges.`}</p>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  {viewingPage > 1 && (
                    <button onClick={() => setViewingPage(viewingPage - 1)}
                      className="flex items-center gap-1 px-3 h-8 rounded-md text-xs transition-all"
                      style={{ border: "1px solid #E2E8F0", color: "#64748B", background: "#FFFFFF" }}
                      onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = "#CBD5E1"; }}
                      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "#E2E8F0"; }}>
                      <ChevronLeft size={12} /> Page précédente
                    </button>
                  )}
                </div>
                <div className="flex gap-2">
                  {viewingPage < totalCdcPages && (
                    <button onClick={() => setViewingPage(viewingPage + 1)}
                      className="flex items-center gap-1 px-3 h-8 rounded-md text-xs transition-all"
                      style={{ background: "#E85D7A", color: "white" }}>
                      Page suivante <ChevronRight size={12} />
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
        </div>
        </div>

      {/* Bottom bar */}
      {showContent && (
        <div className="flex items-center justify-end px-5 py-2 shrink-0" style={{ background: "#FFFFFF", borderTop: "1px solid #E2E8F0" }}>
          <button onClick={onNext}
            className="flex items-center gap-1.5 px-3 h-7 rounded-md text-[11px] font-medium transition-all"
            style={{ background: "#E85D7A", color: "white" }}>
            Passer à l'ingestion <ChevronRight size={11} />
          </button>
        </div>
      )}

      {/* Fallback popup */}
      {structureDetected === false && !usingDefault && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: "rgba(15,23,42,0.5)" }}>
          <div className="w-[460px] rounded-xl overflow-hidden flex flex-col" style={{ background: "#FFFFFF", boxShadow: "0 20px 60px rgba(0,0,0,0.3)" }}>
            <div className="flex items-center gap-3 px-6 pt-6 pb-4">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: "rgba(245,158,11,0.12)" }}>
                <AlertTriangle size={20} style={{ color: "#F59E0B" }} />
              </div>
              <div>
                <h4 style={{ color: "#0F172A" }}>Aucune structure détectée</h4>
                <p className="text-sm mt-0.5" style={{ color: "#64748B" }}>Le CDC n'a pas permis d'identifier de structure cartographique ou de diagnostic.</p>
              </div>
            </div>
            <div className="px-6 py-3" style={{ background: "#FFFBEB", borderTop: "1px solid rgba(245,158,11,0.2)", borderBottom: "1px solid rgba(245,158,11,0.2)" }}>
              <p className="text-sm" style={{ color: "#92400E" }}><strong>Revenir à la structure par défaut ?</strong> Vous pourrez toujours la modifier.</p>
            </div>
            <div className="flex items-center justify-end gap-2 px-6 py-4" style={{ borderTop: "1px solid #E2E8F0" }}>
              <button onClick={resetAll}
                className="px-4 h-9 rounded-md text-sm transition-all"
                style={{ border: "1px solid #E2E8F0", color: "#64748B", background: "#FFFFFF" }}>
                Annuler
              </button>
              <button onClick={acceptFallback}
                className="flex items-center gap-2 px-4 h-9 rounded-md text-sm font-medium transition-all"
                style={{ background: "#D97706", color: "#FFFFFF" }}>
                <Check size={14} /> OK
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}