import { useState } from "react";
import { ChevronDown, Sparkles } from "lucide-react";
import { Card, GhostButton, PrimaryButton, Input } from "../ui-kit";

const sectors = [
  { icon: "🏦", label: "Banque" },
  { icon: "📡", label: "Télécoms" },
  { icon: "🏥", label: "Santé" },
  { icon: "🏛️", label: "Public" },
  { icon: "⚡", label: "Énergie" },
];

const zones = ["EMEA", "AMER", "APAC", "LATAM"];

const pastMissions = [
  { id: 1, name: "SDSI BNA 2024", client: "Banque Nationale Agricole", date: "15 janv. 2024", status: "Complété" },
  { id: 2, name: "Audit SI Orange TN", client: "Orange Tunisie", date: "3 avr. 2023", status: "Archivé" },
  { id: 3, name: "SDSI CAA Assurance", client: "Caisse d'Assurance", date: "20 oct. 2022", status: "Archivé" },
  { id: 4, name: "Audit SI STEG 2023", client: "STEG", date: "8 juin 2023", status: "Archivé" },
];

interface M1CreationProps {
  onNext: () => void;
}

export function M1Creation({ onNext }: M1CreationProps) {
  const [mode, setMode] = useState<"new" | "refresh">("new");
  const [sector, setSector] = useState("Banque");
  const [zone, setZone] = useState("EMEA");
  const [creating, setCreating] = useState(false);
  const [selectedPastMission, setSelectedPastMission] = useState<number | null>(null);
  const [showPastDropdown, setShowPastDropdown] = useState(false);

  const handleCreate = () => {
    setCreating(true);
    setTimeout(() => { setCreating(false); onNext(); }, 1800);
  };

  return (
    <div className="h-full overflow-y-auto" style={{ background: "#F8FAFC" }}>
      <div className="max-w-[680px] mx-auto px-6 py-8">
        {/* Page header */}
        <div className="mb-8">
          <h1 style={{ fontSize: 28 }}>Nouvelle Mission SDSI</h1>
          <p className="text-sm mt-1" style={{ color: "#64748B" }}>Étape 1 sur 5 — Initialisation</p>
        </div>

        {/* Client info */}
        <Card className="mb-4">
          <h4 className="mb-4" style={{ color: "#64748B", fontSize: 13, textTransform: "uppercase", letterSpacing: "0.06em" }}>
            Informations client
          </h4>
          <Input label="Nom du client" placeholder="ex: Banque Centrale Maghreb" className="mb-3" />

          <div className="mb-3">
            <label className="block mb-1 text-xs" style={{ color: "#64748B" }}>Secteur d'activité</label>
            <div className="flex gap-2 flex-wrap">
              {sectors.map(s => (
                <button key={s.label}
                  onClick={() => setSector(s.label)}
                  className="flex items-center gap-1.5 px-3 h-8 rounded-md text-sm transition-all"
                  style={{
                    background: sector === s.label ? "rgba(232,93,122,0.08)" : "#F1F5F9",
                    border: `1px solid ${sector === s.label ? "#E85D7A" : "#E2E8F0"}`,
                    color: sector === s.label ? "#E85D7A" : "#64748B",
                  }}>
                  <span>{s.icon}</span>
                  <span className="text-xs font-medium">{s.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="mb-3">
            <label className="block mb-1 text-xs" style={{ color: "#64748B" }}>Zone géographique</label>
            <div className="flex gap-2 flex-wrap">
              {zones.map(z => (
                <button key={z}
                  onClick={() => setZone(z)}
                  className="px-3 h-8 rounded-md text-sm transition-all"
                  style={{
                    background: zone === z ? "rgba(232,93,122,0.08)" : "#F1F5F9",
                    border: `1px solid ${zone === z ? "#E85D7A" : "#E2E8F0"}`,
                    color: zone === z ? "#E85D7A" : "#64748B",
                  }}>
                  <span className="text-xs font-medium">{z}</span>
                </button>
              ))}
            </div>
          </div>

          <Input label="Date de démarrage" type="date" />
        </Card>

        {/* Mode selector */}
        <Card className="mb-4">
          <h4 className="mb-4 text-xs uppercase tracking-widest" style={{ color: "#64748B" }}>Mode opératoire</h4>
          <div className="grid grid-cols-2 gap-3">
            {[
              { id: "new",     icon: "🆕", title: "Mode Nouveau",   desc: "Importez le cahier des charges client pour générer la cartographie fonctionnelle SI automatiquement." },
              { id: "refresh", icon: "🔄", title: "Mode Refresh",    desc: "Capitalisez sur une mission SDSI existante. Pointez vers une version antérieure." },
            ].map(opt => (
              <button key={opt.id} onClick={() => setMode(opt.id as any)}
                className="text-left p-4 rounded-lg transition-all"
                style={{
                  background: mode === opt.id ? "rgba(232,93,122,0.06)" : "#F1F5F9",
                  border: `1.5px solid ${mode === opt.id ? "#E85D7A" : "#E2E8F0"}`,
                }}>
                <div className="flex items-start justify-between mb-2">
                  <span className="text-xl">{opt.icon}</span>
                  {mode === opt.id && (
                    <span className="w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-bold"
                      style={{ background: "#E85D7A", color: "white" }}>✓</span>
                  )}
                </div>
                <p className="text-sm font-semibold mb-1" style={{ color: "#0F172A" }}>{opt.title}</p>
                <p className="text-xs leading-relaxed" style={{ color: "#64748B" }}>{opt.desc}</p>
              </button>
            ))}
          </div>
        </Card>

        {/* Mode Nouveau — info */}
        {mode === "new" && (
          <Card className="mb-4">
            <h4 className="mb-2 text-xs uppercase tracking-widest" style={{ color: "#64748B" }}>Cahier des charges</h4>
            <p className="text-sm" style={{ color: "#64748B" }}>
              Le cahier des charges sera ingéré dans l'étape suivante (Analyse des besoins) après création de la mission.
            </p>
          </Card>
        )}

        {/* Mode Refresh — Dropdown vers missions passées */}
        {mode === "refresh" && (
          <Card className="mb-4">
            <h4 className="mb-3 text-xs uppercase tracking-widest" style={{ color: "#64748B" }}>Mission SDSI de référence</h4>
            <div className="relative">
              <button
                onClick={() => setShowPastDropdown(!showPastDropdown)}
                className="w-full flex items-center justify-between h-10 px-3 rounded-lg text-sm transition-all"
                style={{ background: "#F8FAFC", border: "1px solid #E2E8F0", color: selectedPastMission ? "#0F172A" : "#94A3B8" }}
                onFocus={e => { e.currentTarget.style.borderColor = "#E85D7A"; }}
                onBlur={e => { e.currentTarget.style.borderColor = "#E2E8F0"; }}>
                <span>{selectedPastMission ? pastMissions.find(m => m.id === selectedPastMission)?.name : "Sélectionner une mission SDSI existante..."}</span>
                <ChevronDown size={14} style={{ color: "#94A3B8", transform: showPastDropdown ? "rotate(180deg)" : "none", transition: "transform 0.2s" }} />
              </button>

              {showPastDropdown && (
                <div className="absolute top-full left-0 right-0 mt-1 z-10 rounded-lg overflow-hidden shadow-lg"
                  style={{ background: "#FFFFFF", border: "1px solid #E2E8F0" }}>
                  {pastMissions.map((m, i) => (
                    <button key={m.id}
                      onClick={() => { setSelectedPastMission(m.id); setShowPastDropdown(false); }}
                      className="w-full text-left px-4 py-3 flex items-center justify-between transition-all"
                      style={{
                        background: selectedPastMission === m.id ? "rgba(232,93,122,0.06)" : "transparent",
                        borderBottom: i < pastMissions.length - 1 ? "1px solid #E2E8F0" : "none",
                      }}
                      onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "#F1F5F9"; }}
                      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = selectedPastMission === m.id ? "rgba(232,93,122,0.06)" : "transparent"; }}>
                      <div>
                        <p className="text-sm font-medium" style={{ color: "#0F172A" }}>{m.name}</p>
                        <p className="text-xs mt-0.5" style={{ color: "#64748B" }}>{m.client}</p>
                        <p className="text-[11px] mt-0.5" style={{ color: "#94A3B8", fontFamily: "JetBrains Mono, monospace" }}>{m.date}</p>
                      </div>
                      <span className="text-[11px] px-2 py-0.5 rounded shrink-0 ml-2" style={{ background: "#F1F5F9", color: "#64748B" }}>{m.status}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
            {selectedPastMission && (
              <div className="mt-3 px-3 py-2.5 rounded-lg text-xs flex items-center gap-2" style={{ background: "rgba(232,93,122,0.06)", border: "1px solid rgba(232,93,122,0.15)", color: "#E85D7A" }}>
                <Sparkles size={12} />
                Capitalisation depuis <strong>{pastMissions.find(m => m.id === selectedPastMission)?.name}</strong> — {pastMissions.find(m => m.id === selectedPastMission)?.client}
              </div>
            )}
          </Card>
        )}

        {/* Bottom CTA */}
        <div className="flex items-center justify-end gap-3 pt-2 pb-8">
          <GhostButton>Annuler</GhostButton>
          <PrimaryButton onClick={handleCreate} loading={creating}>
            {creating ? "✨ Génération en cours..." : "Créer la mission →"}
          </PrimaryButton>
        </div>
      </div>
    </div>
  );
}
