import { useState } from "react";
import {
  Home, FileText, FolderOpen, Map, Calendar, LayoutList,
  Settings, HelpCircle, ChevronRight, ChevronDown,
  CheckCircle, FileCheck, Brain, Target, ClipboardList, MessageSquare,
  BookOpen, Users, Activity, Pen, Eye,
} from "lucide-react";
import { ModuleStepper, CoverageRing } from "./ui-kit";
import devoteamLogo from "@/assets/devoteam_logo.png";

interface AppShellProps {
  children: React.ReactNode;
  activeModule: number;
  onNavigate: (module: number) => void;
  activeScreen: string;
  activeTreeItem?: string | null;
  onTreeItemChange?: (id: string | null) => void;
  onScreenChange: (screen: string) => void;
  onAdminClick?: () => void;
}

interface TreeItem {
  id: string;
  icon?: React.ElementType;
  label: string;
  screen?: string;
  meta?: string;
  children?: TreeItem[];
}

function TreeItemRow({
  item, depth, activeScreen, activeTreeItem, onNavigateTo, defaultExpanded, onTreeItemClick,
}: {
  item: TreeItem;
  depth: number;
  activeScreen: string;
  activeTreeItem?: string | null;
  onNavigateTo: (screen: string, itemId?: string) => void;
  defaultExpanded: boolean;
  onTreeItemClick?: (id: string) => void;
}) {
  const [expanded, setExpanded] = useState(defaultExpanded);
  const hasChildren = !!item.children?.length;
  const isActive = item.screen === activeScreen || activeTreeItem === item.id;

  const handleClick = () => {
    if (hasChildren) setExpanded(!expanded);
    if (item.screen) onNavigateTo(item.screen, item.id);
    if (onTreeItemClick) onTreeItemClick(item.id);
  };

  return (
    <div>
      <button
        onClick={handleClick}
        className="flex items-center w-full rounded-md transition-all text-left whitespace-nowrap overflow-hidden"
        style={{
          height: depth === 0 ? 30 : 24,
          paddingLeft: depth === 0 ? 8 : 16 + depth * 14,
          paddingRight: 6,
          color: isActive ? '#E85D7A' : (depth === 0 ? '#1E293B' : '#64748B'),
          background: isActive ? 'rgba(232,93,122,0.08)' : 'transparent',
          fontWeight: isActive ? 600 : (depth <= 1 ? 500 : 400),
          fontSize: depth === 0 ? 13 : 12,
        }}
        onMouseEnter={e => { if (!isActive) (e.currentTarget as HTMLElement).style.background = '#F8FAFC'; }}
        onMouseLeave={e => { if (!isActive) (e.currentTarget as HTMLElement).style.background = 'transparent'; }}
      >
        {hasChildren && (
          <span className="mr-1 shrink-0">
            {expanded
              ? <ChevronDown size={11} style={{ color: '#94A3B8' }} />
              : <ChevronRight size={11} style={{ color: '#94A3B8' }} />}
          </span>
        )}
        {!hasChildren && <span className="w-3 mr-1 shrink-0" />}

        {item.icon ? (
          <item.icon size={depth === 0 ? 15 : 12} className="shrink-0" style={{ color: isActive ? '#E85D7A' : '#94A3B8' }} />
        ) : (
          <span className="inline-block w-1.5 h-1.5 rounded-full shrink-0" style={{ background: '#CBD5E1' }} />
        )}

        <span className="ml-1.5 truncate flex-1">{item.label}</span>

        {item.meta && (
          <span className="ml-1 shrink-0 text-[10px] px-1 rounded" style={{ background: '#F1F5F9', color: '#94A3B8' }}>
            {item.meta}
          </span>
        )}
      </button>

      {hasChildren && expanded && (
        <div>
          {item.children!.map(child => (
            <TreeItemRow
              key={child.id}
              item={child}
              depth={depth + 1}
              activeScreen={activeScreen}
              activeTreeItem={activeTreeItem}
              onNavigateTo={onNavigateTo}
              onTreeItemClick={onTreeItemClick}
              defaultExpanded={false}
            />
          ))}
        </div>
      )}
    </div>
  );
}

const treeData: TreeItem[] = [
  {
    id: 'home', icon: Home, label: 'Accueil', screen: 'home',
  },
  {
    id: 'm1', icon: FileText, label: 'M1 — Initialisation',
    children: [
      {
        id: 'm1-config', icon: CheckCircle, label: 'Paramètres mission', screen: 'm1', meta: 'validé',
        children: [
          { id: 'm1-config-output', icon: FileCheck, label: 'Fiche mission' },
        ],
      },
      {
        id: 'm1-besoin', icon: FileText, label: 'Analyse des besoins', screen: 'm1-structure',
      },
    ],
  },
  {
    id: 'm2', icon: FolderOpen, label: 'M2 — Ingestion',
    children: [
      { id: 'm2-docs', icon: FileText, label: 'Ingestion & Analyse', screen: 'm2', meta: '3/4 reçus' },
      { id: 'm2-kanban', icon: ClipboardList, label: 'Vue en colonnes', screen: 'm2-kanban', meta: 'terminé' },
    ],
  },
  {
    id: 'm3', icon: Map, label: 'M3 — Analyse',
    children: [
      { id: 'm3-analyse', icon: Brain, label: 'Analyse des documents', screen: 'm3' },
      { id: 'm3-chat', icon: MessageSquare, label: 'Assistant IA', screen: 'chat' },
    ],
  },
  {
    id: 'm4', icon: Calendar, label: 'M4 — Ateliers',
    children: [
      { id: 'm4-gap', icon: Target, label: 'Analyse d\'écart (GAP)', screen: 'm4-gap' },
      {
        id: 'm4-planning', icon: Calendar, label: 'Planification (Gantt)', screen: 'm4',
        children: [
          {
            id: 'm4-atelier-1', icon: Users, label: 'Atelier 1: Gouvernance',
            children: [
              { id: 'm4-q-cobit', icon: ClipboardList, label: 'Questionnaire COBIT 2019', meta: '0/8' },
              { id: 'm4-q-itil', icon: ClipboardList, label: 'Questionnaire ITIL 4', meta: '0/5' },
              { id: 'm4-q-iso', icon: ClipboardList, label: 'Questionnaire ISO 27001', meta: '0/6' },
            ],
          },
          { id: 'm4-atelier-2', icon: Users, label: 'Atelier 2: Infrastructure', meta: 'à préparer' },
          { id: 'm4-atelier-3', icon: Users, label: 'Atelier 3: Sécurité', meta: 'à préparer' },
        ],
      },
      {
        id: 'm4-cockpit', icon: Eye, label: 'Cockpit atelier', screen: 'm4-cockpit', meta: 'à venir',
        children: [
          { id: 'm4-cockpit-q', icon: BookOpen, label: 'Questions client' },
          { id: 'm4-cockpit-notes', icon: Pen, label: 'Notes associées' },
        ],
      },
      { id: 'm4-cr', icon: Pen, label: 'Compte rendu (CR)', screen: 'm4-cr', meta: 'à venir' },
    ],
  },
  {
    id: 'm5', icon: LayoutList, label: 'M5 — Synthèse',
    children: [
      { id: 'm5-brouillon', icon: FileText, label: 'Brouillon', screen: 'm5', meta: 'à venir' },
      { id: 'm5-split', icon: Pen, label: 'Édition Split', screen: 'm5', meta: 'à venir' },
      { id: 'm5-carto', icon: Map, label: 'Cartographie finale', screen: 'm5', meta: 'à venir' },
      {
        id: 'm5-share', icon: MessageSquare, label: 'Partage & Validation', screen: 'm5',
        children: [
          { id: 'm5-share-client', icon: MessageSquare, label: 'Retours client', meta: '0 en attente' },
        ],
      },
    ],
  },
];

function isDescendant(item: TreeItem, screen: string, treeItem?: string | null): boolean {
  if (item.screen === screen || item.id === treeItem) return true;
  if (item.children) return item.children.some(c => isDescendant(c, screen, treeItem));
  return false;
}

export function AppShell({ children, activeModule, onNavigate, activeScreen, activeTreeItem, onTreeItemChange, onScreenChange, onAdminClick }: AppShellProps) {
  const [sidebarExpanded, setSidebarExpanded] = useState(false);

  const handleTreeItemClick = (id: string) => {
    if (onTreeItemChange) onTreeItemChange(id);
  };

  return (
    <div className="h-screen w-screen flex overflow-hidden" style={{ background: "#F8FAFC" }}>
      <aside
        className="h-full flex flex-col shrink-0 transition-all duration-200 overflow-hidden"
        style={{
          width: sidebarExpanded ? 270 : 64,
          background: "#FFFFFF",
          borderRight: "1px solid #E2E8F0",
        }}
        onMouseEnter={() => setSidebarExpanded(true)}
        onMouseLeave={() => setSidebarExpanded(false)}
      >
        <div className="flex flex-col items-center justify-center px-4 py-4 shrink-0 gap-1.5" style={{ borderBottom: "1px solid #E2E8F0", minHeight: 64 }}>
          {sidebarExpanded ? (
            <>
              <img src={devoteamLogo} alt="Devoteam" className="w-36 h-auto object-contain" />
              <span className="text-[11px] font-bold tracking-wider uppercase" style={{ color: "#E85D7A" }}>
                SDSI Platform
              </span>
            </>
          ) : (
            <div className="w-7 h-7 rounded-md flex items-center justify-center shrink-0 font-bold text-sm"
              style={{ background: "#E85D7A", color: "white" }}>S</div>
          )}
        </div>

        <nav className="flex-1 py-2 flex flex-col gap-0.5 px-1.5 overflow-y-auto overflow-x-hidden">
          {treeData.map(root => {
            const expandedByDefault = isDescendant(root, activeScreen, activeTreeItem);
            return (
              <TreeItemRow
                key={root.id}
                item={root}
                depth={0}
                activeScreen={activeScreen}
                activeTreeItem={activeTreeItem}
                onNavigateTo={(screen, itemId) => {
                  if (screen !== activeScreen) onScreenChange(screen);
                  if (itemId && onTreeItemChange) onTreeItemChange(itemId);
                }}
                onTreeItemClick={handleTreeItemClick}
                defaultExpanded={expandedByDefault}
              />
            );
          })}
        </nav>

        <div className="py-3 flex flex-col gap-0.5 px-2 shrink-0" style={{ borderTop: "1px solid #E2E8F0" }}>
          <button key="admin" onClick={onAdminClick}
            className="flex items-center h-8 px-2 rounded-md transition-all text-xs whitespace-nowrap overflow-hidden"
            style={{ color: "#94A3B8" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.color = "#64748B"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.color = "#94A3B8"; }}>
            <Settings size={14} className="shrink-0" />
            {sidebarExpanded && <span className="ml-2.5">Admin</span>}
          </button>
          <button key="aide"
            className="flex items-center h-8 px-2 rounded-md transition-all text-xs whitespace-nowrap overflow-hidden"
            style={{ color: "#94A3B8" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.color = "#64748B"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.color = "#94A3B8"; }}>
            <HelpCircle size={14} className="shrink-0" />
            {sidebarExpanded && <span className="ml-2.5">Aide</span>}
          </button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="h-[52px] shrink-0 flex items-center px-5 gap-4" style={{ background: "#FFFFFF", borderBottom: "1px solid #E2E8F0" }}>
          <div className="flex items-center gap-1.5 text-xs" style={{ color: "#64748B" }}>
            <span>Missions</span>
            <ChevronRight size={12} />
            <span style={{ color: "#0F172A", fontWeight: 500 }}>Audit SI — Banque Centrale Maghreb</span>
          </div>
          <span className="px-2 py-0.5 rounded text-xs font-medium"
            style={{ background: "rgba(232,93,122,0.1)", color: "#E85D7A", fontFamily: "JetBrains Mono, monospace" }}>
            M{activeModule} En cours
          </span>
          <div className="flex-1 flex justify-center">
            <ModuleStepper active={activeModule} onNavigate={onNavigate} />
          </div>
          <div className="flex items-center gap-3 mr-1">
            <div className="flex items-center gap-1.5">
              <CoverageRing pct={42} size={30} />
              <span className="text-[10px] leading-tight" style={{ color: "#64748B" }}>Doc.</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CoverageRing pct={65} size={30} />
              <span className="text-[10px] leading-tight" style={{ color: "#64748B" }}>Analyse</span>
            </div>
          </div>
          <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold"
            style={{ background: "#F1F5F9", color: "#64748B", border: "1px solid #E2E8F0" }}>
            SC
          </div>
        </header>

        <main className="flex-1 overflow-hidden">{children}</main>
      </div>
    </div>
  );
}
