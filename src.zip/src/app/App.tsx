import { useState } from "react";
import { AppShell } from "./components/AppShell";
import { HomeScreen } from "./components/screens/HomeScreen";
import { M1Creation } from "./components/screens/M1Creation";
import { M1Structure } from "./components/screens/M1Structure";
import { M2Upload } from "./components/screens/M2Upload";
import { M2Kanban } from "./components/screens/M2Kanban";
import { M3Analysis } from "./components/screens/M3Analysis";
import { M4Gantt } from "./components/screens/M4Gantt";
import { M4GapAnalysis } from "./components/screens/M4GapAnalysis";
import { M4Cockpit } from "./components/screens/M4Cockpit";
import { M4CR } from "./components/screens/M4CR";
import { M5Synthesis } from "./components/screens/M5Synthesis";
import { ChatBotScreen } from "./components/screens/ChatBotScreen";
import { AdminScreen } from "./components/screens/AdminScreen";

export interface CartoBrique {
  id: string;
  label: string;
  domain: string;
  maturity: string;
  pct: number;
}

type Screen =
  | "home"
  | "m1" | "m1-structure"
  | "m2" | "m2-kanban"
  | "m3"
  | "m4" | "m4-gap" | "m4-cockpit" | "m4-cr"
  | "m5"
  | "chat"
  | "admin";

const screenToModule: Record<Screen, number> = {
  home: 1,
  m1: 1, "m1-structure": 1,
  m2: 2, "m2-kanban": 2,
  m3: 3,
  m4: 4, "m4-gap": 4, "m4-cockpit": 4, "m4-cr": 4,
  m5: 5,
  chat: 3,
  admin: 1,
};

const moduleToScreen: Record<number, Screen> = {
  1: "m1", 2: "m2", 3: "m3", 4: "m4", 5: "m5",
};

export default function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const [activeTreeItem, setActiveTreeItem] = useState<string | null>(null);
  const [chatQuestions, setChatQuestions] = useState<string[]>([]);

  const [briques, setBriques] = useState<CartoBrique[]>([
    { id: "gov",    label: "Gouvernance SI",          domain: "Organisationnel", maturity: "unknown",  pct: 0 },
    { id: "rh",     label: "RH & Structure",           domain: "Organisationnel", maturity: "unknown",  pct: 0 },
    { id: "infra",  label: "Infrastructure Réseaux",   domain: "Technique",       maturity: "unknown",  pct: 0 },
    { id: "secu",   label: "Politique Sécurité",       domain: "Technique",       maturity: "unknown",  pct: 0 },
    { id: "cartof", label: "Cartographie fonct.",      domain: "Cartographie",    maturity: "unknown",  pct: 0 },
    { id: "cartoa", label: "Cartographie applic.",     domain: "Cartographie",    maturity: "unknown",  pct: 0 },
  ]);

  const activeModule = screenToModule[screen] ?? 1;
  const navigate = (s: Screen) => setScreen(s);

  const renderScreen = () => {
    switch (screen) {
      case "home":
        return <HomeScreen onSelectMission={() => navigate("m1")} onResumeMission={(m) => navigate(moduleToScreen[m])} />;
      case "m1":
        return <M1Creation onNext={() => navigate("m1-structure")} />;
      case "m1-structure":
        return <M1Structure onNext={() => navigate("m2")} onBack={() => navigate("m1")} />;
      case "m2":
        return <M2Upload onNext={() => navigate("m2-kanban")} />;
      case "m2-kanban":
        return <M2Kanban onAnalyze={() => navigate("m3")} />;
      case "m3":
        return <M3Analysis briques={briques} onBriquesChange={setBriques} onNext={() => navigate("m4-gap")} onBack={() => navigate("m2-kanban")} />;
      case "m4-gap":
        return <M4GapAnalysis onNext={() => navigate("m4")} onBack={() => navigate("m3")} additionalQuestions={chatQuestions} />;
      case "m4":
        return <M4Gantt onCockpit={() => navigate("m4-cockpit")} />;
      case "m4-cockpit":
        return <M4Cockpit onNext={() => navigate("m4-cr")} />;
      case "m4-cr":
        return <M4CR onNext={() => navigate("m5")} />;
      case "m5":
        return <M5Synthesis briques={briques} onBriquesChange={setBriques} onNext={() => navigate("home")} />;
      case "admin":
        return <AdminScreen onBack={() => navigate("home")} onNavigateToMission={(m) => navigate(moduleToScreen[m])} />;
      case "chat":
        return <ChatBotScreen onBack={() => navigate("m2-kanban")} onNext={() => navigate("m4-gap")} onQuestions={setChatQuestions} />;
      default:
        return null;
    }
  };

  return (
    <AppShell
      activeModule={activeModule}
      onNavigate={(m) => navigate(moduleToScreen[m])}
      activeScreen={screen}
      activeTreeItem={activeTreeItem}
      onTreeItemChange={setActiveTreeItem}
      onAdminClick={() => navigate("admin")}
      onScreenChange={(s) => {
        if (s === "home") navigate("home");
        else if (s.startsWith("m1")) navigate(s as Screen);
        else if (s.startsWith("m2")) navigate(s as Screen);
        else if (s.startsWith("m3")) navigate(s as Screen);
        else if (s.startsWith("m4")) navigate(s as Screen);
        else if (s.startsWith("m5")) navigate(s as Screen);
        else if (s === "chat") navigate("chat");
        else if (s === "admin") navigate("admin");
      }}
    >
      {renderScreen()}
    </AppShell>
  );
}
