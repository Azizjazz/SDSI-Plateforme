import { useState, useCallback } from "react";

const TREE_DATA = [
  {
    id: "as-is", label: "AS-IS", level: 1, type: "as-is",
    children: [
      {
        id: "cartographie", label: "Cartographie", level: 2, type: "as-is-primary",
        children: [
          { id: "carto-fonc", label: "Carto. fonc.", level: 3, type: "as-is-primary", children: [] },
          { id: "carto-appl", label: "Carto. appl.", level: 3, type: "as-is-primary", children: [] }
        ]
      },
      {
        id: "technique", label: "Technique", level: 2, type: "as-is",
        children: [
          {
            id: "infrastructure", label: "Infrastructure", level: 3, type: "as-is",
            children: [
              {
                id: "architectures", label: "Architectures", level: 4, type: "as-is",
                children: [
                  { id: "reseaux", label: "Réseaux", level: 5, type: "as-is", children: [] },
                  { id: "systemes", label: "Systèmes", level: 5, type: "as-is", children: [] },
                  { id: "securite-technique", label: "Sécurité technique", level: 5, type: "as-is", children: [] }
                ]
              },
              {
                id: "politiques-infra", label: "Politiques", level: 4, type: "as-is",
                children: []
              }
            ]
          }
        ]
      },
      {
        id: "organisationnel", label: "Organisationnel", level: 2, type: "as-is",
        children: [
          { id: "structure-dsi", label: "Structure DSI", level: 3, type: "as-is", children: [] },
          {
            id: "gouvernance-si", label: "Gouvernance SI", level: 3, type: "as-is",
            children: [
              {
                id: "politiques-gouv", label: "Politiques Gouvernance", level: 4, type: "as-is",
                children: [
                  { id: "pol-securite", label: "Politique sécurité", level: 5, type: "as-is", children: [] },
                  { id: "sauvegarde", label: "Sauvegarde", level: 5, type: "as-is", children: [] },
                  { id: "pca", label: "PCA", level: 5, type: "as-is", children: [] }
                ]
              }
            ]
          },
          { id: "processus", label: "Processus", level: 3, type: "as-is", children: [] }
        ]
      }
    ]
  },
  {
    id: "cible", label: "Cible", level: 1, type: "cible",
    children: []
  },
  {
    id: "feuille-de-route", label: "Feuille de route", level: 1, type: "feuille",
    children: [
      { id: "projets-budget", label: "Projets & Budget", level: 2, type: "feuille", children: [] }
    ]
  }
];

const TYPE_STYLES = {
  "as-is-primary": {
    dot: "#1E40AF",
    badge: { bg: "#1e3a8a", color: "#bfdbfe", label: "AS-IS" },
    chip: { bg: "#dbeafe", color: "#1e3a8a" }
  },
  "as-is": {
    dot: "#3B82F6",
    badge: { bg: "#eff6ff", color: "#1d4ed8", label: "AS-IS" },
    chip: { bg: "#eff6ff", color: "#1d4ed8" }
  },
  "cible": {
    dot: "#16a34a",
    badge: { bg: "#dcfce7", color: "#15803d", label: "Cible" },
    chip: { bg: "#dcfce7", color: "#15803d" }
  },
  "feuille": {
    dot: "#d97706",
    badge: { bg: "#fef3c7", color: "#92400e", label: "Feuille de route" },
    chip: { bg: "#fef3c7", color: "#92400e" }
  }
};

function getAllIds(nodes) {
  let ids = [];
  for (const n of nodes) {
    if (n.children && n.children.length > 0) {
      ids.push(n.id);
      ids = ids.concat(getAllIds(n.children));
    }
  }
  return ids;
}

function countLeaves(node) {
  if (!node.children || node.children.length === 0) return 1;
  return node.children.reduce((acc, c) => acc + countLeaves(c), 0);
}

function nodeMatchesSearch(node, q) {
  if (!q) return true;
  return node.label.toLowerCase().includes(q.toLowerCase());
}

function subtreeHasMatch(node, q) {
  if (!q) return true;
  if (nodeMatchesSearch(node, q)) return true;
  if (node.children) return node.children.some(c => subtreeHasMatch(c, q));
  return false;
}

function TreeNode({ node, expanded, toggle, depth, searchQ }) {
  const hasChildren = node.children && node.children.length > 0;
  const isExpanded = expanded.has(node.id);
  const style = TYPE_STYLES[node.type] || TYPE_STYLES["as-is"];
  const isMatch = searchQ && nodeMatchesSearch(node, searchQ);

  const levelColors = ["", "#3B82F6", "#6366f1", "#8b5cf6", "#ec4899", "#f59e0b"];

  return (
    <div style={{ marginLeft: depth === 0 ? 0 : 20, position: "relative" }}>
      {depth > 0 && (
        <div style={{
          position: "absolute", left: -12, top: 0, bottom: 0,
          width: 1, background: "var(--color-border-tertiary)"
        }} />
      )}
      <div
        onClick={() => hasChildren && toggle(node.id)}
        style={{
          display: "flex", alignItems: "center", gap: 8,
          padding: "7px 10px",
          borderRadius: 8,
          cursor: hasChildren ? "pointer" : "default",
          background: isMatch ? "#fef9c3" : "transparent",
          border: isMatch ? "1px solid #fde047" : "1px solid transparent",
          transition: "background 0.15s",
          marginBottom: 2,
          position: "relative"
        }}
        onMouseEnter={e => { if (!isMatch) e.currentTarget.style.background = "var(--color-background-secondary)"; }}
        onMouseLeave={e => { if (!isMatch) e.currentTarget.style.background = "transparent"; }}
      >
        {depth > 0 && (
          <div style={{
            position: "absolute", left: -12, top: "50%",
            width: 12, height: 1,
            background: "var(--color-border-tertiary)"
          }} />
        )}
        <span style={{ fontSize: 14, color: "var(--color-text-tertiary)", width: 16, textAlign: "center", flexShrink: 0 }}>
          {hasChildren ? (isExpanded ? "▾" : "▸") : "·"}
        </span>
        <span style={{
          width: 8, height: 8, borderRadius: "50%",
          background: style.dot, flexShrink: 0
        }} />
        <span style={{
          fontSize: 14, fontWeight: depth === 0 ? 500 : 400,
          color: "var(--color-text-primary)", flex: 1
        }}>
          {node.label}
        </span>
        <span style={{
          fontSize: 10, padding: "2px 7px",
          borderRadius: 99, fontWeight: 500,
          background: `${levelColors[node.level]}18`,
          color: levelColors[node.level],
          flexShrink: 0
        }}>
          N{node.level}
        </span>
        {depth === 0 && (
          <span style={{
            fontSize: 10, padding: "2px 8px",
            borderRadius: 99, fontWeight: 500,
            background: style.badge.bg,
            color: style.badge.color,
            flexShrink: 0
          }}>
            {style.badge.label}
          </span>
        )}
        {hasChildren && (
          <span style={{ fontSize: 11, color: "var(--color-text-tertiary)", flexShrink: 0 }}>
            {countLeaves(node)} feuilles
          </span>
        )}
      </div>
      {hasChildren && isExpanded && (
        <div style={{ marginLeft: 20, borderLeft: "1px solid var(--color-border-tertiary)" }}>
          {node.children
            .filter(c => subtreeHasMatch(c, searchQ))
            .map(child => (
              <TreeNode
                key={child.id}
                node={child}
                expanded={expanded}
                toggle={toggle}
                depth={depth + 1}
                searchQ={searchQ}
              />
            ))}
        </div>
      )}
    </div>
  );
}

export default function SDSITree() {
  const allExpandable = getAllIds(TREE_DATA);
  const [expanded, setExpanded] = useState(new Set(["as-is"]));
  const [search, setSearch] = useState("");

  const toggle = useCallback((id) => {
    setExpanded(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }, []);

  const expandAll = () => setExpanded(new Set(allExpandable));
  const collapseAll = () => setExpanded(new Set());

  const totalNodes = (function count(nodes) {
    return nodes.reduce((a, n) => a + 1 + (n.children ? count(n.children) : 0), 0);
  })(TREE_DATA);

  const leafCount = TREE_DATA.reduce((a, n) => a + countLeaves(n), 0);

  return (
    <div style={{ fontFamily: "var(--font-sans)", padding: "1rem 0" }}>
      <div style={{ marginBottom: 16, display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 10 }}>
        <div>
          <p style={{ margin: 0, fontSize: 13, color: "var(--color-text-secondary)" }}>
            {totalNodes} nœuds · {leafCount} feuilles · 5 niveaux
          </p>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          <button onClick={expandAll} style={{ fontSize: 12, padding: "5px 12px", borderRadius: 6, cursor: "pointer" }}>
            Tout déplier
          </button>
          <button onClick={collapseAll} style={{ fontSize: 12, padding: "5px 12px", borderRadius: 6, cursor: "pointer" }}>
            Tout replier
          </button>
        </div>
      </div>

      <input
        type="text"
        placeholder="Rechercher un nœud..."
        value={search}
        onChange={e => {
          setSearch(e.target.value);
          if (e.target.value) setExpanded(new Set(allExpandable));
        }}
        style={{ width: "100%", marginBottom: 14, fontSize: 13, boxSizing: "border-box" }}
      />

      <div style={{
        display: "flex", gap: 8, marginBottom: 16, flexWrap: "wrap"
      }}>
        {[
          { type: "as-is", label: "AS-IS" },
          { type: "cible", label: "Cible" },
          { type: "feuille", label: "Feuille de route" }
        ].map(t => (
          <span key={t.type} style={{
            display: "inline-flex", alignItems: "center", gap: 5,
            fontSize: 11, padding: "3px 10px", borderRadius: 99,
            background: TYPE_STYLES[t.type].chip.bg,
            color: TYPE_STYLES[t.type].chip.color,
            fontWeight: 500
          }}>
            <span style={{
              width: 7, height: 7, borderRadius: "50%",
              background: TYPE_STYLES[t.type].dot
            }} />
            {t.label}
          </span>
        ))}
        <span style={{ fontSize: 11, color: "var(--color-text-tertiary)", alignSelf: "center" }}>
          · N1–N5 = niveaux hiérarchiques
        </span>
      </div>

      <div style={{
        background: "var(--color-background-primary)",
        border: "0.5px solid var(--color-border-tertiary)",
        borderRadius: 12,
        padding: "12px 16px"
      }}>
        {TREE_DATA.filter(n => subtreeHasMatch(n, search)).map(node => (
          <TreeNode
            key={node.id}
            node={node}
            expanded={expanded}
            toggle={toggle}
            depth={0}
            searchQ={search}
          />
        ))}
      </div>
    </div>
  );
}
