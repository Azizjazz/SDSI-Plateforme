# Prompt — Arbre hiérarchique SDSI (React, admin, déroulant)

## Contexte
Crée un composant React standalone (pas de dépendances externes hormis React) qui affiche une hiérarchie SDSI sur 5 niveaux sous forme d'arbre déroulant consultable par un admin.

---

## Données à représenter

```js
const TREE_DATA = [
  {
    id: "as-is", label: "AS-IS", level: 1, type: "as-is",
    children: [
      {
        id: "cartographie", label: "Cartographie", level: 2, type: "as-is-primary",
        children: [
          { id: "carto-fonc",  label: "Carto. fonc.",  level: 3, type: "as-is-primary", children: [] },
          { id: "carto-appl",  label: "Carto. appl.",  level: 3, type: "as-is-primary", children: [] }
        ]
      },
      {
        id: "technique", label: "Technique", level: 2, type: "as-is",
        children: [
          {
            id: "infrastructure", label: "Infrastructure", level: 3, type: "as-is",
            children: [
              {
                id: "architectures", label: "Architectures", level: 4, type: "as-is",
                children: [
                  { id: "reseaux",            label: "Réseaux",            level: 5, type: "as-is", children: [] },
                  { id: "systemes",           label: "Systèmes",           level: 5, type: "as-is", children: [] },
                  { id: "securite-technique", label: "Sécurité technique", level: 5, type: "as-is", children: [] }
                ]
              },
              { id: "politiques-infra", label: "Politiques", level: 4, type: "as-is", children: [] }
            ]
          }
        ]
      },
      {
        id: "organisationnel", label: "Organisationnel", level: 2, type: "as-is",
        children: [
          { id: "structure-dsi", label: "Structure DSI", level: 3, type: "as-is", children: [] },
          {
            id: "gouvernance-si", label: "Gouvernance SI", level: 3, type: "as-is",
            children: [
              {
                id: "politiques-gouv", label: "Politiques Gouvernance", level: 4, type: "as-is",
                children: [
                  { id: "pol-securite", label: "Politique sécurité", level: 5, type: "as-is", children: [] },
                  { id: "sauvegarde",   label: "Sauvegarde",          level: 5, type: "as-is", children: [] },
                  { id: "pca",          label: "PCA",                  level: 5, type: "as-is", children: [] }
                ]
              }
            ]
          },
          { id: "processus", label: "Processus", level: 3, type: "as-is", children: [] }
        ]
      }
    ]
  },
  {
    id: "cible", label: "Cible", level: 1, type: "cible", children: []
  },
  {
    id: "feuille-de-route", label: "Feuille de route", level: 1, type: "feuille",
    children: [
      { id: "projets-budget", label: "Projets & Budget", level: 2, type: "feuille", children: [] }
    ]
  }
];
```

---

## Color coding par `type`

| type           | dot       | chip bg   | chip text | usage                        |
|----------------|-----------|-----------|-----------|------------------------------|
| `as-is-primary`| `#1E40AF` | `#dbeafe` | `#1e3a8a` | Cartographie (actif/highlight) |
| `as-is`        | `#3B82F6` | `#eff6ff` | `#1d4ed8` | Branches AS-IS standard       |
| `cible`        | `#16a34a` | `#dcfce7` | `#15803d` | Nœud Cible                    |
| `feuille`      | `#d97706` | `#fef3c7` | `#92400e` | Feuille de route + Projets    |

Couleurs des chips niveau (N1 à N5) :
- N1 → `#3B82F6`, N2 → `#6366f1`, N3 → `#8b5cf6`, N4 → `#ec4899`, N5 → `#f59e0b`
- Fond du chip = couleur avec opacité ~13% (ex: `#3B82F620`)

---

## Comportement attendu

### Arbre déroulant
- Chaque nœud ayant des enfants est cliquable → déplie / replie ses enfants
- Indentation visuelle croissante par niveau (20px par niveau)
- Ligne verticale fine (`1px`, gris clair) reliant visuellement les enfants à leur parent
- Ligne horizontale fine de 12px raccordant chaque nœud à la ligne verticale de son parent
- Chevron `▸` si replié, `▾` si déplié, `·` si feuille (pas d'enfants)
- Nœud non-feuille affiche à droite le nombre de feuilles en cascade (ex: "9 feuilles")

### Chaque ligne de nœud affiche (de gauche à droite) :
1. Chevron (▸ / ▾ / ·)
2. Dot coloré (cercle 8px, couleur selon `type`)
3. Label du nœud
4. Chip niveau (ex: `N2`) — couleur par niveau
5. Badge type (ex: `AS-IS`, `Cible`, `Feuille de route`) — uniquement sur les nœuds de niveau 1
6. Compteur de feuilles — uniquement si le nœud a des enfants

### Contrôles admin (barre du haut)
- Compteur global : `X nœuds · Y feuilles · 5 niveaux`
- Bouton **Tout déplier** → ouvre tous les nœuds expansibles
- Bouton **Tout replier** → ferme tous les nœuds

### Recherche
- Champ de recherche texte au-dessus de l'arbre
- Filtre en temps réel : masque les nœuds ne correspondant pas
- Surligne en jaune (`#fef9c3`, bordure `#fde047`) les nœuds dont le label matche
- Quand une recherche est active → force l'expansion de toute la hiérarchie

### Légende
- Affichée entre la recherche et l'arbre
- 3 chips colorés : AS-IS / Cible / Feuille de route
- Note textuelle : `· N1–N5 = niveaux hiérarchiques`

---

## Style général
- Fond transparent (hérite du parent)
- Arbre dans une carte blanche avec bordure fine `0.5px solid #e5e7eb` et `border-radius: 12px`
- Hover sur les lignes → fond gris très léger
- Pas de dépendances CSS externes (Tailwind ou CSS-in-JS inline acceptés)
- Police système ou `sans-serif`
- Composant `default export` nommé `SDSITree`
- État initial : seul le nœud racine `"as-is"` est déplié au chargement

---

## Structure des hooks attendus
```js
const [expanded, setExpanded] = useState(new Set(["as-is"]));
const [search, setSearch]     = useState("");
```

Fonction utilitaire à prévoir :
- `getAllExpandable(nodes)` → liste tous les IDs de nœuds ayant des enfants (pour le bouton "Tout déplier")
- `countLeaves(node)` → compte récursivement les feuilles d'un sous-arbre
- `subtreeMatch(node, query)` → retourne `true` si le nœud ou l'un de ses descendants matche la recherche
